#Alexa Chrome Extension

## How to build
Description about how to build the extensions:

* Open chrome://extensions/ in your chrome's address bar
* Click "Pack extension..." and select your development folder and pem file
* Crx file will be automatically built on the same level of the previous folder. 

## How to deploy
Description about how to deploy the extensions:

* Zip the development folder
* Submit the zip file to Alexa's account(alexa@alexa.com) at chrome's webstore
