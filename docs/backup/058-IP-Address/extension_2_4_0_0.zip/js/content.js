(function() {
	document.body.hasAttribute("sip-shortcut-listen") || (document.body.setAttribute("sip-shortcut-listen", "true"), document.body.addEventListener("keydown", function(a) {
		var b = -1 < navigator.userAgent.toLowerCase().indexOf("mac"),
			c = a.keyCode;
		(a.ctrlKey && a.altKey && !b || a.metaKey && a.altKey && b) && (64 < c && 91 > c) && chrome.extension.sendMessage({
				action: "hotkey-pressed",
				keyCode: c
			})
	}, !1));
	var b = null;
	document.addEventListener("mousedown", function(a) {
		2 == a.button && (b = a.target)
	}, !0);
	chrome.extension.onMessage.addListener(function(a,
		d, c) {
		"object" === typeof a && "paste" === a.action && (b.value += a.message)
	})
})();