if (typeof ipAddress == "undefined" || !ipAddress) { var ipAddress = {}; }

ipAddress.utils = {
    openURLInNewTab : function(url) {
      chrome.tabs.create({url:url});
    },

    getExtensionVersion : function(callback) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.open("get", "/manifest.json", true);
        xmlhttp.onreadystatechange = function (e) {
            if (xmlhttp.readyState == 4) {
                callback(JSON.parse(xmlhttp.responseText).version);
            }
        };
        xmlhttp.send({});
    },

    getChromeVersion : function() {
        if (!window || !window.navigator) return '-';
        
        var userAgent = window.navigator.userAgent;
        if (userAgent && userAgent.match(/Chrome\/([0-9.]+)/)) {
            return RegExp.$1;
        } else {
            return '-';
        }
    },

    getPlatform : function() {
        var userAgent = navigator.userAgent.toLowerCase();
        if (userAgent.indexOf('mac') != -1) return 'mac';
        if (userAgent.indexOf('windows') != -1) return 'windows';
        if (userAgent.indexOf('linux') != -1) return 'linux';
        return 'unknown';
    },

    getIPData: function(callback){
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "http://check-ip.9gg.de/check-ip.php", true);
        xhr.onreadystatechange = function() {
          if (xhr.readyState == 4) {
            var responseObject = JSON.parse(xhr.responseText);
            callback(responseObject);
          }
        }
        xhr.send();
    },

    platformIs : function(platform) {
       return this.getPlatform() == platform;
    },

    platformSupportsNonForegroundHover : function() {
        return this.getPlatform() == 'windows';
    },

    copyToClipboard: function( text ){
      var copyDiv = document.createElement('div');
      copyDiv.contentEditable = true;
      copyDiv.setAttribute("style","position:absolute; left: 0; top: 0; height: 0; visability: hidden;");
      document.body.appendChild(copyDiv);
      copyDiv.innerHTML = text;
      copyDiv.unselectable = "off";
      copyDiv.focus();
      document.execCommand('SelectAll');
      document.execCommand("Copy", false, null);
      document.body.removeChild(copyDiv);
    },

    setDefaultOptions: function(){
      localStorage['autocopy-option-enabled'] = 'true';
      localStorage['autocopy-option'] = 'ip';
      localStorage['option-keyboard-shortcuts-enabled'] = 'false';
      localStorage['option-keyboard-shortcuts-char']    = 'E';
      return true
    },

    /**
    * Tranlates each Element with a data-message attribute.
    * Example: <h1 data-message="someI18nKey">Default text</h1>
    */
    translateHtml: function(){
      var objects = document.getElementsByTagName('*'), i;
      for(i = 0; i < objects.length; i++) {
        if (objects[i].dataset && objects[i].dataset.message) {
          objects[i].innerHTML = chrome.i18n.getMessage(objects[i].dataset.message);
        }
      }
    }
}