function showInputSuccess(element) {

  var msg = document.createElement('span');
  msg.appendChild(document.createTextNode(chrome.i18n.getMessage('popup_page_copied')));
  msg.setAttribute('class', 'msg');

  element.parentElement.appendChild(msg);

  // change the style for some seconds
  element.style.backgroundColor = '#e3f8e7';
  element.style.color = '#4aaa5a';

  //hide the msg after 0.75 seconds
  window.setTimeout(function () {
    element.style.backgroundColor = '#ffffff';
    element.style.color = '#000000';
    element.parentElement.removeChild(msg);
  }, 750);
}

function handleAutocopy(ipData) {
  var autocopy = document.getElementById('autocopy');
  if (localStorage['autocopy-option-enabled'] === "true") {
    autocopy.checked = true;
    switch (localStorage['autocopy-option']) {
      case "ip":
        ipAddress.utils.copyToClipboard(ipData.remote_addr);
        showInputSuccess(ipField);
        break;
      case "dns":
        ipAddress.utils.copyToClipboard(ipData.remote_host);
        break;
    }
  } else {
    autocopy.checked = false;
  }
  autocopy.addEventListener('change', function () {
    localStorage['autocopy-option-enabled'] = autocopy.checked ? "true" : "false";
  }, false);
}

function handleDetails() {
  var details = document.getElementById("details_button");
  var detailsBox = document.getElementById("details");

  // load state
  if (localStorage['showDetails'] == "true") {
    detailsBox.style.display = "block";
    details.innerHTML = chrome.i18n.getMessage('popup_page_hide_details');
  } else {
    detailsBox.style.display = "none";
  }

  // toggle on click
  details.addEventListener('click', function () {
    if (detailsBox.style.display == "none") {
      localStorage['showDetails'] = true;
      detailsBox.style.display = "block";
      details.innerHTML = chrome.i18n.getMessage('popup_page_hide_details');
    } else {
      localStorage['showDetails'] = false;
      detailsBox.style.display = "none";
      details.innerHTML = " " + chrome.i18n.getMessage('popup_page_details');
    }
  }, false)
}

function handleShortcut() {
  var checkbox = document.getElementById("shortcut");
  var lable = document.getElementById("shortcutLable");
  var controlls = document.getElementById("shortcutControlls");
  var shortcut = controlls.childNodes[1];
  var shortcutChar = controlls.childNodes[3];

  debuggi = shortcutChar;

  function save() {
    localStorage['option-keyboard-shortcuts-enabled'] = checkbox.checked;
    localStorage['option-keyboard-shortcuts-char'] = shortcutChar.value;
  }

  function loadStates() {
    checkbox.checked = localStorage['option-keyboard-shortcuts-enabled'] == "true" ? true : false;
    shortcutChar.value = localStorage['option-keyboard-shortcuts-char'];
    calibrate();
  }

  function calibrate() {
    if (checkbox.checked) {
      lable.style.display = "none";
      controlls.style.display = "inline";
    } else {
      lable.style.display = "inline";
      controlls.style.display = "none";
    }
    save();
  }

  // set shortcut lable
  var isMac = ipAddress.utils.getPlatform() == 'mac';
  shortcut.innerHTML = chrome.i18n.getMessage('popup_page_shorcut') + (isMac ? 'Cmd + Opt + ' : 'Ctrl + Alt + ');

  // fill the selectbox width options (chars) 
  var charCodeOfA = 65,
      charCodeOfZ = 90,
      // disable specific shortcuts - Blacklist!
      excludeList = {
        'mac':     ['B', 'D', 'F', 'I','P', 'Q', 'T', 'U', 'W'],
        'linux':   ['B', 'H', 'L', 'S', 'X'],
        'windows': ['B', 'H', 'L', 'S', 'X']
      }
  for (var i = charCodeOfA; i <= charCodeOfZ; i++) {
    
      var letter = String.fromCharCode(i),
          option = document.createElement("option");
      option.innerHTML = letter;
      option.setAttribute('value', letter);

      // check if letter is in excludeList
      if(excludeList[ipAddress.utils.getPlatform()].indexOf(letter) != -1){ 
        option.setAttribute('disabled', 'disabled');
      }
      shortcutChar.appendChild(option);
  }

  // add eventlisteners
  checkbox.addEventListener('change', calibrate, false);
  shortcutChar.addEventListener('change', save, false);

  loadStates();
}
handleShortcut();
ipAddress.utils.translateHtml();

/**
 * handles the response (ip,....)
 */
function init(ipData) {
  ipField = document.getElementById("ip_field");
  ipField.value = ipData.remote_addr;
  window.getSelection().removeAllRanges();
  ipField.addEventListener('click', function () {
    ipAddress.utils.copyToClipboard(ipData.remote_addr);
    showInputSuccess(ipField);
  });

  dnsField = document.getElementById("dns_field").innerHTML = ipData.remote_host;
  countryField = document.getElementById("country_field").innerHTML = ipData.remote_country;

  handleAutocopy(ipData);
  handleDetails();
}

ipAddress.utils.getIPData(init);