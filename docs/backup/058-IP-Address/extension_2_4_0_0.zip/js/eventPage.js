/*
 * Populate textfields with contextmenu
 */

// The onClicked callback function.
function contextMenuOnclick(info, tab) {
  ipAddress.utils.getIPData(function(data){
    var message = {
      action: "paste",
      message: data.remote_addr
    }
    chrome.tabs.sendMessage(tab.id, message);
  });
};
chrome.contextMenus.onClicked.addListener(contextMenuOnclick);

// Set up context menu tree at install time and update time!
chrome.runtime.onInstalled.addListener(function() {

    var cmOptions = {
      "title": chrome.i18n.getMessage('context_menu_paste_ip'), 
      "contexts":["editable"],
      "id": "context" + "editable"
    },
    id = chrome.contextMenus.create(cmOptions);

    // set this only on the first install time
    if(localStorage['autocopy-option'] !== "ip"){
      // set default options
      localStorage['autocopy-option-enabled'] = false;
      localStorage['autocopy-option'] = "ip";
      localStorage['showDetails'] = false;
      localStorage['option-keyboard-shortcuts-enabled'] = false;
      localStorage['option-keyboard-shortcuts-char'] = "E";
    }
});

// Listen for hotkey hits
chrome.extension.onMessage.addListener(function(msg, sender, sendResponse) {
  if(  msg.action == 'hotkey-pressed' 
    && localStorage['option-keyboard-shortcuts-enabled'] === "true" 
    && msg.keyCode === localStorage['option-keyboard-shortcuts-char'].charCodeAt(0)){
        ipAddress.utils.getIPData(function(data){
          ipAddress.utils.copyToClipboard(data.remote_addr);
        });
  }
});
