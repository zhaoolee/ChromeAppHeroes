
var Ajax = (function () {

    function load(page, updateItem) {

        // Google PageSpeed Desktop
        if (page.url.indexOf("localhost") === -1 && page.url.indexOf("file://") === -1) {
            getUrl("https://www.googleapis.com/pagespeedonline/v2/runPagespeed?url=" + page.url + "&strategy=desktop", function (xhr) {
                if (xhr.status === 200) {
                    var score = JSON.parse(xhr.responseText).ruleGroups.SPEED.score;
                    page.Performance.pagespeedDesktop.text = "Desktop score of (" + score + "/100)";
                    page.Performance.pagespeedDesktop.result = score > 85;
                    updateItem("pagespeedDesktop", page.Performance.pagespeedDesktop);
                }
                else {
                    page.Performance.pagespeedDesktop.text = "Google PageSpeed (quota limit)";
                    page.Performance.pagespeedDesktop.description = "The daily quota has been reached<br />" + page.Performance.pagespeedDesktop.description;
                    updateItem("pagespeedDesktop", page.Performance.pagespeedDesktop);
                }
            });
        }
        else {
            page.Performance.pagespeed.text = "Google PageSpeed (remote only)";
            updateItem("pagespeedDesktop", page.Performance.pagespeed);
        }

        // Google PageSpeed Mobile
        if (page.url.indexOf("localhost") === -1 && page.url.indexOf("file://") === -1) {
            getUrl("https://www.googleapis.com/pagespeedonline/v2/runPagespeed?url=" + page.url + "&strategy=mobile", function (xhr) {
                if (xhr.status === 200) {
                    var score = JSON.parse(xhr.responseText).ruleGroups.SPEED.score;
                    page.Performance.pagespeedMobile.text = "Mobile score of (" + score + "/100)";
                    page.Performance.pagespeedMobile.result = score > 85;
                    updateItem("pagespeedMobile", page.Performance.pagespeedMobile);

                    var usability = JSON.parse(xhr.responseText).ruleGroups.USABILITY.score;
                    page.Performance.userExperienceUsability.text = "UX score of (" + usability + "/100)";
                    page.Performance.userExperienceUsability.result = usability > 95;
                    updateItem("userExperienceUsability", page.Performance.userExperienceUsability);
                }
                else {
                    page.Performance.pagespeedMobile.text = "Google PageSpeed (quota limit)";
                    page.Performance.pagespeedMobile.description = "The daily quota has been reached<br />" + page.Performance.pagespeedMobile.description;
                    updateItem("pagespeedMobile", page.Performance.pagespeedMobile);
                }
            });
        }
        else {
            page.Performance.pagespeed.text = "Google PageSpeed (remote only)";
            updateItem("pagespeedMobile", page.Performance.pagespeed);
        }

        // Robots.txt and XML Sitemap
        getUrl(page.url + "/robots.txt", function (xhr) {
            page.SEO.robotstxt.result = (xhr.status === 200);
            //page.SEO.sitemap = { text: "Sitemap.xml exist", result: xhr.responseText.indexOf("sitemap") > -1 };
            updateItem("robotstxt", page.SEO.robotstxt);
        });

        // Favicon
        if (!page.Usability.favicon.result) {
            getUrl(page.url + "/favicon.ico", function (xhr) {
                if (xhr.status === 200) {
                    page.Usability.favicon.result = true;
                    updateItem("favicon", page.Usability.favicon);
                }
            });
        }

        // W3C validation
        if (page.Usability.validator.result === "n/a") {
            if (page.url.indexOf("localhost") === -1 && page.url.indexOf("file://") === -1) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "http://validator.nu/?out=json&level=error&laxtype=yes&doc=" + page.url + "", true);
                xhr.setRequestHeader("Content-type", "text/html");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        var json = JSON.parse(xhr.responseText);
                        var errors = json.messages.length;

                        page.Usability.validator.result = errors === 0;
                        page.Usability.validator.text += " (" + errors + " errors)";

                        if (errors > 0) {
                            page.Usability.validator.description = "";

                            for (var i = 0; i < json.messages.length; i++) {
                                page.Usability.validator.description += "<mark title='Line: " + json.messages[i].lastLine + " Column: " + json.messages[i].lastColumn + "'>" + json.messages[i].message + "</mark>"
                            }
                        }

                        updateItem("validator", page.Usability.validator);
                    }
                };

                xhr.send(page.Usability.validator.html);
            }
        }
    }

    function getUrl(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url + ((/\?/).test(url) ? "&" : "?") + (new Date()).getTime(), true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                callback(xhr);
            }
        };
        xhr.send();
    }

    return {
        load: load
    };
})();