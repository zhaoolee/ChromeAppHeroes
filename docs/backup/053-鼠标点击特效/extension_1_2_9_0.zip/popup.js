// mouse click special effects
function localizeHtmlPage()
{
    var objects = document.getElementsByTagName('html');
    for (var j = 0; j < objects.length; j++)
    {
        var obj = objects[j];

        var valStrH = obj.innerHTML.toString();
        var valNewH = valStrH.replace(/__MSG_(\w+)__/g, function(match, v1)
        {
            return v1 ? chrome.i18n.getMessage(v1) : "";
        });

        if(valNewH != valStrH)
        {
            obj.innerHTML = valNewH;
        }
    }
}
localizeHtmlPage();

var color = '#E94F06';
var defaultClickText = '❤';
var clickText = ['OωO', '(๑•́ ∀ •̀๑)', '(๑•́ ₃ •̀๑)', '(๑•̀_•́๑)', '（￣へ￣）', '(╯°口°)╯(┴—┴', '૮( ᵒ̌皿ᵒ̌ )ა', '╮(｡>口<｡)╭', '( ง ᵒ̌皿ᵒ̌)ง⁼³₌₃', '(ꐦ°᷄д°᷅)'];
var defaultSize = 18;

var clickCount=0;
jQuery(document).ready(function($) {
    chrome.storage.sync.get({clickText: ['OωO', '(๑•́ ∀ •̀๑)', '(๑•́ ₃ •̀๑)', '(๑•̀_•́๑)', '（￣へ￣）', '(╯°口°)╯(┴—┴', '૮( ᵒ̌皿ᵒ̌ )ა', '╮(｡>口<｡)╭', '( ง ᵒ̌皿ᵒ̌)ง⁼³₌₃', '(ꐦ°᷄д°᷅)'], defaultClickText: '❤', color: '#E94F06', size: 18}, function(items) {
        clickText = items.clickText;
        color = items.color;
        defaultSize = items.size;
        defaultClickText = items.defaultClickText;
        $('#color').val(color);
        $('#size').val(defaultSize);
        $('#clickText').val(clickText.join('\n'));
        $('#defaultClickText').val(defaultClickText);
    });

    function randomRgb() {
        var R = Math.floor(Math.random() * 255);
        var G = Math.floor(Math.random() * 255);
        var B = Math.floor(Math.random() * 255);
        return 'rgb(' + R + ',' + G + ',' + B + ')';
      }

    $("html").click(function(e) {
        var size = defaultSize;
        var $i;

        if(defaultClickText === ''){
            $i=$("<b></b>").text(clickText[clickCount]);
            size=Math.round(Math.random()*defaultSize+6);
            if(clickCount === clickText.length - 1){
                clickCount = -1;
            }
        }else if(clickCount > 0 && clickCount%10 === 0) {
            $i=$("<b></b>").text(clickText[clickCount/10 - 1]);
            if(clickCount/10 === clickText.length){
                clickCount = -1;
            }
        } else {
            $i=$("<b></b>").text(defaultClickText);
            size=Math.round(Math.random()*defaultSize+6);
        }
        
        clickCount++;
        var x=e.pageX,y=e.pageY;
        $i.css({
            "z-index":9999,
            "top":y-20,
            "left":x,
            "position":"absolute",
            "color":color === 'random' ? randomRgb(): color,
            "font-size":size,
            "-moz-user-select": "none",
            "-webkit-user-select": "none",
            "-ms-user-select": "none"
        });
        $("body").append($i);
        $i.animate(
            {"top":y-180,"opacity":0},
            1500,
            function(){$i.remove();}
        );
        //e.stopPropagation();
    });

    $('#settings-btn').on('click', function() {
        var color = $('#color').val();
        var size = $('#size').val();
        if(size === '' || size < 0){
            size = 0;
        }
        var clickText = $('#clickText').val();
        var defaultClickText = $('#defaultClickText').val();
    
        chrome.storage.sync.set({defaultClickText: defaultClickText, color: color, size: size, clickText: clickText.split('\n')}, function() {
            console.log('success');
            var el = document.querySelector('#success');
            el.style.display = "block";
        });
    });

    $('#default-settings-btn').on('click', function() {
        $('#color').val('#E94F06');
        $('#size').val(18);
        clickText = ['OωO', '(๑•́ ∀ •̀๑)', '(๑•́ ₃ •̀๑)', '(๑•̀_•́๑)', '（￣へ￣）', '(╯°口°)╯(┴—┴', '૮( ᵒ̌皿ᵒ̌ )ა', '╮(｡>口<｡)╭', '( ง ᵒ̌皿ᵒ̌)ง⁼³₌₃', '(ꐦ°᷄д°᷅)']
        $('#clickText').val(clickText.join('\n'));
        $('#defaultClickText').val('❤');
    });

    $('#donate-btn').on('click', function() {
        chrome.tabs.create({url: 'https://www.paypal.me/LYGG'});
    });
  
});
