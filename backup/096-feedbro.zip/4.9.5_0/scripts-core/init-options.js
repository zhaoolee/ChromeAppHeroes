var feedbrooptions = new feedbro.Options();

document.addEventListener('DOMContentLoaded', function () { 
	feedbrooptions.initOptions();
});

