$(document).ready(function() {
	var f = new feedbro.Bookmarks();
	f.init();
});
