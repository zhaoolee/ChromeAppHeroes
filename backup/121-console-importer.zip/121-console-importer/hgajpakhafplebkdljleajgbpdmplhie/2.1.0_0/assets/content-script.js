(()=>{const e=document.createElement("script");e.src=chrome.runtime.getURL("assets/importer.js"),e.type="module",document.body.appendChild(e),document.body.removeChild(e)})();
