Element.prototype.requestFullscreen = () => {};
Element.prototype.exitFullscreen = () => {};
