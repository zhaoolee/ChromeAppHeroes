(function polyfill() {
    const relList = document.createElement("link").relList;
    if (relList && relList.supports && relList.supports("modulepreload")) {
        return;
    }
    for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
        processPreload(link);
    }
    new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.type !== "childList") {
                continue;
            }
            for (const node of mutation.addedNodes) {
                if (node.tagName === "LINK" && node.rel === "modulepreload")
                    processPreload(node);
            }
        }
    }).observe(document, { childList: true, subtree: true });
    function getFetchOpts(link) {
        const fetchOpts = {};
        if (link.integrity) fetchOpts.integrity = link.integrity;
        if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
        if (link.crossOrigin === "use-credentials")
            fetchOpts.credentials = "include";
        else if (link.crossOrigin === "anonymous")
            fetchOpts.credentials = "omit";
        else fetchOpts.credentials = "same-origin";
        return fetchOpts;
    }
    function processPreload(link) {
        if (link.ep) return;
        link.ep = true;
        const fetchOpts = getFetchOpts(link);
        fetch(link.href, fetchOpts);
    }
})();
/**
 * @vue/shared v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function makeMap(str) {
    const map = /* @__PURE__ */ Object.create(null);
    for (const key of str.split(",")) map[key] = 1;
    return (val) => val in map;
}
const EMPTY_OBJ = {};
const EMPTY_ARR = [];
const NOOP = () => {};
const NO = () => false;
const isOn = (key) =>
    key.charCodeAt(0) === 111 &&
    key.charCodeAt(1) === 110 && // uppercase letter
    (key.charCodeAt(2) > 122 || key.charCodeAt(2) < 97);
const isModelListener = (key) => key.startsWith("onUpdate:");
const extend = Object.assign;
const remove = (arr, el) => {
    const i = arr.indexOf(el);
    if (i > -1) {
        arr.splice(i, 1);
    }
};
const hasOwnProperty$1 = Object.prototype.hasOwnProperty;
const hasOwn = (val, key) => hasOwnProperty$1.call(val, key);
const isArray = Array.isArray;
const isMap = (val) => toTypeString(val) === "[object Map]";
const isSet = (val) => toTypeString(val) === "[object Set]";
const isDate = (val) => toTypeString(val) === "[object Date]";
const isFunction = (val) => typeof val === "function";
const isString = (val) => typeof val === "string";
const isSymbol = (val) => typeof val === "symbol";
const isObject = (val) => val !== null && typeof val === "object";
const isPromise$1 = (val) => {
    return (
        (isObject(val) || isFunction(val)) &&
        isFunction(val.then) &&
        isFunction(val.catch)
    );
};
const objectToString = Object.prototype.toString;
const toTypeString = (value) => objectToString.call(value);
const toRawType = (value) => {
    return toTypeString(value).slice(8, -1);
};
const isPlainObject$1 = (val) => toTypeString(val) === "[object Object]";
const isIntegerKey = (key) =>
    isString(key) &&
    key !== "NaN" &&
    key[0] !== "-" &&
    "" + parseInt(key, 10) === key;
const isReservedProp = /* @__PURE__ */ makeMap(
    // the leading comma is intentional so empty string "" is also included
    ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted",
);
const cacheStringFunction = (fn) => {
    const cache = /* @__PURE__ */ Object.create(null);
    return (str) => {
        const hit = cache[str];
        return hit || (cache[str] = fn(str));
    };
};
const camelizeRE = /-(\w)/g;
const camelize = cacheStringFunction((str) => {
    return str.replace(camelizeRE, (_, c) => (c ? c.toUpperCase() : ""));
});
const hyphenateRE = /\B([A-Z])/g;
const hyphenate = cacheStringFunction((str) =>
    str.replace(hyphenateRE, "-$1").toLowerCase(),
);
const capitalize = cacheStringFunction((str) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
});
const toHandlerKey = cacheStringFunction((str) => {
    const s = str ? `on${capitalize(str)}` : ``;
    return s;
});
const hasChanged = (value, oldValue) => !Object.is(value, oldValue);
const invokeArrayFns = (fns, ...arg) => {
    for (let i = 0; i < fns.length; i++) {
        fns[i](...arg);
    }
};
const def = (obj, key, value, writable = false) => {
    Object.defineProperty(obj, key, {
        configurable: true,
        enumerable: false,
        writable,
        value,
    });
};
const looseToNumber = (val) => {
    const n = parseFloat(val);
    return isNaN(n) ? val : n;
};
let _globalThis;
const getGlobalThis = () => {
    return (
        _globalThis ||
        (_globalThis =
            typeof globalThis !== "undefined"
                ? globalThis
                : typeof self !== "undefined"
                  ? self
                  : typeof window !== "undefined"
                    ? window
                    : typeof global !== "undefined"
                      ? global
                      : {})
    );
};
function normalizeStyle(value) {
    if (isArray(value)) {
        const res = {};
        for (let i = 0; i < value.length; i++) {
            const item = value[i];
            const normalized = isString(item)
                ? parseStringStyle(item)
                : normalizeStyle(item);
            if (normalized) {
                for (const key in normalized) {
                    res[key] = normalized[key];
                }
            }
        }
        return res;
    } else if (isString(value) || isObject(value)) {
        return value;
    }
}
const listDelimiterRE = /;(?![^(]*\))/g;
const propertyDelimiterRE = /:([^]+)/;
const styleCommentRE = /\/\*[^]*?\*\//g;
function parseStringStyle(cssText) {
    const ret = {};
    cssText
        .replace(styleCommentRE, "")
        .split(listDelimiterRE)
        .forEach((item) => {
            if (item) {
                const tmp = item.split(propertyDelimiterRE);
                tmp.length > 1 && (ret[tmp[0].trim()] = tmp[1].trim());
            }
        });
    return ret;
}
function normalizeClass(value) {
    let res = "";
    if (isString(value)) {
        res = value;
    } else if (isArray(value)) {
        for (let i = 0; i < value.length; i++) {
            const normalized = normalizeClass(value[i]);
            if (normalized) {
                res += normalized + " ";
            }
        }
    } else if (isObject(value)) {
        for (const name in value) {
            if (value[name]) {
                res += name + " ";
            }
        }
    }
    return res.trim();
}
const specialBooleanAttrs = `itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly`;
const isSpecialBooleanAttr = /* @__PURE__ */ makeMap(specialBooleanAttrs);
function includeBooleanAttr(value) {
    return !!value || value === "";
}
function looseCompareArrays(a, b) {
    if (a.length !== b.length) return false;
    let equal = true;
    for (let i = 0; equal && i < a.length; i++) {
        equal = looseEqual(a[i], b[i]);
    }
    return equal;
}
function looseEqual(a, b) {
    if (a === b) return true;
    let aValidType = isDate(a);
    let bValidType = isDate(b);
    if (aValidType || bValidType) {
        return aValidType && bValidType ? a.getTime() === b.getTime() : false;
    }
    aValidType = isSymbol(a);
    bValidType = isSymbol(b);
    if (aValidType || bValidType) {
        return a === b;
    }
    aValidType = isArray(a);
    bValidType = isArray(b);
    if (aValidType || bValidType) {
        return aValidType && bValidType ? looseCompareArrays(a, b) : false;
    }
    aValidType = isObject(a);
    bValidType = isObject(b);
    if (aValidType || bValidType) {
        if (!aValidType || !bValidType) {
            return false;
        }
        const aKeysCount = Object.keys(a).length;
        const bKeysCount = Object.keys(b).length;
        if (aKeysCount !== bKeysCount) {
            return false;
        }
        for (const key in a) {
            const aHasKey = a.hasOwnProperty(key);
            const bHasKey = b.hasOwnProperty(key);
            if (
                (aHasKey && !bHasKey) ||
                (!aHasKey && bHasKey) ||
                !looseEqual(a[key], b[key])
            ) {
                return false;
            }
        }
    }
    return String(a) === String(b);
}
function looseIndexOf(arr, val) {
    return arr.findIndex((item) => looseEqual(item, val));
}
const isRef$1 = (val) => {
    return !!(val && val["__v_isRef"] === true);
};
const toDisplayString = (val) => {
    return isString(val)
        ? val
        : val == null
          ? ""
          : isArray(val) ||
              (isObject(val) &&
                  (val.toString === objectToString ||
                      !isFunction(val.toString)))
            ? isRef$1(val)
                ? toDisplayString(val.value)
                : JSON.stringify(val, replacer, 2)
            : String(val);
};
const replacer = (_key, val) => {
    if (isRef$1(val)) {
        return replacer(_key, val.value);
    } else if (isMap(val)) {
        return {
            [`Map(${val.size})`]: [...val.entries()].reduce(
                (entries, [key, val2], i) => {
                    entries[stringifySymbol(key, i) + " =>"] = val2;
                    return entries;
                },
                {},
            ),
        };
    } else if (isSet(val)) {
        return {
            [`Set(${val.size})`]: [...val.values()].map((v) =>
                stringifySymbol(v),
            ),
        };
    } else if (isSymbol(val)) {
        return stringifySymbol(val);
    } else if (isObject(val) && !isArray(val) && !isPlainObject$1(val)) {
        return String(val);
    }
    return val;
};
const stringifySymbol = (v, i = "") => {
    var _a;
    return (
        // Symbol.description in es2019+ so we need to cast here to pass
        // the lib: es2016 check
        isSymbol(v) ? `Symbol(${(_a = v.description) != null ? _a : i})` : v
    );
};
/**
 * @vue/reactivity v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
let activeEffectScope;
class EffectScope {
    constructor(detached = false) {
        this.detached = detached;
        this._active = true;
        this.effects = [];
        this.cleanups = [];
        this._isPaused = false;
        this.parent = activeEffectScope;
        if (!detached && activeEffectScope) {
            this.index =
                (
                    activeEffectScope.scopes || (activeEffectScope.scopes = [])
                ).push(this) - 1;
        }
    }
    get active() {
        return this._active;
    }
    pause() {
        if (this._active) {
            this._isPaused = true;
            let i, l;
            if (this.scopes) {
                for (i = 0, l = this.scopes.length; i < l; i++) {
                    this.scopes[i].pause();
                }
            }
            for (i = 0, l = this.effects.length; i < l; i++) {
                this.effects[i].pause();
            }
        }
    }
    /**
     * Resumes the effect scope, including all child scopes and effects.
     */
    resume() {
        if (this._active) {
            if (this._isPaused) {
                this._isPaused = false;
                let i, l;
                if (this.scopes) {
                    for (i = 0, l = this.scopes.length; i < l; i++) {
                        this.scopes[i].resume();
                    }
                }
                for (i = 0, l = this.effects.length; i < l; i++) {
                    this.effects[i].resume();
                }
            }
        }
    }
    run(fn) {
        if (this._active) {
            const currentEffectScope = activeEffectScope;
            try {
                activeEffectScope = this;
                return fn();
            } finally {
                activeEffectScope = currentEffectScope;
            }
        }
    }
    /**
     * This should only be called on non-detached scopes
     * @internal
     */
    on() {
        activeEffectScope = this;
    }
    /**
     * This should only be called on non-detached scopes
     * @internal
     */
    off() {
        activeEffectScope = this.parent;
    }
    stop(fromParent) {
        if (this._active) {
            this._active = false;
            let i, l;
            for (i = 0, l = this.effects.length; i < l; i++) {
                this.effects[i].stop();
            }
            this.effects.length = 0;
            for (i = 0, l = this.cleanups.length; i < l; i++) {
                this.cleanups[i]();
            }
            this.cleanups.length = 0;
            if (this.scopes) {
                for (i = 0, l = this.scopes.length; i < l; i++) {
                    this.scopes[i].stop(true);
                }
                this.scopes.length = 0;
            }
            if (!this.detached && this.parent && !fromParent) {
                const last = this.parent.scopes.pop();
                if (last && last !== this) {
                    this.parent.scopes[this.index] = last;
                    last.index = this.index;
                }
            }
            this.parent = void 0;
        }
    }
}
function effectScope(detached) {
    return new EffectScope(detached);
}
function getCurrentScope() {
    return activeEffectScope;
}
function onScopeDispose(fn, failSilently = false) {
    if (activeEffectScope) {
        activeEffectScope.cleanups.push(fn);
    }
}
let activeSub;
const pausedQueueEffects = /* @__PURE__ */ new WeakSet();
class ReactiveEffect {
    constructor(fn) {
        this.fn = fn;
        this.deps = void 0;
        this.depsTail = void 0;
        this.flags = 1 | 4;
        this.next = void 0;
        this.cleanup = void 0;
        this.scheduler = void 0;
        if (activeEffectScope && activeEffectScope.active) {
            activeEffectScope.effects.push(this);
        }
    }
    pause() {
        this.flags |= 64;
    }
    resume() {
        if (this.flags & 64) {
            this.flags &= -65;
            if (pausedQueueEffects.has(this)) {
                pausedQueueEffects.delete(this);
                this.trigger();
            }
        }
    }
    /**
     * @internal
     */
    notify() {
        if (this.flags & 2 && !(this.flags & 32)) {
            return;
        }
        if (!(this.flags & 8)) {
            batch(this);
        }
    }
    run() {
        if (!(this.flags & 1)) {
            return this.fn();
        }
        this.flags |= 2;
        cleanupEffect(this);
        prepareDeps(this);
        const prevEffect = activeSub;
        const prevShouldTrack = shouldTrack;
        activeSub = this;
        shouldTrack = true;
        try {
            return this.fn();
        } finally {
            cleanupDeps(this);
            activeSub = prevEffect;
            shouldTrack = prevShouldTrack;
            this.flags &= -3;
        }
    }
    stop() {
        if (this.flags & 1) {
            for (let link = this.deps; link; link = link.nextDep) {
                removeSub(link);
            }
            this.deps = this.depsTail = void 0;
            cleanupEffect(this);
            this.onStop && this.onStop();
            this.flags &= -2;
        }
    }
    trigger() {
        if (this.flags & 64) {
            pausedQueueEffects.add(this);
        } else if (this.scheduler) {
            this.scheduler();
        } else {
            this.runIfDirty();
        }
    }
    /**
     * @internal
     */
    runIfDirty() {
        if (isDirty(this)) {
            this.run();
        }
    }
    get dirty() {
        return isDirty(this);
    }
}
let batchDepth = 0;
let batchedSub;
let batchedComputed;
function batch(sub, isComputed2 = false) {
    sub.flags |= 8;
    if (isComputed2) {
        sub.next = batchedComputed;
        batchedComputed = sub;
        return;
    }
    sub.next = batchedSub;
    batchedSub = sub;
}
function startBatch() {
    batchDepth++;
}
function endBatch() {
    if (--batchDepth > 0) {
        return;
    }
    if (batchedComputed) {
        let e = batchedComputed;
        batchedComputed = void 0;
        while (e) {
            const next = e.next;
            e.next = void 0;
            e.flags &= -9;
            e = next;
        }
    }
    let error;
    while (batchedSub) {
        let e = batchedSub;
        batchedSub = void 0;
        while (e) {
            const next = e.next;
            e.next = void 0;
            e.flags &= -9;
            if (e.flags & 1) {
                try {
                    e.trigger();
                } catch (err) {
                    if (!error) error = err;
                }
            }
            e = next;
        }
    }
    if (error) throw error;
}
function prepareDeps(sub) {
    for (let link = sub.deps; link; link = link.nextDep) {
        link.version = -1;
        link.prevActiveLink = link.dep.activeLink;
        link.dep.activeLink = link;
    }
}
function cleanupDeps(sub) {
    let head;
    let tail = sub.depsTail;
    let link = tail;
    while (link) {
        const prev = link.prevDep;
        if (link.version === -1) {
            if (link === tail) tail = prev;
            removeSub(link);
            removeDep(link);
        } else {
            head = link;
        }
        link.dep.activeLink = link.prevActiveLink;
        link.prevActiveLink = void 0;
        link = prev;
    }
    sub.deps = head;
    sub.depsTail = tail;
}
function isDirty(sub) {
    for (let link = sub.deps; link; link = link.nextDep) {
        if (
            link.dep.version !== link.version ||
            (link.dep.computed &&
                (refreshComputed(link.dep.computed) ||
                    link.dep.version !== link.version))
        ) {
            return true;
        }
    }
    if (sub._dirty) {
        return true;
    }
    return false;
}
function refreshComputed(computed2) {
    if (computed2.flags & 4 && !(computed2.flags & 16)) {
        return;
    }
    computed2.flags &= -17;
    if (computed2.globalVersion === globalVersion) {
        return;
    }
    computed2.globalVersion = globalVersion;
    const dep = computed2.dep;
    computed2.flags |= 2;
    if (
        dep.version > 0 &&
        !computed2.isSSR &&
        computed2.deps &&
        !isDirty(computed2)
    ) {
        computed2.flags &= -3;
        return;
    }
    const prevSub = activeSub;
    const prevShouldTrack = shouldTrack;
    activeSub = computed2;
    shouldTrack = true;
    try {
        prepareDeps(computed2);
        const value = computed2.fn(computed2._value);
        if (dep.version === 0 || hasChanged(value, computed2._value)) {
            computed2._value = value;
            dep.version++;
        }
    } catch (err) {
        dep.version++;
        throw err;
    } finally {
        activeSub = prevSub;
        shouldTrack = prevShouldTrack;
        cleanupDeps(computed2);
        computed2.flags &= -3;
    }
}
function removeSub(link, soft = false) {
    const { dep, prevSub, nextSub } = link;
    if (prevSub) {
        prevSub.nextSub = nextSub;
        link.prevSub = void 0;
    }
    if (nextSub) {
        nextSub.prevSub = prevSub;
        link.nextSub = void 0;
    }
    if (dep.subs === link) {
        dep.subs = prevSub;
        if (!prevSub && dep.computed) {
            dep.computed.flags &= -5;
            for (let l = dep.computed.deps; l; l = l.nextDep) {
                removeSub(l, true);
            }
        }
    }
    if (!soft && !--dep.sc && dep.map) {
        dep.map.delete(dep.key);
    }
}
function removeDep(link) {
    const { prevDep, nextDep } = link;
    if (prevDep) {
        prevDep.nextDep = nextDep;
        link.prevDep = void 0;
    }
    if (nextDep) {
        nextDep.prevDep = prevDep;
        link.nextDep = void 0;
    }
}
let shouldTrack = true;
const trackStack = [];
function pauseTracking() {
    trackStack.push(shouldTrack);
    shouldTrack = false;
}
function resetTracking() {
    const last = trackStack.pop();
    shouldTrack = last === void 0 ? true : last;
}
function cleanupEffect(e) {
    const { cleanup } = e;
    e.cleanup = void 0;
    if (cleanup) {
        const prevSub = activeSub;
        activeSub = void 0;
        try {
            cleanup();
        } finally {
            activeSub = prevSub;
        }
    }
}
let globalVersion = 0;
class Link {
    constructor(sub, dep) {
        this.sub = sub;
        this.dep = dep;
        this.version = dep.version;
        this.nextDep =
            this.prevDep =
            this.nextSub =
            this.prevSub =
            this.prevActiveLink =
                void 0;
    }
}
class Dep {
    constructor(computed2) {
        this.computed = computed2;
        this.version = 0;
        this.activeLink = void 0;
        this.subs = void 0;
        this.map = void 0;
        this.key = void 0;
        this.sc = 0;
    }
    track(debugInfo) {
        if (!activeSub || !shouldTrack || activeSub === this.computed) {
            return;
        }
        let link = this.activeLink;
        if (link === void 0 || link.sub !== activeSub) {
            link = this.activeLink = new Link(activeSub, this);
            if (!activeSub.deps) {
                activeSub.deps = activeSub.depsTail = link;
            } else {
                link.prevDep = activeSub.depsTail;
                activeSub.depsTail.nextDep = link;
                activeSub.depsTail = link;
            }
            addSub(link);
        } else if (link.version === -1) {
            link.version = this.version;
            if (link.nextDep) {
                const next = link.nextDep;
                next.prevDep = link.prevDep;
                if (link.prevDep) {
                    link.prevDep.nextDep = next;
                }
                link.prevDep = activeSub.depsTail;
                link.nextDep = void 0;
                activeSub.depsTail.nextDep = link;
                activeSub.depsTail = link;
                if (activeSub.deps === link) {
                    activeSub.deps = next;
                }
            }
        }
        return link;
    }
    trigger(debugInfo) {
        this.version++;
        globalVersion++;
        this.notify(debugInfo);
    }
    notify(debugInfo) {
        startBatch();
        try {
            if (false);
            for (let link = this.subs; link; link = link.prevSub) {
                if (link.sub.notify()) {
                    link.sub.dep.notify();
                }
            }
        } finally {
            endBatch();
        }
    }
}
function addSub(link) {
    link.dep.sc++;
    if (link.sub.flags & 4) {
        const computed2 = link.dep.computed;
        if (computed2 && !link.dep.subs) {
            computed2.flags |= 4 | 16;
            for (let l = computed2.deps; l; l = l.nextDep) {
                addSub(l);
            }
        }
        const currentTail = link.dep.subs;
        if (currentTail !== link) {
            link.prevSub = currentTail;
            if (currentTail) currentTail.nextSub = link;
        }
        link.dep.subs = link;
    }
}
const targetMap = /* @__PURE__ */ new WeakMap();
const ITERATE_KEY = Symbol("");
const MAP_KEY_ITERATE_KEY = Symbol("");
const ARRAY_ITERATE_KEY = Symbol("");
function track(target, type, key) {
    if (shouldTrack && activeSub) {
        let depsMap = targetMap.get(target);
        if (!depsMap) {
            targetMap.set(target, (depsMap = /* @__PURE__ */ new Map()));
        }
        let dep = depsMap.get(key);
        if (!dep) {
            depsMap.set(key, (dep = new Dep()));
            dep.map = depsMap;
            dep.key = key;
        }
        {
            dep.track();
        }
    }
}
function trigger(target, type, key, newValue, oldValue, oldTarget) {
    const depsMap = targetMap.get(target);
    if (!depsMap) {
        globalVersion++;
        return;
    }
    const run = (dep) => {
        if (dep) {
            {
                dep.trigger();
            }
        }
    };
    startBatch();
    if (type === "clear") {
        depsMap.forEach(run);
    } else {
        const targetIsArray = isArray(target);
        const isArrayIndex = targetIsArray && isIntegerKey(key);
        if (targetIsArray && key === "length") {
            const newLength = Number(newValue);
            depsMap.forEach((dep, key2) => {
                if (
                    key2 === "length" ||
                    key2 === ARRAY_ITERATE_KEY ||
                    (!isSymbol(key2) && key2 >= newLength)
                ) {
                    run(dep);
                }
            });
        } else {
            if (key !== void 0 || depsMap.has(void 0)) {
                run(depsMap.get(key));
            }
            if (isArrayIndex) {
                run(depsMap.get(ARRAY_ITERATE_KEY));
            }
            switch (type) {
                case "add":
                    if (!targetIsArray) {
                        run(depsMap.get(ITERATE_KEY));
                        if (isMap(target)) {
                            run(depsMap.get(MAP_KEY_ITERATE_KEY));
                        }
                    } else if (isArrayIndex) {
                        run(depsMap.get("length"));
                    }
                    break;
                case "delete":
                    if (!targetIsArray) {
                        run(depsMap.get(ITERATE_KEY));
                        if (isMap(target)) {
                            run(depsMap.get(MAP_KEY_ITERATE_KEY));
                        }
                    }
                    break;
                case "set":
                    if (isMap(target)) {
                        run(depsMap.get(ITERATE_KEY));
                    }
                    break;
            }
        }
    }
    endBatch();
}
function getDepFromReactive(object, key) {
    const depMap = targetMap.get(object);
    return depMap && depMap.get(key);
}
function reactiveReadArray(array) {
    const raw = toRaw(array);
    if (raw === array) return raw;
    track(raw, "iterate", ARRAY_ITERATE_KEY);
    return isShallow(array) ? raw : raw.map(toReactive);
}
function shallowReadArray(arr) {
    track((arr = toRaw(arr)), "iterate", ARRAY_ITERATE_KEY);
    return arr;
}
const arrayInstrumentations = {
    __proto__: null,
    [Symbol.iterator]() {
        return iterator(this, Symbol.iterator, toReactive);
    },
    concat(...args) {
        return reactiveReadArray(this).concat(
            ...args.map((x) => (isArray(x) ? reactiveReadArray(x) : x)),
        );
    },
    entries() {
        return iterator(this, "entries", (value) => {
            value[1] = toReactive(value[1]);
            return value;
        });
    },
    every(fn, thisArg) {
        return apply(this, "every", fn, thisArg, void 0, arguments);
    },
    filter(fn, thisArg) {
        return apply(
            this,
            "filter",
            fn,
            thisArg,
            (v) => v.map(toReactive),
            arguments,
        );
    },
    find(fn, thisArg) {
        return apply(this, "find", fn, thisArg, toReactive, arguments);
    },
    findIndex(fn, thisArg) {
        return apply(this, "findIndex", fn, thisArg, void 0, arguments);
    },
    findLast(fn, thisArg) {
        return apply(this, "findLast", fn, thisArg, toReactive, arguments);
    },
    findLastIndex(fn, thisArg) {
        return apply(this, "findLastIndex", fn, thisArg, void 0, arguments);
    },
    // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
    forEach(fn, thisArg) {
        return apply(this, "forEach", fn, thisArg, void 0, arguments);
    },
    includes(...args) {
        return searchProxy(this, "includes", args);
    },
    indexOf(...args) {
        return searchProxy(this, "indexOf", args);
    },
    join(separator) {
        return reactiveReadArray(this).join(separator);
    },
    // keys() iterator only reads `length`, no optimisation required
    lastIndexOf(...args) {
        return searchProxy(this, "lastIndexOf", args);
    },
    map(fn, thisArg) {
        return apply(this, "map", fn, thisArg, void 0, arguments);
    },
    pop() {
        return noTracking(this, "pop");
    },
    push(...args) {
        return noTracking(this, "push", args);
    },
    reduce(fn, ...args) {
        return reduce(this, "reduce", fn, args);
    },
    reduceRight(fn, ...args) {
        return reduce(this, "reduceRight", fn, args);
    },
    shift() {
        return noTracking(this, "shift");
    },
    // slice could use ARRAY_ITERATE but also seems to beg for range tracking
    some(fn, thisArg) {
        return apply(this, "some", fn, thisArg, void 0, arguments);
    },
    splice(...args) {
        return noTracking(this, "splice", args);
    },
    toReversed() {
        return reactiveReadArray(this).toReversed();
    },
    toSorted(comparer) {
        return reactiveReadArray(this).toSorted(comparer);
    },
    toSpliced(...args) {
        return reactiveReadArray(this).toSpliced(...args);
    },
    unshift(...args) {
        return noTracking(this, "unshift", args);
    },
    values() {
        return iterator(this, "values", toReactive);
    },
};
function iterator(self2, method, wrapValue) {
    const arr = shallowReadArray(self2);
    const iter = arr[method]();
    if (arr !== self2 && !isShallow(self2)) {
        iter._next = iter.next;
        iter.next = () => {
            const result = iter._next();
            if (result.value) {
                result.value = wrapValue(result.value);
            }
            return result;
        };
    }
    return iter;
}
const arrayProto = Array.prototype;
function apply(self2, method, fn, thisArg, wrappedRetFn, args) {
    const arr = shallowReadArray(self2);
    const needsWrap = arr !== self2 && !isShallow(self2);
    const methodFn = arr[method];
    if (methodFn !== arrayProto[method]) {
        const result2 = methodFn.apply(self2, args);
        return needsWrap ? toReactive(result2) : result2;
    }
    let wrappedFn = fn;
    if (arr !== self2) {
        if (needsWrap) {
            wrappedFn = function (item, index) {
                return fn.call(this, toReactive(item), index, self2);
            };
        } else if (fn.length > 2) {
            wrappedFn = function (item, index) {
                return fn.call(this, item, index, self2);
            };
        }
    }
    const result = methodFn.call(arr, wrappedFn, thisArg);
    return needsWrap && wrappedRetFn ? wrappedRetFn(result) : result;
}
function reduce(self2, method, fn, args) {
    const arr = shallowReadArray(self2);
    let wrappedFn = fn;
    if (arr !== self2) {
        if (!isShallow(self2)) {
            wrappedFn = function (acc, item, index) {
                return fn.call(this, acc, toReactive(item), index, self2);
            };
        } else if (fn.length > 3) {
            wrappedFn = function (acc, item, index) {
                return fn.call(this, acc, item, index, self2);
            };
        }
    }
    return arr[method](wrappedFn, ...args);
}
function searchProxy(self2, method, args) {
    const arr = toRaw(self2);
    track(arr, "iterate", ARRAY_ITERATE_KEY);
    const res = arr[method](...args);
    if ((res === -1 || res === false) && isProxy(args[0])) {
        args[0] = toRaw(args[0]);
        return arr[method](...args);
    }
    return res;
}
function noTracking(self2, method, args = []) {
    pauseTracking();
    startBatch();
    const res = toRaw(self2)[method].apply(self2, args);
    endBatch();
    resetTracking();
    return res;
}
const isNonTrackableKeys = /* @__PURE__ */ makeMap(
    `__proto__,__v_isRef,__isVue`,
);
const builtInSymbols = new Set(
    /* @__PURE__ */ Object.getOwnPropertyNames(Symbol)
        .filter((key) => key !== "arguments" && key !== "caller")
        .map((key) => Symbol[key])
        .filter(isSymbol),
);
function hasOwnProperty(key) {
    if (!isSymbol(key)) key = String(key);
    const obj = toRaw(this);
    track(obj, "has", key);
    return obj.hasOwnProperty(key);
}
class BaseReactiveHandler {
    constructor(_isReadonly = false, _isShallow = false) {
        this._isReadonly = _isReadonly;
        this._isShallow = _isShallow;
    }
    get(target, key, receiver) {
        if (key === "__v_skip") return target["__v_skip"];
        const isReadonly2 = this._isReadonly,
            isShallow2 = this._isShallow;
        if (key === "__v_isReactive") {
            return !isReadonly2;
        } else if (key === "__v_isReadonly") {
            return isReadonly2;
        } else if (key === "__v_isShallow") {
            return isShallow2;
        } else if (key === "__v_raw") {
            if (
                receiver ===
                    (isReadonly2
                        ? isShallow2
                            ? shallowReadonlyMap
                            : readonlyMap
                        : isShallow2
                          ? shallowReactiveMap
                          : reactiveMap
                    ).get(target) || // receiver is not the reactive proxy, but has the same prototype
                // this means the receiver is a user proxy of the reactive proxy
                Object.getPrototypeOf(target) ===
                    Object.getPrototypeOf(receiver)
            ) {
                return target;
            }
            return;
        }
        const targetIsArray = isArray(target);
        if (!isReadonly2) {
            let fn;
            if (targetIsArray && (fn = arrayInstrumentations[key])) {
                return fn;
            }
            if (key === "hasOwnProperty") {
                return hasOwnProperty;
            }
        }
        const res = Reflect.get(
            target,
            key,
            // if this is a proxy wrapping a ref, return methods using the raw ref
            // as receiver so that we don't have to call `toRaw` on the ref in all
            // its class methods
            isRef(target) ? target : receiver,
        );
        if (isSymbol(key) ? builtInSymbols.has(key) : isNonTrackableKeys(key)) {
            return res;
        }
        if (!isReadonly2) {
            track(target, "get", key);
        }
        if (isShallow2) {
            return res;
        }
        if (isRef(res)) {
            return targetIsArray && isIntegerKey(key) ? res : res.value;
        }
        if (isObject(res)) {
            return isReadonly2 ? readonly(res) : reactive(res);
        }
        return res;
    }
}
class MutableReactiveHandler extends BaseReactiveHandler {
    constructor(isShallow2 = false) {
        super(false, isShallow2);
    }
    set(target, key, value, receiver) {
        let oldValue = target[key];
        if (!this._isShallow) {
            const isOldValueReadonly = isReadonly(oldValue);
            if (!isShallow(value) && !isReadonly(value)) {
                oldValue = toRaw(oldValue);
                value = toRaw(value);
            }
            if (!isArray(target) && isRef(oldValue) && !isRef(value)) {
                if (isOldValueReadonly) {
                    return false;
                } else {
                    oldValue.value = value;
                    return true;
                }
            }
        }
        const hadKey =
            isArray(target) && isIntegerKey(key)
                ? Number(key) < target.length
                : hasOwn(target, key);
        const result = Reflect.set(
            target,
            key,
            value,
            isRef(target) ? target : receiver,
        );
        if (target === toRaw(receiver)) {
            if (!hadKey) {
                trigger(target, "add", key, value);
            } else if (hasChanged(value, oldValue)) {
                trigger(target, "set", key, value);
            }
        }
        return result;
    }
    deleteProperty(target, key) {
        const hadKey = hasOwn(target, key);
        target[key];
        const result = Reflect.deleteProperty(target, key);
        if (result && hadKey) {
            trigger(target, "delete", key, void 0);
        }
        return result;
    }
    has(target, key) {
        const result = Reflect.has(target, key);
        if (!isSymbol(key) || !builtInSymbols.has(key)) {
            track(target, "has", key);
        }
        return result;
    }
    ownKeys(target) {
        track(target, "iterate", isArray(target) ? "length" : ITERATE_KEY);
        return Reflect.ownKeys(target);
    }
}
class ReadonlyReactiveHandler extends BaseReactiveHandler {
    constructor(isShallow2 = false) {
        super(true, isShallow2);
    }
    set(target, key) {
        return true;
    }
    deleteProperty(target, key) {
        return true;
    }
}
const mutableHandlers = /* @__PURE__ */ new MutableReactiveHandler();
const readonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler();
const shallowReactiveHandlers = /* @__PURE__ */ new MutableReactiveHandler(
    true,
);
const shallowReadonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler(
    true,
);
const toShallow = (value) => value;
const getProto = (v) => Reflect.getPrototypeOf(v);
function createIterableMethod(method, isReadonly2, isShallow2) {
    return function (...args) {
        const target = this["__v_raw"];
        const rawTarget = toRaw(target);
        const targetIsMap = isMap(rawTarget);
        const isPair =
            method === "entries" || (method === Symbol.iterator && targetIsMap);
        const isKeyOnly = method === "keys" && targetIsMap;
        const innerIterator = target[method](...args);
        const wrap = isShallow2
            ? toShallow
            : isReadonly2
              ? toReadonly
              : toReactive;
        !isReadonly2 &&
            track(
                rawTarget,
                "iterate",
                isKeyOnly ? MAP_KEY_ITERATE_KEY : ITERATE_KEY,
            );
        return {
            // iterator protocol
            next() {
                const { value, done } = innerIterator.next();
                return done
                    ? { value, done }
                    : {
                          value: isPair
                              ? [wrap(value[0]), wrap(value[1])]
                              : wrap(value),
                          done,
                      };
            },
            // iterable protocol
            [Symbol.iterator]() {
                return this;
            },
        };
    };
}
function createReadonlyMethod(type) {
    return function (...args) {
        return type === "delete" ? false : type === "clear" ? void 0 : this;
    };
}
function createInstrumentations(readonly2, shallow) {
    const instrumentations = {
        get(key) {
            const target = this["__v_raw"];
            const rawTarget = toRaw(target);
            const rawKey = toRaw(key);
            if (!readonly2) {
                if (hasChanged(key, rawKey)) {
                    track(rawTarget, "get", key);
                }
                track(rawTarget, "get", rawKey);
            }
            const { has } = getProto(rawTarget);
            const wrap = shallow
                ? toShallow
                : readonly2
                  ? toReadonly
                  : toReactive;
            if (has.call(rawTarget, key)) {
                return wrap(target.get(key));
            } else if (has.call(rawTarget, rawKey)) {
                return wrap(target.get(rawKey));
            } else if (target !== rawTarget) {
                target.get(key);
            }
        },
        get size() {
            const target = this["__v_raw"];
            !readonly2 && track(toRaw(target), "iterate", ITERATE_KEY);
            return Reflect.get(target, "size", target);
        },
        has(key) {
            const target = this["__v_raw"];
            const rawTarget = toRaw(target);
            const rawKey = toRaw(key);
            if (!readonly2) {
                if (hasChanged(key, rawKey)) {
                    track(rawTarget, "has", key);
                }
                track(rawTarget, "has", rawKey);
            }
            return key === rawKey
                ? target.has(key)
                : target.has(key) || target.has(rawKey);
        },
        forEach(callback, thisArg) {
            const observed = this;
            const target = observed["__v_raw"];
            const rawTarget = toRaw(target);
            const wrap = shallow
                ? toShallow
                : readonly2
                  ? toReadonly
                  : toReactive;
            !readonly2 && track(rawTarget, "iterate", ITERATE_KEY);
            return target.forEach((value, key) => {
                return callback.call(thisArg, wrap(value), wrap(key), observed);
            });
        },
    };
    extend(
        instrumentations,
        readonly2
            ? {
                  add: createReadonlyMethod("add"),
                  set: createReadonlyMethod("set"),
                  delete: createReadonlyMethod("delete"),
                  clear: createReadonlyMethod("clear"),
              }
            : {
                  add(value) {
                      if (!shallow && !isShallow(value) && !isReadonly(value)) {
                          value = toRaw(value);
                      }
                      const target = toRaw(this);
                      const proto = getProto(target);
                      const hadKey = proto.has.call(target, value);
                      if (!hadKey) {
                          target.add(value);
                          trigger(target, "add", value, value);
                      }
                      return this;
                  },
                  set(key, value) {
                      if (!shallow && !isShallow(value) && !isReadonly(value)) {
                          value = toRaw(value);
                      }
                      const target = toRaw(this);
                      const { has, get: get2 } = getProto(target);
                      let hadKey = has.call(target, key);
                      if (!hadKey) {
                          key = toRaw(key);
                          hadKey = has.call(target, key);
                      }
                      const oldValue = get2.call(target, key);
                      target.set(key, value);
                      if (!hadKey) {
                          trigger(target, "add", key, value);
                      } else if (hasChanged(value, oldValue)) {
                          trigger(target, "set", key, value);
                      }
                      return this;
                  },
                  delete(key) {
                      const target = toRaw(this);
                      const { has, get: get2 } = getProto(target);
                      let hadKey = has.call(target, key);
                      if (!hadKey) {
                          key = toRaw(key);
                          hadKey = has.call(target, key);
                      }
                      get2 ? get2.call(target, key) : void 0;
                      const result = target.delete(key);
                      if (hadKey) {
                          trigger(target, "delete", key, void 0);
                      }
                      return result;
                  },
                  clear() {
                      const target = toRaw(this);
                      const hadItems = target.size !== 0;
                      const result = target.clear();
                      if (hadItems) {
                          trigger(target, "clear", void 0, void 0);
                      }
                      return result;
                  },
              },
    );
    const iteratorMethods = ["keys", "values", "entries", Symbol.iterator];
    iteratorMethods.forEach((method) => {
        instrumentations[method] = createIterableMethod(
            method,
            readonly2,
            shallow,
        );
    });
    return instrumentations;
}
function createInstrumentationGetter(isReadonly2, shallow) {
    const instrumentations = createInstrumentations(isReadonly2, shallow);
    return (target, key, receiver) => {
        if (key === "__v_isReactive") {
            return !isReadonly2;
        } else if (key === "__v_isReadonly") {
            return isReadonly2;
        } else if (key === "__v_raw") {
            return target;
        }
        return Reflect.get(
            hasOwn(instrumentations, key) && key in target
                ? instrumentations
                : target,
            key,
            receiver,
        );
    };
}
const mutableCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(false, false),
};
const shallowCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(false, true),
};
const readonlyCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(true, false),
};
const shallowReadonlyCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(true, true),
};
const reactiveMap = /* @__PURE__ */ new WeakMap();
const shallowReactiveMap = /* @__PURE__ */ new WeakMap();
const readonlyMap = /* @__PURE__ */ new WeakMap();
const shallowReadonlyMap = /* @__PURE__ */ new WeakMap();
function targetTypeMap(rawType) {
    switch (rawType) {
        case "Object":
        case "Array":
            return 1;
        case "Map":
        case "Set":
        case "WeakMap":
        case "WeakSet":
            return 2;
        default:
            return 0;
    }
}
function getTargetType(value) {
    return value["__v_skip"] || !Object.isExtensible(value)
        ? 0
        : targetTypeMap(toRawType(value));
}
function reactive(target) {
    if (isReadonly(target)) {
        return target;
    }
    return createReactiveObject(
        target,
        false,
        mutableHandlers,
        mutableCollectionHandlers,
        reactiveMap,
    );
}
function shallowReactive(target) {
    return createReactiveObject(
        target,
        false,
        shallowReactiveHandlers,
        shallowCollectionHandlers,
        shallowReactiveMap,
    );
}
function readonly(target) {
    return createReactiveObject(
        target,
        true,
        readonlyHandlers,
        readonlyCollectionHandlers,
        readonlyMap,
    );
}
function shallowReadonly(target) {
    return createReactiveObject(
        target,
        true,
        shallowReadonlyHandlers,
        shallowReadonlyCollectionHandlers,
        shallowReadonlyMap,
    );
}
function createReactiveObject(
    target,
    isReadonly2,
    baseHandlers,
    collectionHandlers,
    proxyMap,
) {
    if (!isObject(target)) {
        return target;
    }
    if (target["__v_raw"] && !(isReadonly2 && target["__v_isReactive"])) {
        return target;
    }
    const existingProxy = proxyMap.get(target);
    if (existingProxy) {
        return existingProxy;
    }
    const targetType = getTargetType(target);
    if (targetType === 0) {
        return target;
    }
    const proxy = new Proxy(
        target,
        targetType === 2 ? collectionHandlers : baseHandlers,
    );
    proxyMap.set(target, proxy);
    return proxy;
}
function isReactive(value) {
    if (isReadonly(value)) {
        return isReactive(value["__v_raw"]);
    }
    return !!(value && value["__v_isReactive"]);
}
function isReadonly(value) {
    return !!(value && value["__v_isReadonly"]);
}
function isShallow(value) {
    return !!(value && value["__v_isShallow"]);
}
function isProxy(value) {
    return value ? !!value["__v_raw"] : false;
}
function toRaw(observed) {
    const raw = observed && observed["__v_raw"];
    return raw ? toRaw(raw) : observed;
}
function markRaw(value) {
    if (!hasOwn(value, "__v_skip") && Object.isExtensible(value)) {
        def(value, "__v_skip", true);
    }
    return value;
}
const toReactive = (value) => (isObject(value) ? reactive(value) : value);
const toReadonly = (value) => (isObject(value) ? readonly(value) : value);
function isRef(r) {
    return r ? r["__v_isRef"] === true : false;
}
function ref(value) {
    return createRef(value, false);
}
function createRef(rawValue, shallow) {
    if (isRef(rawValue)) {
        return rawValue;
    }
    return new RefImpl(rawValue, shallow);
}
class RefImpl {
    constructor(value, isShallow2) {
        this.dep = new Dep();
        this["__v_isRef"] = true;
        this["__v_isShallow"] = false;
        this._rawValue = isShallow2 ? value : toRaw(value);
        this._value = isShallow2 ? value : toReactive(value);
        this["__v_isShallow"] = isShallow2;
    }
    get value() {
        {
            this.dep.track();
        }
        return this._value;
    }
    set value(newValue) {
        const oldValue = this._rawValue;
        const useDirectValue =
            this["__v_isShallow"] ||
            isShallow(newValue) ||
            isReadonly(newValue);
        newValue = useDirectValue ? newValue : toRaw(newValue);
        if (hasChanged(newValue, oldValue)) {
            this._rawValue = newValue;
            this._value = useDirectValue ? newValue : toReactive(newValue);
            {
                this.dep.trigger();
            }
        }
    }
}
function unref(ref2) {
    return isRef(ref2) ? ref2.value : ref2;
}
const shallowUnwrapHandlers = {
    get: (target, key, receiver) =>
        key === "__v_raw" ? target : unref(Reflect.get(target, key, receiver)),
    set: (target, key, value, receiver) => {
        const oldValue = target[key];
        if (isRef(oldValue) && !isRef(value)) {
            oldValue.value = value;
            return true;
        } else {
            return Reflect.set(target, key, value, receiver);
        }
    },
};
function proxyRefs(objectWithRefs) {
    return isReactive(objectWithRefs)
        ? objectWithRefs
        : new Proxy(objectWithRefs, shallowUnwrapHandlers);
}
function toRefs(object) {
    const ret = isArray(object) ? new Array(object.length) : {};
    for (const key in object) {
        ret[key] = propertyToRef(object, key);
    }
    return ret;
}
class ObjectRefImpl {
    constructor(_object, _key, _defaultValue) {
        this._object = _object;
        this._key = _key;
        this._defaultValue = _defaultValue;
        this["__v_isRef"] = true;
        this._value = void 0;
    }
    get value() {
        const val = this._object[this._key];
        return (this._value = val === void 0 ? this._defaultValue : val);
    }
    set value(newVal) {
        this._object[this._key] = newVal;
    }
    get dep() {
        return getDepFromReactive(toRaw(this._object), this._key);
    }
}
function propertyToRef(source, key, defaultValue) {
    const val = source[key];
    return isRef(val) ? val : new ObjectRefImpl(source, key, defaultValue);
}
class ComputedRefImpl {
    constructor(fn, setter, isSSR) {
        this.fn = fn;
        this.setter = setter;
        this._value = void 0;
        this.dep = new Dep(this);
        this.__v_isRef = true;
        this.deps = void 0;
        this.depsTail = void 0;
        this.flags = 16;
        this.globalVersion = globalVersion - 1;
        this.next = void 0;
        this.effect = this;
        this["__v_isReadonly"] = !setter;
        this.isSSR = isSSR;
    }
    /**
     * @internal
     */
    notify() {
        this.flags |= 16;
        if (
            !(this.flags & 8) && // avoid infinite self recursion
            activeSub !== this
        ) {
            batch(this, true);
            return true;
        }
    }
    get value() {
        const link = this.dep.track();
        refreshComputed(this);
        if (link) {
            link.version = this.dep.version;
        }
        return this._value;
    }
    set value(newValue) {
        if (this.setter) {
            this.setter(newValue);
        }
    }
}
function computed$1(getterOrOptions, debugOptions, isSSR = false) {
    let getter;
    let setter;
    if (isFunction(getterOrOptions)) {
        getter = getterOrOptions;
    } else {
        getter = getterOrOptions.get;
        setter = getterOrOptions.set;
    }
    const cRef = new ComputedRefImpl(getter, setter, isSSR);
    return cRef;
}
const INITIAL_WATCHER_VALUE = {};
const cleanupMap = /* @__PURE__ */ new WeakMap();
let activeWatcher = void 0;
function onWatcherCleanup(
    cleanupFn,
    failSilently = false,
    owner = activeWatcher,
) {
    if (owner) {
        let cleanups = cleanupMap.get(owner);
        if (!cleanups) cleanupMap.set(owner, (cleanups = []));
        cleanups.push(cleanupFn);
    }
}
function watch$1(source, cb, options = EMPTY_OBJ) {
    const { immediate, deep, once, scheduler, augmentJob, call } = options;
    const reactiveGetter = (source2) => {
        if (deep) return source2;
        if (isShallow(source2) || deep === false || deep === 0)
            return traverse(source2, 1);
        return traverse(source2);
    };
    let effect2;
    let getter;
    let cleanup;
    let boundCleanup;
    let forceTrigger = false;
    let isMultiSource = false;
    if (isRef(source)) {
        getter = () => source.value;
        forceTrigger = isShallow(source);
    } else if (isReactive(source)) {
        getter = () => reactiveGetter(source);
        forceTrigger = true;
    } else if (isArray(source)) {
        isMultiSource = true;
        forceTrigger = source.some((s) => isReactive(s) || isShallow(s));
        getter = () =>
            source.map((s) => {
                if (isRef(s)) {
                    return s.value;
                } else if (isReactive(s)) {
                    return reactiveGetter(s);
                } else if (isFunction(s)) {
                    return call ? call(s, 2) : s();
                } else;
            });
    } else if (isFunction(source)) {
        if (cb) {
            getter = call ? () => call(source, 2) : source;
        } else {
            getter = () => {
                if (cleanup) {
                    pauseTracking();
                    try {
                        cleanup();
                    } finally {
                        resetTracking();
                    }
                }
                const currentEffect = activeWatcher;
                activeWatcher = effect2;
                try {
                    return call
                        ? call(source, 3, [boundCleanup])
                        : source(boundCleanup);
                } finally {
                    activeWatcher = currentEffect;
                }
            };
        }
    } else {
        getter = NOOP;
    }
    if (cb && deep) {
        const baseGetter = getter;
        const depth = deep === true ? Infinity : deep;
        getter = () => traverse(baseGetter(), depth);
    }
    const scope = getCurrentScope();
    const watchHandle = () => {
        effect2.stop();
        if (scope && scope.active) {
            remove(scope.effects, effect2);
        }
    };
    if (once && cb) {
        const _cb = cb;
        cb = (...args) => {
            _cb(...args);
            watchHandle();
        };
    }
    let oldValue = isMultiSource
        ? new Array(source.length).fill(INITIAL_WATCHER_VALUE)
        : INITIAL_WATCHER_VALUE;
    const job = (immediateFirstRun) => {
        if (!(effect2.flags & 1) || (!effect2.dirty && !immediateFirstRun)) {
            return;
        }
        if (cb) {
            const newValue = effect2.run();
            if (
                deep ||
                forceTrigger ||
                (isMultiSource
                    ? newValue.some((v, i) => hasChanged(v, oldValue[i]))
                    : hasChanged(newValue, oldValue))
            ) {
                if (cleanup) {
                    cleanup();
                }
                const currentWatcher = activeWatcher;
                activeWatcher = effect2;
                try {
                    const args = [
                        newValue,
                        // pass undefined as the old value when it's changed for the first time
                        oldValue === INITIAL_WATCHER_VALUE
                            ? void 0
                            : isMultiSource &&
                                oldValue[0] === INITIAL_WATCHER_VALUE
                              ? []
                              : oldValue,
                        boundCleanup,
                    ];
                    call
                        ? call(cb, 3, args)
                        : // @ts-expect-error
                          cb(...args);
                    oldValue = newValue;
                } finally {
                    activeWatcher = currentWatcher;
                }
            }
        } else {
            effect2.run();
        }
    };
    if (augmentJob) {
        augmentJob(job);
    }
    effect2 = new ReactiveEffect(getter);
    effect2.scheduler = scheduler ? () => scheduler(job, false) : job;
    boundCleanup = (fn) => onWatcherCleanup(fn, false, effect2);
    cleanup = effect2.onStop = () => {
        const cleanups = cleanupMap.get(effect2);
        if (cleanups) {
            if (call) {
                call(cleanups, 4);
            } else {
                for (const cleanup2 of cleanups) cleanup2();
            }
            cleanupMap.delete(effect2);
        }
    };
    if (cb) {
        if (immediate) {
            job(true);
        } else {
            oldValue = effect2.run();
        }
    } else if (scheduler) {
        scheduler(job.bind(null, true), true);
    } else {
        effect2.run();
    }
    watchHandle.pause = effect2.pause.bind(effect2);
    watchHandle.resume = effect2.resume.bind(effect2);
    watchHandle.stop = watchHandle;
    return watchHandle;
}
function traverse(value, depth = Infinity, seen) {
    if (depth <= 0 || !isObject(value) || value["__v_skip"]) {
        return value;
    }
    seen = seen || /* @__PURE__ */ new Set();
    if (seen.has(value)) {
        return value;
    }
    seen.add(value);
    depth--;
    if (isRef(value)) {
        traverse(value.value, depth, seen);
    } else if (isArray(value)) {
        for (let i = 0; i < value.length; i++) {
            traverse(value[i], depth, seen);
        }
    } else if (isSet(value) || isMap(value)) {
        value.forEach((v) => {
            traverse(v, depth, seen);
        });
    } else if (isPlainObject$1(value)) {
        for (const key in value) {
            traverse(value[key], depth, seen);
        }
        for (const key of Object.getOwnPropertySymbols(value)) {
            if (Object.prototype.propertyIsEnumerable.call(value, key)) {
                traverse(value[key], depth, seen);
            }
        }
    }
    return value;
}
/**
 * @vue/runtime-core v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
const stack = [];
let isWarning = false;
function warn$1(msg, ...args) {
    if (isWarning) return;
    isWarning = true;
    pauseTracking();
    const instance = stack.length ? stack[stack.length - 1].component : null;
    const appWarnHandler = instance && instance.appContext.config.warnHandler;
    const trace = getComponentTrace();
    if (appWarnHandler) {
        callWithErrorHandling(appWarnHandler, instance, 11, [
            // eslint-disable-next-line no-restricted-syntax
            msg +
                args
                    .map((a) => {
                        var _a, _b;
                        return (_b =
                            (_a = a.toString) == null ? void 0 : _a.call(a)) !=
                            null
                            ? _b
                            : JSON.stringify(a);
                    })
                    .join(""),
            instance && instance.proxy,
            trace
                .map(
                    ({ vnode }) =>
                        `at <${formatComponentName(instance, vnode.type)}>`,
                )
                .join("\n"),
            trace,
        ]);
    } else {
        const warnArgs = [`[Vue warn]: ${msg}`, ...args];
        if (
            trace.length && // avoid spamming console during tests
            true
        ) {
            warnArgs.push(
                `
`,
                ...formatTrace(trace),
            );
        }
        console.warn(...warnArgs);
    }
    resetTracking();
    isWarning = false;
}
function getComponentTrace() {
    let currentVNode = stack[stack.length - 1];
    if (!currentVNode) {
        return [];
    }
    const normalizedStack = [];
    while (currentVNode) {
        const last = normalizedStack[0];
        if (last && last.vnode === currentVNode) {
            last.recurseCount++;
        } else {
            normalizedStack.push({
                vnode: currentVNode,
                recurseCount: 0,
            });
        }
        const parentInstance =
            currentVNode.component && currentVNode.component.parent;
        currentVNode = parentInstance && parentInstance.vnode;
    }
    return normalizedStack;
}
function formatTrace(trace) {
    const logs = [];
    trace.forEach((entry, i) => {
        logs.push(
            ...(i === 0
                ? []
                : [
                      `
`,
                  ]),
            ...formatTraceEntry(entry),
        );
    });
    return logs;
}
function formatTraceEntry({ vnode, recurseCount }) {
    const postfix =
        recurseCount > 0 ? `... (${recurseCount} recursive calls)` : ``;
    const isRoot = vnode.component ? vnode.component.parent == null : false;
    const open = ` at <${formatComponentName(
        vnode.component,
        vnode.type,
        isRoot,
    )}`;
    const close = `>` + postfix;
    return vnode.props
        ? [open, ...formatProps(vnode.props), close]
        : [open + close];
}
function formatProps(props) {
    const res = [];
    const keys = Object.keys(props);
    keys.slice(0, 3).forEach((key) => {
        res.push(...formatProp(key, props[key]));
    });
    if (keys.length > 3) {
        res.push(` ...`);
    }
    return res;
}
function formatProp(key, value, raw) {
    if (isString(value)) {
        value = JSON.stringify(value);
        return raw ? value : [`${key}=${value}`];
    } else if (
        typeof value === "number" ||
        typeof value === "boolean" ||
        value == null
    ) {
        return raw ? value : [`${key}=${value}`];
    } else if (isRef(value)) {
        value = formatProp(key, toRaw(value.value), true);
        return raw ? value : [`${key}=Ref<`, value, `>`];
    } else if (isFunction(value)) {
        return [`${key}=fn${value.name ? `<${value.name}>` : ``}`];
    } else {
        value = toRaw(value);
        return raw ? value : [`${key}=`, value];
    }
}
function callWithErrorHandling(fn, instance, type, args) {
    try {
        return args ? fn(...args) : fn();
    } catch (err) {
        handleError(err, instance, type);
    }
}
function callWithAsyncErrorHandling(fn, instance, type, args) {
    if (isFunction(fn)) {
        const res = callWithErrorHandling(fn, instance, type, args);
        if (res && isPromise$1(res)) {
            res.catch((err) => {
                handleError(err, instance, type);
            });
        }
        return res;
    }
    if (isArray(fn)) {
        const values = [];
        for (let i = 0; i < fn.length; i++) {
            values.push(
                callWithAsyncErrorHandling(fn[i], instance, type, args),
            );
        }
        return values;
    }
}
function handleError(err, instance, type, throwInDev = true) {
    const contextVNode = instance ? instance.vnode : null;
    const { errorHandler, throwUnhandledErrorInProduction } =
        (instance && instance.appContext.config) || EMPTY_OBJ;
    if (instance) {
        let cur = instance.parent;
        const exposedInstance = instance.proxy;
        const errorInfo = `https://vuejs.org/error-reference/#runtime-${type}`;
        while (cur) {
            const errorCapturedHooks = cur.ec;
            if (errorCapturedHooks) {
                for (let i = 0; i < errorCapturedHooks.length; i++) {
                    if (
                        errorCapturedHooks[i](
                            err,
                            exposedInstance,
                            errorInfo,
                        ) === false
                    ) {
                        return;
                    }
                }
            }
            cur = cur.parent;
        }
        if (errorHandler) {
            pauseTracking();
            callWithErrorHandling(errorHandler, null, 10, [
                err,
                exposedInstance,
                errorInfo,
            ]);
            resetTracking();
            return;
        }
    }
    logError(
        err,
        type,
        contextVNode,
        throwInDev,
        throwUnhandledErrorInProduction,
    );
}
function logError(
    err,
    type,
    contextVNode,
    throwInDev = true,
    throwInProd = false,
) {
    if (throwInProd) {
        throw err;
    } else {
        console.error(err);
    }
}
const queue = [];
let flushIndex = -1;
const pendingPostFlushCbs = [];
let activePostFlushCbs = null;
let postFlushIndex = 0;
const resolvedPromise = /* @__PURE__ */ Promise.resolve();
let currentFlushPromise = null;
function nextTick(fn) {
    const p2 = currentFlushPromise || resolvedPromise;
    return fn ? p2.then(this ? fn.bind(this) : fn) : p2;
}
function findInsertionIndex(id) {
    let start = flushIndex + 1;
    let end = queue.length;
    while (start < end) {
        const middle = (start + end) >>> 1;
        const middleJob = queue[middle];
        const middleJobId = getId(middleJob);
        if (middleJobId < id || (middleJobId === id && middleJob.flags & 2)) {
            start = middle + 1;
        } else {
            end = middle;
        }
    }
    return start;
}
function queueJob(job) {
    if (!(job.flags & 1)) {
        const jobId = getId(job);
        const lastJob = queue[queue.length - 1];
        if (
            !lastJob || // fast path when the job id is larger than the tail
            (!(job.flags & 2) && jobId >= getId(lastJob))
        ) {
            queue.push(job);
        } else {
            queue.splice(findInsertionIndex(jobId), 0, job);
        }
        job.flags |= 1;
        queueFlush();
    }
}
function queueFlush() {
    if (!currentFlushPromise) {
        currentFlushPromise = resolvedPromise.then(flushJobs);
    }
}
function queuePostFlushCb(cb) {
    if (!isArray(cb)) {
        if (activePostFlushCbs && cb.id === -1) {
            activePostFlushCbs.splice(postFlushIndex + 1, 0, cb);
        } else if (!(cb.flags & 1)) {
            pendingPostFlushCbs.push(cb);
            cb.flags |= 1;
        }
    } else {
        pendingPostFlushCbs.push(...cb);
    }
    queueFlush();
}
function flushPreFlushCbs(instance, seen, i = flushIndex + 1) {
    for (; i < queue.length; i++) {
        const cb = queue[i];
        if (cb && cb.flags & 2) {
            if (instance && cb.id !== instance.uid) {
                continue;
            }
            queue.splice(i, 1);
            i--;
            if (cb.flags & 4) {
                cb.flags &= -2;
            }
            cb();
            if (!(cb.flags & 4)) {
                cb.flags &= -2;
            }
        }
    }
}
function flushPostFlushCbs(seen) {
    if (pendingPostFlushCbs.length) {
        const deduped = [...new Set(pendingPostFlushCbs)].sort(
            (a, b) => getId(a) - getId(b),
        );
        pendingPostFlushCbs.length = 0;
        if (activePostFlushCbs) {
            activePostFlushCbs.push(...deduped);
            return;
        }
        activePostFlushCbs = deduped;
        for (
            postFlushIndex = 0;
            postFlushIndex < activePostFlushCbs.length;
            postFlushIndex++
        ) {
            const cb = activePostFlushCbs[postFlushIndex];
            if (cb.flags & 4) {
                cb.flags &= -2;
            }
            if (!(cb.flags & 8)) cb();
            cb.flags &= -2;
        }
        activePostFlushCbs = null;
        postFlushIndex = 0;
    }
}
const getId = (job) =>
    job.id == null ? (job.flags & 2 ? -1 : Infinity) : job.id;
function flushJobs(seen) {
    try {
        for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
            const job = queue[flushIndex];
            if (job && !(job.flags & 8)) {
                if (false);
                if (job.flags & 4) {
                    job.flags &= ~1;
                }
                callWithErrorHandling(job, job.i, job.i ? 15 : 14);
                if (!(job.flags & 4)) {
                    job.flags &= ~1;
                }
            }
        }
    } finally {
        for (; flushIndex < queue.length; flushIndex++) {
            const job = queue[flushIndex];
            if (job) {
                job.flags &= -2;
            }
        }
        flushIndex = -1;
        queue.length = 0;
        flushPostFlushCbs();
        currentFlushPromise = null;
        if (queue.length || pendingPostFlushCbs.length) {
            flushJobs();
        }
    }
}
let currentRenderingInstance = null;
let currentScopeId = null;
function setCurrentRenderingInstance(instance) {
    const prev = currentRenderingInstance;
    currentRenderingInstance = instance;
    currentScopeId = (instance && instance.type.__scopeId) || null;
    return prev;
}
function withCtx(fn, ctx = currentRenderingInstance, isNonScopedSlot) {
    if (!ctx) return fn;
    if (fn._n) {
        return fn;
    }
    const renderFnWithContext = (...args) => {
        if (renderFnWithContext._d) {
            setBlockTracking(-1);
        }
        const prevInstance = setCurrentRenderingInstance(ctx);
        let res;
        try {
            res = fn(...args);
        } finally {
            setCurrentRenderingInstance(prevInstance);
            if (renderFnWithContext._d) {
                setBlockTracking(1);
            }
        }
        return res;
    };
    renderFnWithContext._n = true;
    renderFnWithContext._c = true;
    renderFnWithContext._d = true;
    return renderFnWithContext;
}
function withDirectives(vnode, directives) {
    if (currentRenderingInstance === null) {
        return vnode;
    }
    const instance = getComponentPublicInstance(currentRenderingInstance);
    const bindings = vnode.dirs || (vnode.dirs = []);
    for (let i = 0; i < directives.length; i++) {
        let [dir, value, arg, modifiers = EMPTY_OBJ] = directives[i];
        if (dir) {
            if (isFunction(dir)) {
                dir = {
                    mounted: dir,
                    updated: dir,
                };
            }
            if (dir.deep) {
                traverse(value);
            }
            bindings.push({
                dir,
                instance,
                value,
                oldValue: void 0,
                arg,
                modifiers,
            });
        }
    }
    return vnode;
}
function invokeDirectiveHook(vnode, prevVNode, instance, name) {
    const bindings = vnode.dirs;
    const oldBindings = prevVNode && prevVNode.dirs;
    for (let i = 0; i < bindings.length; i++) {
        const binding = bindings[i];
        if (oldBindings) {
            binding.oldValue = oldBindings[i].value;
        }
        let hook = binding.dir[name];
        if (hook) {
            pauseTracking();
            callWithAsyncErrorHandling(hook, instance, 8, [
                vnode.el,
                binding,
                vnode,
                prevVNode,
            ]);
            resetTracking();
        }
    }
}
const TeleportEndKey = Symbol("_vte");
const isTeleport = (type) => type.__isTeleport;
function setTransitionHooks(vnode, hooks) {
    if (vnode.shapeFlag & 6 && vnode.component) {
        vnode.transition = hooks;
        setTransitionHooks(vnode.component.subTree, hooks);
    } else if (vnode.shapeFlag & 128) {
        vnode.ssContent.transition = hooks.clone(vnode.ssContent);
        vnode.ssFallback.transition = hooks.clone(vnode.ssFallback);
    } else {
        vnode.transition = hooks;
    }
}
function markAsyncBoundary(instance) {
    instance.ids = [instance.ids[0] + instance.ids[2]++ + "-", 0, 0];
}
function setRef(rawRef, oldRawRef, parentSuspense, vnode, isUnmount = false) {
    if (isArray(rawRef)) {
        rawRef.forEach((r, i) =>
            setRef(
                r,
                oldRawRef && (isArray(oldRawRef) ? oldRawRef[i] : oldRawRef),
                parentSuspense,
                vnode,
                isUnmount,
            ),
        );
        return;
    }
    if (isAsyncWrapper(vnode) && !isUnmount) {
        if (
            vnode.shapeFlag & 512 &&
            vnode.type.__asyncResolved &&
            vnode.component.subTree.component
        ) {
            setRef(rawRef, oldRawRef, parentSuspense, vnode.component.subTree);
        }
        return;
    }
    const refValue =
        vnode.shapeFlag & 4
            ? getComponentPublicInstance(vnode.component)
            : vnode.el;
    const value = isUnmount ? null : refValue;
    const { i: owner, r: ref3 } = rawRef;
    const oldRef = oldRawRef && oldRawRef.r;
    const refs = owner.refs === EMPTY_OBJ ? (owner.refs = {}) : owner.refs;
    const setupState = owner.setupState;
    const rawSetupState = toRaw(setupState);
    const canSetSetupRef =
        setupState === EMPTY_OBJ
            ? () => false
            : (key) => {
                  return hasOwn(rawSetupState, key);
              };
    if (oldRef != null && oldRef !== ref3) {
        if (isString(oldRef)) {
            refs[oldRef] = null;
            if (canSetSetupRef(oldRef)) {
                setupState[oldRef] = null;
            }
        } else if (isRef(oldRef)) {
            oldRef.value = null;
        }
    }
    if (isFunction(ref3)) {
        callWithErrorHandling(ref3, owner, 12, [value, refs]);
    } else {
        const _isString = isString(ref3);
        const _isRef = isRef(ref3);
        if (_isString || _isRef) {
            const doSet = () => {
                if (rawRef.f) {
                    const existing = _isString
                        ? canSetSetupRef(ref3)
                            ? setupState[ref3]
                            : refs[ref3]
                        : ref3.value;
                    if (isUnmount) {
                        isArray(existing) && remove(existing, refValue);
                    } else {
                        if (!isArray(existing)) {
                            if (_isString) {
                                refs[ref3] = [refValue];
                                if (canSetSetupRef(ref3)) {
                                    setupState[ref3] = refs[ref3];
                                }
                            } else {
                                ref3.value = [refValue];
                                if (rawRef.k) refs[rawRef.k] = ref3.value;
                            }
                        } else if (!existing.includes(refValue)) {
                            existing.push(refValue);
                        }
                    }
                } else if (_isString) {
                    refs[ref3] = value;
                    if (canSetSetupRef(ref3)) {
                        setupState[ref3] = value;
                    }
                } else if (_isRef) {
                    ref3.value = value;
                    if (rawRef.k) refs[rawRef.k] = value;
                } else;
            };
            if (value) {
                doSet.id = -1;
                queuePostRenderEffect(doSet, parentSuspense);
            } else {
                doSet();
            }
        }
    }
}
getGlobalThis().requestIdleCallback || ((cb) => setTimeout(cb, 1));
getGlobalThis().cancelIdleCallback || ((id) => clearTimeout(id));
const isAsyncWrapper = (i) => !!i.type.__asyncLoader;
const isKeepAlive = (vnode) => vnode.type.__isKeepAlive;
function onActivated(hook, target) {
    registerKeepAliveHook(hook, "a", target);
}
function onDeactivated(hook, target) {
    registerKeepAliveHook(hook, "da", target);
}
function registerKeepAliveHook(hook, type, target = currentInstance) {
    const wrappedHook =
        hook.__wdc ||
        (hook.__wdc = () => {
            let current = target;
            while (current) {
                if (current.isDeactivated) {
                    return;
                }
                current = current.parent;
            }
            return hook();
        });
    injectHook(type, wrappedHook, target);
    if (target) {
        let current = target.parent;
        while (current && current.parent) {
            if (isKeepAlive(current.parent.vnode)) {
                injectToKeepAliveRoot(wrappedHook, type, target, current);
            }
            current = current.parent;
        }
    }
}
function injectToKeepAliveRoot(hook, type, target, keepAliveRoot) {
    const injected = injectHook(
        type,
        hook,
        keepAliveRoot,
        true,
        /* prepend */
    );
    onUnmounted(() => {
        remove(keepAliveRoot[type], injected);
    }, target);
}
function injectHook(type, hook, target = currentInstance, prepend = false) {
    if (target) {
        const hooks = target[type] || (target[type] = []);
        const wrappedHook =
            hook.__weh ||
            (hook.__weh = (...args) => {
                pauseTracking();
                const reset = setCurrentInstance(target);
                const res = callWithAsyncErrorHandling(
                    hook,
                    target,
                    type,
                    args,
                );
                reset();
                resetTracking();
                return res;
            });
        if (prepend) {
            hooks.unshift(wrappedHook);
        } else {
            hooks.push(wrappedHook);
        }
        return wrappedHook;
    }
}
const createHook =
    (lifecycle) =>
    (hook, target = currentInstance) => {
        if (!isInSSRComponentSetup || lifecycle === "sp") {
            injectHook(lifecycle, (...args) => hook(...args), target);
        }
    };
const onBeforeMount = createHook("bm");
const onMounted = createHook("m");
const onBeforeUpdate = createHook("bu");
const onUpdated = createHook("u");
const onBeforeUnmount = createHook("bum");
const onUnmounted = createHook("um");
const onServerPrefetch = createHook("sp");
const onRenderTriggered = createHook("rtg");
const onRenderTracked = createHook("rtc");
function onErrorCaptured(hook, target = currentInstance) {
    injectHook("ec", hook, target);
}
const NULL_DYNAMIC_COMPONENT = Symbol.for("v-ndc");
function renderList(source, renderItem, cache, index) {
    let ret;
    const cached = cache;
    const sourceIsArray = isArray(source);
    if (sourceIsArray || isString(source)) {
        const sourceIsReactiveArray = sourceIsArray && isReactive(source);
        let needsWrap = false;
        if (sourceIsReactiveArray) {
            needsWrap = !isShallow(source);
            source = shallowReadArray(source);
        }
        ret = new Array(source.length);
        for (let i = 0, l = source.length; i < l; i++) {
            ret[i] = renderItem(
                needsWrap ? toReactive(source[i]) : source[i],
                i,
                void 0,
                cached,
            );
        }
    } else if (typeof source === "number") {
        ret = new Array(source);
        for (let i = 0; i < source; i++) {
            ret[i] = renderItem(i + 1, i, void 0, cached);
        }
    } else if (isObject(source)) {
        if (source[Symbol.iterator]) {
            ret = Array.from(source, (item, i) =>
                renderItem(item, i, void 0, cached),
            );
        } else {
            const keys = Object.keys(source);
            ret = new Array(keys.length);
            for (let i = 0, l = keys.length; i < l; i++) {
                const key = keys[i];
                ret[i] = renderItem(source[key], key, i, cached);
            }
        }
    } else {
        ret = [];
    }
    return ret;
}
const getPublicInstance = (i) => {
    if (!i) return null;
    if (isStatefulComponent(i)) return getComponentPublicInstance(i);
    return getPublicInstance(i.parent);
};
const publicPropertiesMap =
    // Move PURE marker to new line to workaround compiler discarding it
    // due to type annotation
    /* @__PURE__ */ extend(/* @__PURE__ */ Object.create(null), {
        $: (i) => i,
        $el: (i) => i.vnode.el,
        $data: (i) => i.data,
        $props: (i) => i.props,
        $attrs: (i) => i.attrs,
        $slots: (i) => i.slots,
        $refs: (i) => i.refs,
        $parent: (i) => getPublicInstance(i.parent),
        $root: (i) => getPublicInstance(i.root),
        $host: (i) => i.ce,
        $emit: (i) => i.emit,
        $options: (i) => resolveMergedOptions(i),
        $forceUpdate: (i) =>
            i.f ||
            (i.f = () => {
                queueJob(i.update);
            }),
        $nextTick: (i) => i.n || (i.n = nextTick.bind(i.proxy)),
        $watch: (i) => instanceWatch.bind(i),
    });
const hasSetupBinding = (state, key) =>
    state !== EMPTY_OBJ && !state.__isScriptSetup && hasOwn(state, key);
const PublicInstanceProxyHandlers = {
    get({ _: instance }, key) {
        if (key === "__v_skip") {
            return true;
        }
        const { ctx, setupState, data, props, accessCache, type, appContext } =
            instance;
        let normalizedProps;
        if (key[0] !== "$") {
            const n = accessCache[key];
            if (n !== void 0) {
                switch (n) {
                    case 1:
                        return setupState[key];
                    case 2:
                        return data[key];
                    case 4:
                        return ctx[key];
                    case 3:
                        return props[key];
                }
            } else if (hasSetupBinding(setupState, key)) {
                accessCache[key] = 1;
                return setupState[key];
            } else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
                accessCache[key] = 2;
                return data[key];
            } else if (
                // only cache other properties when instance has declared (thus stable)
                // props
                (normalizedProps = instance.propsOptions[0]) &&
                hasOwn(normalizedProps, key)
            ) {
                accessCache[key] = 3;
                return props[key];
            } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
                accessCache[key] = 4;
                return ctx[key];
            } else if (shouldCacheAccess) {
                accessCache[key] = 0;
            }
        }
        const publicGetter = publicPropertiesMap[key];
        let cssModule, globalProperties;
        if (publicGetter) {
            if (key === "$attrs") {
                track(instance.attrs, "get", "");
            }
            return publicGetter(instance);
        } else if (
            // css module (injected by vue-loader)
            (cssModule = type.__cssModules) &&
            (cssModule = cssModule[key])
        ) {
            return cssModule;
        } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
            accessCache[key] = 4;
            return ctx[key];
        } else if (
            // global properties
            ((globalProperties = appContext.config.globalProperties),
            hasOwn(globalProperties, key))
        ) {
            {
                return globalProperties[key];
            }
        } else;
    },
    set({ _: instance }, key, value) {
        const { data, setupState, ctx } = instance;
        if (hasSetupBinding(setupState, key)) {
            setupState[key] = value;
            return true;
        } else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
            data[key] = value;
            return true;
        } else if (hasOwn(instance.props, key)) {
            return false;
        }
        if (key[0] === "$" && key.slice(1) in instance) {
            return false;
        } else {
            {
                ctx[key] = value;
            }
        }
        return true;
    },
    has(
        { _: { data, setupState, accessCache, ctx, appContext, propsOptions } },
        key,
    ) {
        let normalizedProps;
        return (
            !!accessCache[key] ||
            (data !== EMPTY_OBJ && hasOwn(data, key)) ||
            hasSetupBinding(setupState, key) ||
            ((normalizedProps = propsOptions[0]) &&
                hasOwn(normalizedProps, key)) ||
            hasOwn(ctx, key) ||
            hasOwn(publicPropertiesMap, key) ||
            hasOwn(appContext.config.globalProperties, key)
        );
    },
    defineProperty(target, key, descriptor) {
        if (descriptor.get != null) {
            target._.accessCache[key] = 0;
        } else if (hasOwn(descriptor, "value")) {
            this.set(target, key, descriptor.value, null);
        }
        return Reflect.defineProperty(target, key, descriptor);
    },
};
function normalizePropsOrEmits(props) {
    return isArray(props)
        ? props.reduce(
              (normalized, p2) => ((normalized[p2] = null), normalized),
              {},
          )
        : props;
}
let shouldCacheAccess = true;
function applyOptions(instance) {
    const options = resolveMergedOptions(instance);
    const publicThis = instance.proxy;
    const ctx = instance.ctx;
    shouldCacheAccess = false;
    if (options.beforeCreate) {
        callHook(options.beforeCreate, instance, "bc");
    }
    const {
        // state
        data: dataOptions,
        computed: computedOptions,
        methods,
        watch: watchOptions,
        provide: provideOptions,
        inject: injectOptions,
        // lifecycle
        created,
        beforeMount,
        mounted,
        beforeUpdate,
        updated,
        activated,
        deactivated,
        beforeDestroy,
        beforeUnmount,
        destroyed,
        unmounted,
        render,
        renderTracked,
        renderTriggered,
        errorCaptured,
        serverPrefetch,
        // public API
        expose,
        inheritAttrs,
        // assets
        components,
        directives,
        filters,
    } = options;
    const checkDuplicateProperties = null;
    if (injectOptions) {
        resolveInjections(injectOptions, ctx, checkDuplicateProperties);
    }
    if (methods) {
        for (const key in methods) {
            const methodHandler = methods[key];
            if (isFunction(methodHandler)) {
                {
                    ctx[key] = methodHandler.bind(publicThis);
                }
            }
        }
    }
    if (dataOptions) {
        const data = dataOptions.call(publicThis, publicThis);
        if (!isObject(data));
        else {
            instance.data = reactive(data);
        }
    }
    shouldCacheAccess = true;
    if (computedOptions) {
        for (const key in computedOptions) {
            const opt = computedOptions[key];
            const get2 = isFunction(opt)
                ? opt.bind(publicThis, publicThis)
                : isFunction(opt.get)
                  ? opt.get.bind(publicThis, publicThis)
                  : NOOP;
            const set2 =
                !isFunction(opt) && isFunction(opt.set)
                    ? opt.set.bind(publicThis)
                    : NOOP;
            const c = computed({
                get: get2,
                set: set2,
            });
            Object.defineProperty(ctx, key, {
                enumerable: true,
                configurable: true,
                get: () => c.value,
                set: (v) => (c.value = v),
            });
        }
    }
    if (watchOptions) {
        for (const key in watchOptions) {
            createWatcher(watchOptions[key], ctx, publicThis, key);
        }
    }
    if (provideOptions) {
        const provides = isFunction(provideOptions)
            ? provideOptions.call(publicThis)
            : provideOptions;
        Reflect.ownKeys(provides).forEach((key) => {
            provide(key, provides[key]);
        });
    }
    if (created) {
        callHook(created, instance, "c");
    }
    function registerLifecycleHook(register, hook) {
        if (isArray(hook)) {
            hook.forEach((_hook) => register(_hook.bind(publicThis)));
        } else if (hook) {
            register(hook.bind(publicThis));
        }
    }
    registerLifecycleHook(onBeforeMount, beforeMount);
    registerLifecycleHook(onMounted, mounted);
    registerLifecycleHook(onBeforeUpdate, beforeUpdate);
    registerLifecycleHook(onUpdated, updated);
    registerLifecycleHook(onActivated, activated);
    registerLifecycleHook(onDeactivated, deactivated);
    registerLifecycleHook(onErrorCaptured, errorCaptured);
    registerLifecycleHook(onRenderTracked, renderTracked);
    registerLifecycleHook(onRenderTriggered, renderTriggered);
    registerLifecycleHook(onBeforeUnmount, beforeUnmount);
    registerLifecycleHook(onUnmounted, unmounted);
    registerLifecycleHook(onServerPrefetch, serverPrefetch);
    if (isArray(expose)) {
        if (expose.length) {
            const exposed = instance.exposed || (instance.exposed = {});
            expose.forEach((key) => {
                Object.defineProperty(exposed, key, {
                    get: () => publicThis[key],
                    set: (val) => (publicThis[key] = val),
                });
            });
        } else if (!instance.exposed) {
            instance.exposed = {};
        }
    }
    if (render && instance.render === NOOP) {
        instance.render = render;
    }
    if (inheritAttrs != null) {
        instance.inheritAttrs = inheritAttrs;
    }
    if (components) instance.components = components;
    if (directives) instance.directives = directives;
    if (serverPrefetch) {
        markAsyncBoundary(instance);
    }
}
function resolveInjections(
    injectOptions,
    ctx,
    checkDuplicateProperties = NOOP,
) {
    if (isArray(injectOptions)) {
        injectOptions = normalizeInject(injectOptions);
    }
    for (const key in injectOptions) {
        const opt = injectOptions[key];
        let injected;
        if (isObject(opt)) {
            if ("default" in opt) {
                injected = inject(opt.from || key, opt.default, true);
            } else {
                injected = inject(opt.from || key);
            }
        } else {
            injected = inject(opt);
        }
        if (isRef(injected)) {
            Object.defineProperty(ctx, key, {
                enumerable: true,
                configurable: true,
                get: () => injected.value,
                set: (v) => (injected.value = v),
            });
        } else {
            ctx[key] = injected;
        }
    }
}
function callHook(hook, instance, type) {
    callWithAsyncErrorHandling(
        isArray(hook)
            ? hook.map((h2) => h2.bind(instance.proxy))
            : hook.bind(instance.proxy),
        instance,
        type,
    );
}
function createWatcher(raw, ctx, publicThis, key) {
    let getter = key.includes(".")
        ? createPathGetter(publicThis, key)
        : () => publicThis[key];
    if (isString(raw)) {
        const handler = ctx[raw];
        if (isFunction(handler)) {
            {
                watch(getter, handler);
            }
        }
    } else if (isFunction(raw)) {
        {
            watch(getter, raw.bind(publicThis));
        }
    } else if (isObject(raw)) {
        if (isArray(raw)) {
            raw.forEach((r) => createWatcher(r, ctx, publicThis, key));
        } else {
            const handler = isFunction(raw.handler)
                ? raw.handler.bind(publicThis)
                : ctx[raw.handler];
            if (isFunction(handler)) {
                watch(getter, handler, raw);
            }
        }
    } else;
}
function resolveMergedOptions(instance) {
    const base = instance.type;
    const { mixins, extends: extendsOptions } = base;
    const {
        mixins: globalMixins,
        optionsCache: cache,
        config: { optionMergeStrategies },
    } = instance.appContext;
    const cached = cache.get(base);
    let resolved;
    if (cached) {
        resolved = cached;
    } else if (!globalMixins.length && !mixins && !extendsOptions) {
        {
            resolved = base;
        }
    } else {
        resolved = {};
        if (globalMixins.length) {
            globalMixins.forEach((m) =>
                mergeOptions(resolved, m, optionMergeStrategies, true),
            );
        }
        mergeOptions(resolved, base, optionMergeStrategies);
    }
    if (isObject(base)) {
        cache.set(base, resolved);
    }
    return resolved;
}
function mergeOptions(to, from, strats, asMixin = false) {
    const { mixins, extends: extendsOptions } = from;
    if (extendsOptions) {
        mergeOptions(to, extendsOptions, strats, true);
    }
    if (mixins) {
        mixins.forEach((m) => mergeOptions(to, m, strats, true));
    }
    for (const key in from) {
        if (asMixin && key === "expose");
        else {
            const strat =
                internalOptionMergeStrats[key] || (strats && strats[key]);
            to[key] = strat ? strat(to[key], from[key]) : from[key];
        }
    }
    return to;
}
const internalOptionMergeStrats = {
    data: mergeDataFn,
    props: mergeEmitsOrPropsOptions,
    emits: mergeEmitsOrPropsOptions,
    // objects
    methods: mergeObjectOptions,
    computed: mergeObjectOptions,
    // lifecycle
    beforeCreate: mergeAsArray,
    created: mergeAsArray,
    beforeMount: mergeAsArray,
    mounted: mergeAsArray,
    beforeUpdate: mergeAsArray,
    updated: mergeAsArray,
    beforeDestroy: mergeAsArray,
    beforeUnmount: mergeAsArray,
    destroyed: mergeAsArray,
    unmounted: mergeAsArray,
    activated: mergeAsArray,
    deactivated: mergeAsArray,
    errorCaptured: mergeAsArray,
    serverPrefetch: mergeAsArray,
    // assets
    components: mergeObjectOptions,
    directives: mergeObjectOptions,
    // watch
    watch: mergeWatchOptions,
    // provide / inject
    provide: mergeDataFn,
    inject: mergeInject,
};
function mergeDataFn(to, from) {
    if (!from) {
        return to;
    }
    if (!to) {
        return from;
    }
    return function mergedDataFn() {
        return extend(
            isFunction(to) ? to.call(this, this) : to,
            isFunction(from) ? from.call(this, this) : from,
        );
    };
}
function mergeInject(to, from) {
    return mergeObjectOptions(normalizeInject(to), normalizeInject(from));
}
function normalizeInject(raw) {
    if (isArray(raw)) {
        const res = {};
        for (let i = 0; i < raw.length; i++) {
            res[raw[i]] = raw[i];
        }
        return res;
    }
    return raw;
}
function mergeAsArray(to, from) {
    return to ? [...new Set([].concat(to, from))] : from;
}
function mergeObjectOptions(to, from) {
    return to ? extend(/* @__PURE__ */ Object.create(null), to, from) : from;
}
function mergeEmitsOrPropsOptions(to, from) {
    if (to) {
        if (isArray(to) && isArray(from)) {
            return [.../* @__PURE__ */ new Set([...to, ...from])];
        }
        return extend(
            /* @__PURE__ */ Object.create(null),
            normalizePropsOrEmits(to),
            normalizePropsOrEmits(from != null ? from : {}),
        );
    } else {
        return from;
    }
}
function mergeWatchOptions(to, from) {
    if (!to) return from;
    if (!from) return to;
    const merged = extend(/* @__PURE__ */ Object.create(null), to);
    for (const key in from) {
        merged[key] = mergeAsArray(to[key], from[key]);
    }
    return merged;
}
function createAppContext() {
    return {
        app: null,
        config: {
            isNativeTag: NO,
            performance: false,
            globalProperties: {},
            optionMergeStrategies: {},
            errorHandler: void 0,
            warnHandler: void 0,
            compilerOptions: {},
        },
        mixins: [],
        components: {},
        directives: {},
        provides: /* @__PURE__ */ Object.create(null),
        optionsCache: /* @__PURE__ */ new WeakMap(),
        propsCache: /* @__PURE__ */ new WeakMap(),
        emitsCache: /* @__PURE__ */ new WeakMap(),
    };
}
let uid$1 = 0;
function createAppAPI(render, hydrate) {
    return function createApp2(rootComponent, rootProps = null) {
        if (!isFunction(rootComponent)) {
            rootComponent = extend({}, rootComponent);
        }
        if (rootProps != null && !isObject(rootProps)) {
            rootProps = null;
        }
        const context = createAppContext();
        const installedPlugins = /* @__PURE__ */ new WeakSet();
        const pluginCleanupFns = [];
        let isMounted = false;
        const app = (context.app = {
            _uid: uid$1++,
            _component: rootComponent,
            _props: rootProps,
            _container: null,
            _context: context,
            _instance: null,
            version: version$1,
            get config() {
                return context.config;
            },
            set config(v) {},
            use(plugin, ...options) {
                if (installedPlugins.has(plugin));
                else if (plugin && isFunction(plugin.install)) {
                    installedPlugins.add(plugin);
                    plugin.install(app, ...options);
                } else if (isFunction(plugin)) {
                    installedPlugins.add(plugin);
                    plugin(app, ...options);
                } else;
                return app;
            },
            mixin(mixin) {
                {
                    if (!context.mixins.includes(mixin)) {
                        context.mixins.push(mixin);
                    }
                }
                return app;
            },
            component(name, component) {
                if (!component) {
                    return context.components[name];
                }
                context.components[name] = component;
                return app;
            },
            directive(name, directive) {
                if (!directive) {
                    return context.directives[name];
                }
                context.directives[name] = directive;
                return app;
            },
            mount(rootContainer, isHydrate, namespace) {
                if (!isMounted) {
                    const vnode =
                        app._ceVNode || createVNode(rootComponent, rootProps);
                    vnode.appContext = context;
                    if (namespace === true) {
                        namespace = "svg";
                    } else if (namespace === false) {
                        namespace = void 0;
                    }
                    {
                        render(vnode, rootContainer, namespace);
                    }
                    isMounted = true;
                    app._container = rootContainer;
                    rootContainer.__vue_app__ = app;
                    return getComponentPublicInstance(vnode.component);
                }
            },
            onUnmount(cleanupFn) {
                pluginCleanupFns.push(cleanupFn);
            },
            unmount() {
                if (isMounted) {
                    callWithAsyncErrorHandling(
                        pluginCleanupFns,
                        app._instance,
                        16,
                    );
                    render(null, app._container);
                    delete app._container.__vue_app__;
                }
            },
            provide(key, value) {
                context.provides[key] = value;
                return app;
            },
            runWithContext(fn) {
                const lastApp = currentApp;
                currentApp = app;
                try {
                    return fn();
                } finally {
                    currentApp = lastApp;
                }
            },
        });
        return app;
    };
}
let currentApp = null;
function provide(key, value) {
    if (!currentInstance);
    else {
        let provides = currentInstance.provides;
        const parentProvides =
            currentInstance.parent && currentInstance.parent.provides;
        if (parentProvides === provides) {
            provides = currentInstance.provides = Object.create(parentProvides);
        }
        provides[key] = value;
    }
}
function inject(key, defaultValue, treatDefaultAsFactory = false) {
    const instance = currentInstance || currentRenderingInstance;
    if (instance || currentApp) {
        const provides = currentApp
            ? currentApp._context.provides
            : instance
              ? instance.parent == null
                  ? instance.vnode.appContext &&
                    instance.vnode.appContext.provides
                  : instance.parent.provides
              : void 0;
        if (provides && key in provides) {
            return provides[key];
        } else if (arguments.length > 1) {
            return treatDefaultAsFactory && isFunction(defaultValue)
                ? defaultValue.call(instance && instance.proxy)
                : defaultValue;
        } else;
    }
}
function hasInjectionContext() {
    return !!(currentInstance || currentRenderingInstance || currentApp);
}
const internalObjectProto = {};
const createInternalObject = () => Object.create(internalObjectProto);
const isInternalObject = (obj) =>
    Object.getPrototypeOf(obj) === internalObjectProto;
function initProps(instance, rawProps, isStateful, isSSR = false) {
    const props = {};
    const attrs = createInternalObject();
    instance.propsDefaults = /* @__PURE__ */ Object.create(null);
    setFullProps(instance, rawProps, props, attrs);
    for (const key in instance.propsOptions[0]) {
        if (!(key in props)) {
            props[key] = void 0;
        }
    }
    if (isStateful) {
        instance.props = isSSR ? props : shallowReactive(props);
    } else {
        if (!instance.type.props) {
            instance.props = attrs;
        } else {
            instance.props = props;
        }
    }
    instance.attrs = attrs;
}
function updateProps(instance, rawProps, rawPrevProps, optimized) {
    const {
        props,
        attrs,
        vnode: { patchFlag },
    } = instance;
    const rawCurrentProps = toRaw(props);
    const [options] = instance.propsOptions;
    let hasAttrsChanged = false;
    if (
        // always force full diff in dev
        // - #1942 if hmr is enabled with sfc component
        // - vite#872 non-sfc component used by sfc component
        (optimized || patchFlag > 0) &&
        !(patchFlag & 16)
    ) {
        if (patchFlag & 8) {
            const propsToUpdate = instance.vnode.dynamicProps;
            for (let i = 0; i < propsToUpdate.length; i++) {
                let key = propsToUpdate[i];
                if (isEmitListener(instance.emitsOptions, key)) {
                    continue;
                }
                const value = rawProps[key];
                if (options) {
                    if (hasOwn(attrs, key)) {
                        if (value !== attrs[key]) {
                            attrs[key] = value;
                            hasAttrsChanged = true;
                        }
                    } else {
                        const camelizedKey = camelize(key);
                        props[camelizedKey] = resolvePropValue(
                            options,
                            rawCurrentProps,
                            camelizedKey,
                            value,
                            instance,
                            false,
                        );
                    }
                } else {
                    if (value !== attrs[key]) {
                        attrs[key] = value;
                        hasAttrsChanged = true;
                    }
                }
            }
        }
    } else {
        if (setFullProps(instance, rawProps, props, attrs)) {
            hasAttrsChanged = true;
        }
        let kebabKey;
        for (const key in rawCurrentProps) {
            if (
                !rawProps || // for camelCase
                (!hasOwn(rawProps, key) && // it's possible the original props was passed in as kebab-case
                    // and converted to camelCase (#955)
                    ((kebabKey = hyphenate(key)) === key ||
                        !hasOwn(rawProps, kebabKey)))
            ) {
                if (options) {
                    if (
                        rawPrevProps && // for camelCase
                        (rawPrevProps[key] !== void 0 || // for kebab-case
                            rawPrevProps[kebabKey] !== void 0)
                    ) {
                        props[key] = resolvePropValue(
                            options,
                            rawCurrentProps,
                            key,
                            void 0,
                            instance,
                            true,
                        );
                    }
                } else {
                    delete props[key];
                }
            }
        }
        if (attrs !== rawCurrentProps) {
            for (const key in attrs) {
                if (!rawProps || (!hasOwn(rawProps, key) && true)) {
                    delete attrs[key];
                    hasAttrsChanged = true;
                }
            }
        }
    }
    if (hasAttrsChanged) {
        trigger(instance.attrs, "set", "");
    }
}
function setFullProps(instance, rawProps, props, attrs) {
    const [options, needCastKeys] = instance.propsOptions;
    let hasAttrsChanged = false;
    let rawCastValues;
    if (rawProps) {
        for (let key in rawProps) {
            if (isReservedProp(key)) {
                continue;
            }
            const value = rawProps[key];
            let camelKey;
            if (options && hasOwn(options, (camelKey = camelize(key)))) {
                if (!needCastKeys || !needCastKeys.includes(camelKey)) {
                    props[camelKey] = value;
                } else {
                    (rawCastValues || (rawCastValues = {}))[camelKey] = value;
                }
            } else if (!isEmitListener(instance.emitsOptions, key)) {
                if (!(key in attrs) || value !== attrs[key]) {
                    attrs[key] = value;
                    hasAttrsChanged = true;
                }
            }
        }
    }
    if (needCastKeys) {
        const rawCurrentProps = toRaw(props);
        const castValues = rawCastValues || EMPTY_OBJ;
        for (let i = 0; i < needCastKeys.length; i++) {
            const key = needCastKeys[i];
            props[key] = resolvePropValue(
                options,
                rawCurrentProps,
                key,
                castValues[key],
                instance,
                !hasOwn(castValues, key),
            );
        }
    }
    return hasAttrsChanged;
}
function resolvePropValue(options, props, key, value, instance, isAbsent) {
    const opt = options[key];
    if (opt != null) {
        const hasDefault = hasOwn(opt, "default");
        if (hasDefault && value === void 0) {
            const defaultValue = opt.default;
            if (
                opt.type !== Function &&
                !opt.skipFactory &&
                isFunction(defaultValue)
            ) {
                const { propsDefaults } = instance;
                if (key in propsDefaults) {
                    value = propsDefaults[key];
                } else {
                    const reset = setCurrentInstance(instance);
                    value = propsDefaults[key] = defaultValue.call(null, props);
                    reset();
                }
            } else {
                value = defaultValue;
            }
            if (instance.ce) {
                instance.ce._setProp(key, value);
            }
        }
        if (
            opt[0]
            /* shouldCast */
        ) {
            if (isAbsent && !hasDefault) {
                value = false;
            } else if (
                opt[1] &&
                /* shouldCastTrue */
                (value === "" || value === hyphenate(key))
            ) {
                value = true;
            }
        }
    }
    return value;
}
const mixinPropsCache = /* @__PURE__ */ new WeakMap();
function normalizePropsOptions(comp, appContext, asMixin = false) {
    const cache = asMixin ? mixinPropsCache : appContext.propsCache;
    const cached = cache.get(comp);
    if (cached) {
        return cached;
    }
    const raw = comp.props;
    const normalized = {};
    const needCastKeys = [];
    let hasExtends = false;
    if (!isFunction(comp)) {
        const extendProps = (raw2) => {
            hasExtends = true;
            const [props, keys] = normalizePropsOptions(raw2, appContext, true);
            extend(normalized, props);
            if (keys) needCastKeys.push(...keys);
        };
        if (!asMixin && appContext.mixins.length) {
            appContext.mixins.forEach(extendProps);
        }
        if (comp.extends) {
            extendProps(comp.extends);
        }
        if (comp.mixins) {
            comp.mixins.forEach(extendProps);
        }
    }
    if (!raw && !hasExtends) {
        if (isObject(comp)) {
            cache.set(comp, EMPTY_ARR);
        }
        return EMPTY_ARR;
    }
    if (isArray(raw)) {
        for (let i = 0; i < raw.length; i++) {
            const normalizedKey = camelize(raw[i]);
            if (validatePropName(normalizedKey)) {
                normalized[normalizedKey] = EMPTY_OBJ;
            }
        }
    } else if (raw) {
        for (const key in raw) {
            const normalizedKey = camelize(key);
            if (validatePropName(normalizedKey)) {
                const opt = raw[key];
                const prop = (normalized[normalizedKey] =
                    isArray(opt) || isFunction(opt)
                        ? { type: opt }
                        : extend({}, opt));
                const propType = prop.type;
                let shouldCast = false;
                let shouldCastTrue = true;
                if (isArray(propType)) {
                    for (let index = 0; index < propType.length; ++index) {
                        const type = propType[index];
                        const typeName = isFunction(type) && type.name;
                        if (typeName === "Boolean") {
                            shouldCast = true;
                            break;
                        } else if (typeName === "String") {
                            shouldCastTrue = false;
                        }
                    }
                } else {
                    shouldCast =
                        isFunction(propType) && propType.name === "Boolean";
                }
                prop[0] =
                /* shouldCast */
                    shouldCast;
                prop[1] =
                /* shouldCastTrue */
                    shouldCastTrue;
                if (shouldCast || hasOwn(prop, "default")) {
                    needCastKeys.push(normalizedKey);
                }
            }
        }
    }
    const res = [normalized, needCastKeys];
    if (isObject(comp)) {
        cache.set(comp, res);
    }
    return res;
}
function validatePropName(key) {
    if (key[0] !== "$" && !isReservedProp(key)) {
        return true;
    }
    return false;
}
const isInternalKey = (key) => key[0] === "_" || key === "$stable";
const normalizeSlotValue = (value) =>
    isArray(value) ? value.map(normalizeVNode) : [normalizeVNode(value)];
const normalizeSlot = (key, rawSlot, ctx) => {
    if (rawSlot._n) {
        return rawSlot;
    }
    const normalized = withCtx((...args) => {
        if (false);
        return normalizeSlotValue(rawSlot(...args));
    }, ctx);
    normalized._c = false;
    return normalized;
};
const normalizeObjectSlots = (rawSlots, slots, instance) => {
    const ctx = rawSlots._ctx;
    for (const key in rawSlots) {
        if (isInternalKey(key)) continue;
        const value = rawSlots[key];
        if (isFunction(value)) {
            slots[key] = normalizeSlot(key, value, ctx);
        } else if (value != null) {
            const normalized = normalizeSlotValue(value);
            slots[key] = () => normalized;
        }
    }
};
const normalizeVNodeSlots = (instance, children) => {
    const normalized = normalizeSlotValue(children);
    instance.slots.default = () => normalized;
};
const assignSlots = (slots, children, optimized) => {
    for (const key in children) {
        if (optimized || key !== "_") {
            slots[key] = children[key];
        }
    }
};
const initSlots = (instance, children, optimized) => {
    const slots = (instance.slots = createInternalObject());
    if (instance.vnode.shapeFlag & 32) {
        const type = children._;
        if (type) {
            assignSlots(slots, children, optimized);
            if (optimized) {
                def(slots, "_", type, true);
            }
        } else {
            normalizeObjectSlots(children, slots);
        }
    } else if (children) {
        normalizeVNodeSlots(instance, children);
    }
};
const updateSlots = (instance, children, optimized) => {
    const { vnode, slots } = instance;
    let needDeletionCheck = true;
    let deletionComparisonTarget = EMPTY_OBJ;
    if (vnode.shapeFlag & 32) {
        const type = children._;
        if (type) {
            if (optimized && type === 1) {
                needDeletionCheck = false;
            } else {
                assignSlots(slots, children, optimized);
            }
        } else {
            needDeletionCheck = !children.$stable;
            normalizeObjectSlots(children, slots);
        }
        deletionComparisonTarget = children;
    } else if (children) {
        normalizeVNodeSlots(instance, children);
        deletionComparisonTarget = { default: 1 };
    }
    if (needDeletionCheck) {
        for (const key in slots) {
            if (!isInternalKey(key) && deletionComparisonTarget[key] == null) {
                delete slots[key];
            }
        }
    }
};
const queuePostRenderEffect = queueEffectWithSuspense;
function createRenderer(options) {
    return baseCreateRenderer(options);
}
function baseCreateRenderer(options, createHydrationFns) {
    const target = getGlobalThis();
    target.__VUE__ = true;
    const {
        insert: hostInsert,
        remove: hostRemove,
        patchProp: hostPatchProp,
        createElement: hostCreateElement,
        createText: hostCreateText,
        createComment: hostCreateComment,
        setText: hostSetText,
        setElementText: hostSetElementText,
        parentNode: hostParentNode,
        nextSibling: hostNextSibling,
        setScopeId: hostSetScopeId = NOOP,
        insertStaticContent: hostInsertStaticContent,
    } = options;
    const patch = (
        n1,
        n2,
        container,
        anchor = null,
        parentComponent = null,
        parentSuspense = null,
        namespace = void 0,
        slotScopeIds = null,
        optimized = !!n2.dynamicChildren,
    ) => {
        if (n1 === n2) {
            return;
        }
        if (n1 && !isSameVNodeType(n1, n2)) {
            anchor = getNextHostNode(n1);
            unmount(n1, parentComponent, parentSuspense, true);
            n1 = null;
        }
        if (n2.patchFlag === -2) {
            optimized = false;
            n2.dynamicChildren = null;
        }
        const { type, ref: ref3, shapeFlag } = n2;
        switch (type) {
            case Text:
                processText(n1, n2, container, anchor);
                break;
            case Comment:
                processCommentNode(n1, n2, container, anchor);
                break;
            case Static:
                if (n1 == null) {
                    mountStaticNode(n2, container, anchor, namespace);
                }
                break;
            case Fragment:
                processFragment(
                    n1,
                    n2,
                    container,
                    anchor,
                    parentComponent,
                    parentSuspense,
                    namespace,
                    slotScopeIds,
                    optimized,
                );
                break;
            default:
                if (shapeFlag & 1) {
                    processElement(
                        n1,
                        n2,
                        container,
                        anchor,
                        parentComponent,
                        parentSuspense,
                        namespace,
                        slotScopeIds,
                        optimized,
                    );
                } else if (shapeFlag & 6) {
                    processComponent(
                        n1,
                        n2,
                        container,
                        anchor,
                        parentComponent,
                        parentSuspense,
                        namespace,
                        slotScopeIds,
                        optimized,
                    );
                } else if (shapeFlag & 64) {
                    type.process(
                        n1,
                        n2,
                        container,
                        anchor,
                        parentComponent,
                        parentSuspense,
                        namespace,
                        slotScopeIds,
                        optimized,
                        internals,
                    );
                } else if (shapeFlag & 128) {
                    type.process(
                        n1,
                        n2,
                        container,
                        anchor,
                        parentComponent,
                        parentSuspense,
                        namespace,
                        slotScopeIds,
                        optimized,
                        internals,
                    );
                } else;
        }
        if (ref3 != null && parentComponent) {
            setRef(ref3, n1 && n1.ref, parentSuspense, n2 || n1, !n2);
        }
    };
    const processText = (n1, n2, container, anchor) => {
        if (n1 == null) {
            hostInsert(
                (n2.el = hostCreateText(n2.children)),
                container,
                anchor,
            );
        } else {
            const el = (n2.el = n1.el);
            if (n2.children !== n1.children) {
                hostSetText(el, n2.children);
            }
        }
    };
    const processCommentNode = (n1, n2, container, anchor) => {
        if (n1 == null) {
            hostInsert(
                (n2.el = hostCreateComment(n2.children || "")),
                container,
                anchor,
            );
        } else {
            n2.el = n1.el;
        }
    };
    const mountStaticNode = (n2, container, anchor, namespace) => {
        [n2.el, n2.anchor] = hostInsertStaticContent(
            n2.children,
            container,
            anchor,
            namespace,
            n2.el,
            n2.anchor,
        );
    };
    const moveStaticNode = ({ el, anchor }, container, nextSibling) => {
        let next;
        while (el && el !== anchor) {
            next = hostNextSibling(el);
            hostInsert(el, container, nextSibling);
            el = next;
        }
        hostInsert(anchor, container, nextSibling);
    };
    const removeStaticNode = ({ el, anchor }) => {
        let next;
        while (el && el !== anchor) {
            next = hostNextSibling(el);
            hostRemove(el);
            el = next;
        }
        hostRemove(anchor);
    };
    const processElement = (
        n1,
        n2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
    ) => {
        if (n2.type === "svg") {
            namespace = "svg";
        } else if (n2.type === "math") {
            namespace = "mathml";
        }
        if (n1 == null) {
            mountElement(
                n2,
                container,
                anchor,
                parentComponent,
                parentSuspense,
                namespace,
                slotScopeIds,
                optimized,
            );
        } else {
            patchElement(
                n1,
                n2,
                parentComponent,
                parentSuspense,
                namespace,
                slotScopeIds,
                optimized,
            );
        }
    };
    const mountElement = (
        vnode,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
    ) => {
        let el;
        let vnodeHook;
        const { props, shapeFlag, transition, dirs } = vnode;
        el = vnode.el = hostCreateElement(
            vnode.type,
            namespace,
            props && props.is,
            props,
        );
        if (shapeFlag & 8) {
            hostSetElementText(el, vnode.children);
        } else if (shapeFlag & 16) {
            mountChildren(
                vnode.children,
                el,
                null,
                parentComponent,
                parentSuspense,
                resolveChildrenNamespace(vnode, namespace),
                slotScopeIds,
                optimized,
            );
        }
        if (dirs) {
            invokeDirectiveHook(vnode, null, parentComponent, "created");
        }
        setScopeId(el, vnode, vnode.scopeId, slotScopeIds, parentComponent);
        if (props) {
            for (const key in props) {
                if (key !== "value" && !isReservedProp(key)) {
                    hostPatchProp(
                        el,
                        key,
                        null,
                        props[key],
                        namespace,
                        parentComponent,
                    );
                }
            }
            if ("value" in props) {
                hostPatchProp(el, "value", null, props.value, namespace);
            }
            if ((vnodeHook = props.onVnodeBeforeMount)) {
                invokeVNodeHook(vnodeHook, parentComponent, vnode);
            }
        }
        if (dirs) {
            invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
        }
        const needCallTransitionHooks = needTransition(
            parentSuspense,
            transition,
        );
        if (needCallTransitionHooks) {
            transition.beforeEnter(el);
        }
        hostInsert(el, container, anchor);
        if (
            (vnodeHook = props && props.onVnodeMounted) ||
            needCallTransitionHooks ||
            dirs
        ) {
            queuePostRenderEffect(() => {
                vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
                needCallTransitionHooks && transition.enter(el);
                dirs &&
                    invokeDirectiveHook(
                        vnode,
                        null,
                        parentComponent,
                        "mounted",
                    );
            }, parentSuspense);
        }
    };
    const setScopeId = (el, vnode, scopeId, slotScopeIds, parentComponent) => {
        if (scopeId) {
            hostSetScopeId(el, scopeId);
        }
        if (slotScopeIds) {
            for (let i = 0; i < slotScopeIds.length; i++) {
                hostSetScopeId(el, slotScopeIds[i]);
            }
        }
        if (parentComponent) {
            let subTree = parentComponent.subTree;
            if (
                vnode === subTree ||
                (isSuspense(subTree.type) &&
                    (subTree.ssContent === vnode ||
                        subTree.ssFallback === vnode))
            ) {
                const parentVNode = parentComponent.vnode;
                setScopeId(
                    el,
                    parentVNode,
                    parentVNode.scopeId,
                    parentVNode.slotScopeIds,
                    parentComponent.parent,
                );
            }
        }
    };
    const mountChildren = (
        children,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
        start = 0,
    ) => {
        for (let i = start; i < children.length; i++) {
            const child = (children[i] = optimized
                ? cloneIfMounted(children[i])
                : normalizeVNode(children[i]));
            patch(
                null,
                child,
                container,
                anchor,
                parentComponent,
                parentSuspense,
                namespace,
                slotScopeIds,
                optimized,
            );
        }
    };
    const patchElement = (
        n1,
        n2,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
    ) => {
        const el = (n2.el = n1.el);
        let { patchFlag, dynamicChildren, dirs } = n2;
        patchFlag |= n1.patchFlag & 16;
        const oldProps = n1.props || EMPTY_OBJ;
        const newProps = n2.props || EMPTY_OBJ;
        let vnodeHook;
        parentComponent && toggleRecurse(parentComponent, false);
        if ((vnodeHook = newProps.onVnodeBeforeUpdate)) {
            invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
        }
        if (dirs) {
            invokeDirectiveHook(n2, n1, parentComponent, "beforeUpdate");
        }
        parentComponent && toggleRecurse(parentComponent, true);
        if (
            (oldProps.innerHTML && newProps.innerHTML == null) ||
            (oldProps.textContent && newProps.textContent == null)
        ) {
            hostSetElementText(el, "");
        }
        if (dynamicChildren) {
            patchBlockChildren(
                n1.dynamicChildren,
                dynamicChildren,
                el,
                parentComponent,
                parentSuspense,
                resolveChildrenNamespace(n2, namespace),
                slotScopeIds,
            );
        } else if (!optimized) {
            patchChildren(
                n1,
                n2,
                el,
                null,
                parentComponent,
                parentSuspense,
                resolveChildrenNamespace(n2, namespace),
                slotScopeIds,
                false,
            );
        }
        if (patchFlag > 0) {
            if (patchFlag & 16) {
                patchProps(el, oldProps, newProps, parentComponent, namespace);
            } else {
                if (patchFlag & 2) {
                    if (oldProps.class !== newProps.class) {
                        hostPatchProp(
                            el,
                            "class",
                            null,
                            newProps.class,
                            namespace,
                        );
                    }
                }
                if (patchFlag & 4) {
                    hostPatchProp(
                        el,
                        "style",
                        oldProps.style,
                        newProps.style,
                        namespace,
                    );
                }
                if (patchFlag & 8) {
                    const propsToUpdate = n2.dynamicProps;
                    for (let i = 0; i < propsToUpdate.length; i++) {
                        const key = propsToUpdate[i];
                        const prev = oldProps[key];
                        const next = newProps[key];
                        if (next !== prev || key === "value") {
                            hostPatchProp(
                                el,
                                key,
                                prev,
                                next,
                                namespace,
                                parentComponent,
                            );
                        }
                    }
                }
            }
            if (patchFlag & 1) {
                if (n1.children !== n2.children) {
                    hostSetElementText(el, n2.children);
                }
            }
        } else if (!optimized && dynamicChildren == null) {
            patchProps(el, oldProps, newProps, parentComponent, namespace);
        }
        if ((vnodeHook = newProps.onVnodeUpdated) || dirs) {
            queuePostRenderEffect(() => {
                vnodeHook &&
                    invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
                dirs && invokeDirectiveHook(n2, n1, parentComponent, "updated");
            }, parentSuspense);
        }
    };
    const patchBlockChildren = (
        oldChildren,
        newChildren,
        fallbackContainer,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
    ) => {
        for (let i = 0; i < newChildren.length; i++) {
            const oldVNode = oldChildren[i];
            const newVNode = newChildren[i];
            const container =
                // oldVNode may be an errored async setup() component inside Suspense
                // which will not have a mounted element
                oldVNode.el && // - In the case of a Fragment, we need to provide the actual parent
                // of the Fragment itself so it can move its children.
                (oldVNode.type === Fragment || // - In the case of different nodes, there is going to be a replacement
                    // which also requires the correct parent container
                    !isSameVNodeType(oldVNode, newVNode) || // - In the case of a component, it could contain anything.
                    oldVNode.shapeFlag & (6 | 64))
                    ? hostParentNode(oldVNode.el)
                    : // In other cases, the parent container is not actually used so we
                      // just pass the block element here to avoid a DOM parentNode call.
                      fallbackContainer;
            patch(
                oldVNode,
                newVNode,
                container,
                null,
                parentComponent,
                parentSuspense,
                namespace,
                slotScopeIds,
                true,
            );
        }
    };
    const patchProps = (el, oldProps, newProps, parentComponent, namespace) => {
        if (oldProps !== newProps) {
            if (oldProps !== EMPTY_OBJ) {
                for (const key in oldProps) {
                    if (!isReservedProp(key) && !(key in newProps)) {
                        hostPatchProp(
                            el,
                            key,
                            oldProps[key],
                            null,
                            namespace,
                            parentComponent,
                        );
                    }
                }
            }
            for (const key in newProps) {
                if (isReservedProp(key)) continue;
                const next = newProps[key];
                const prev = oldProps[key];
                if (next !== prev && key !== "value") {
                    hostPatchProp(
                        el,
                        key,
                        prev,
                        next,
                        namespace,
                        parentComponent,
                    );
                }
            }
            if ("value" in newProps) {
                hostPatchProp(
                    el,
                    "value",
                    oldProps.value,
                    newProps.value,
                    namespace,
                );
            }
        }
    };
    const processFragment = (
        n1,
        n2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
    ) => {
        const fragmentStartAnchor = (n2.el = n1 ? n1.el : hostCreateText(""));
        const fragmentEndAnchor = (n2.anchor = n1
            ? n1.anchor
            : hostCreateText(""));
        let {
            patchFlag,
            dynamicChildren,
            slotScopeIds: fragmentSlotScopeIds,
        } = n2;
        if (fragmentSlotScopeIds) {
            slotScopeIds = slotScopeIds
                ? slotScopeIds.concat(fragmentSlotScopeIds)
                : fragmentSlotScopeIds;
        }
        if (n1 == null) {
            hostInsert(fragmentStartAnchor, container, anchor);
            hostInsert(fragmentEndAnchor, container, anchor);
            mountChildren(
                // #10007
                // such fragment like `<></>` will be compiled into
                // a fragment which doesn't have a children.
                // In this case fallback to an empty array
                n2.children || [],
                container,
                fragmentEndAnchor,
                parentComponent,
                parentSuspense,
                namespace,
                slotScopeIds,
                optimized,
            );
        } else {
            if (
                patchFlag > 0 &&
                patchFlag & 64 &&
                dynamicChildren && // #2715 the previous fragment could've been a BAILed one as a result
                // of renderSlot() with no valid children
                n1.dynamicChildren
            ) {
                patchBlockChildren(
                    n1.dynamicChildren,
                    dynamicChildren,
                    container,
                    parentComponent,
                    parentSuspense,
                    namespace,
                    slotScopeIds,
                );
                if (
                    // #2080 if the stable fragment has a key, it's a <template v-for> that may
                    //  get moved around. Make sure all root level vnodes inherit el.
                    // #2134 or if it's a component root, it may also get moved around
                    // as the component is being moved.
                    n2.key != null ||
                    (parentComponent && n2 === parentComponent.subTree)
                ) {
                    traverseStaticChildren(
                        n1,
                        n2,
                        true,
                        /* shallow */
                    );
                }
            } else {
                patchChildren(
                    n1,
                    n2,
                    container,
                    fragmentEndAnchor,
                    parentComponent,
                    parentSuspense,
                    namespace,
                    slotScopeIds,
                    optimized,
                );
            }
        }
    };
    const processComponent = (
        n1,
        n2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
    ) => {
        n2.slotScopeIds = slotScopeIds;
        if (n1 == null) {
            if (n2.shapeFlag & 512) {
                parentComponent.ctx.activate(
                    n2,
                    container,
                    anchor,
                    namespace,
                    optimized,
                );
            } else {
                mountComponent(
                    n2,
                    container,
                    anchor,
                    parentComponent,
                    parentSuspense,
                    namespace,
                    optimized,
                );
            }
        } else {
            updateComponent(n1, n2, optimized);
        }
    };
    const mountComponent = (
        initialVNode,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        optimized,
    ) => {
        const instance = (initialVNode.component = createComponentInstance(
            initialVNode,
            parentComponent,
            parentSuspense,
        ));
        if (isKeepAlive(initialVNode)) {
            instance.ctx.renderer = internals;
        }
        {
            setupComponent(instance, false, optimized);
        }
        if (instance.asyncDep) {
            parentSuspense &&
                parentSuspense.registerDep(
                    instance,
                    setupRenderEffect,
                    optimized,
                );
            if (!initialVNode.el) {
                const placeholder = (instance.subTree = createVNode(Comment));
                processCommentNode(null, placeholder, container, anchor);
            }
        } else {
            setupRenderEffect(
                instance,
                initialVNode,
                container,
                anchor,
                parentSuspense,
                namespace,
                optimized,
            );
        }
    };
    const updateComponent = (n1, n2, optimized) => {
        const instance = (n2.component = n1.component);
        if (shouldUpdateComponent(n1, n2, optimized)) {
            if (instance.asyncDep && !instance.asyncResolved) {
                updateComponentPreRender(instance, n2, optimized);
                return;
            } else {
                instance.next = n2;
                instance.update();
            }
        } else {
            n2.el = n1.el;
            instance.vnode = n2;
        }
    };
    const setupRenderEffect = (
        instance,
        initialVNode,
        container,
        anchor,
        parentSuspense,
        namespace,
        optimized,
    ) => {
        const componentUpdateFn = () => {
            if (!instance.isMounted) {
                let vnodeHook;
                const { el, props } = initialVNode;
                const { bm, m, parent, root, type } = instance;
                const isAsyncWrapperVNode = isAsyncWrapper(initialVNode);
                toggleRecurse(instance, false);
                if (bm) {
                    invokeArrayFns(bm);
                }
                if (
                    !isAsyncWrapperVNode &&
                    (vnodeHook = props && props.onVnodeBeforeMount)
                ) {
                    invokeVNodeHook(vnodeHook, parent, initialVNode);
                }
                toggleRecurse(instance, true);
                {
                    if (root.ce) {
                        root.ce._injectChildStyle(type);
                    }
                    const subTree = (instance.subTree =
                        renderComponentRoot(instance));
                    patch(
                        null,
                        subTree,
                        container,
                        anchor,
                        instance,
                        parentSuspense,
                        namespace,
                    );
                    initialVNode.el = subTree.el;
                }
                if (m) {
                    queuePostRenderEffect(m, parentSuspense);
                }
                if (
                    !isAsyncWrapperVNode &&
                    (vnodeHook = props && props.onVnodeMounted)
                ) {
                    const scopedInitialVNode = initialVNode;
                    queuePostRenderEffect(
                        () =>
                            invokeVNodeHook(
                                vnodeHook,
                                parent,
                                scopedInitialVNode,
                            ),
                        parentSuspense,
                    );
                }
                if (
                    initialVNode.shapeFlag & 256 ||
                    (parent &&
                        isAsyncWrapper(parent.vnode) &&
                        parent.vnode.shapeFlag & 256)
                ) {
                    instance.a &&
                        queuePostRenderEffect(instance.a, parentSuspense);
                }
                instance.isMounted = true;
                initialVNode = container = anchor = null;
            } else {
                let { next, bu, u, parent, vnode } = instance;
                {
                    const nonHydratedAsyncRoot =
                        locateNonHydratedAsyncRoot(instance);
                    if (nonHydratedAsyncRoot) {
                        if (next) {
                            next.el = vnode.el;
                            updateComponentPreRender(instance, next, optimized);
                        }
                        nonHydratedAsyncRoot.asyncDep.then(() => {
                            if (!instance.isUnmounted) {
                                componentUpdateFn();
                            }
                        });
                        return;
                    }
                }
                let originNext = next;
                let vnodeHook;
                toggleRecurse(instance, false);
                if (next) {
                    next.el = vnode.el;
                    updateComponentPreRender(instance, next, optimized);
                } else {
                    next = vnode;
                }
                if (bu) {
                    invokeArrayFns(bu);
                }
                if (
                    (vnodeHook = next.props && next.props.onVnodeBeforeUpdate)
                ) {
                    invokeVNodeHook(vnodeHook, parent, next, vnode);
                }
                toggleRecurse(instance, true);
                const nextTree = renderComponentRoot(instance);
                const prevTree = instance.subTree;
                instance.subTree = nextTree;
                patch(
                    prevTree,
                    nextTree,
                    // parent may have changed if it's in a teleport
                    hostParentNode(prevTree.el),
                    // anchor may have changed if it's in a fragment
                    getNextHostNode(prevTree),
                    instance,
                    parentSuspense,
                    namespace,
                );
                next.el = nextTree.el;
                if (originNext === null) {
                    updateHOCHostEl(instance, nextTree.el);
                }
                if (u) {
                    queuePostRenderEffect(u, parentSuspense);
                }
                if ((vnodeHook = next.props && next.props.onVnodeUpdated)) {
                    queuePostRenderEffect(
                        () => invokeVNodeHook(vnodeHook, parent, next, vnode),
                        parentSuspense,
                    );
                }
            }
        };
        instance.scope.on();
        const effect2 = (instance.effect = new ReactiveEffect(
            componentUpdateFn,
        ));
        instance.scope.off();
        const update = (instance.update = effect2.run.bind(effect2));
        const job = (instance.job = effect2.runIfDirty.bind(effect2));
        job.i = instance;
        job.id = instance.uid;
        effect2.scheduler = () => queueJob(job);
        toggleRecurse(instance, true);
        update();
    };
    const updateComponentPreRender = (instance, nextVNode, optimized) => {
        nextVNode.component = instance;
        const prevProps = instance.vnode.props;
        instance.vnode = nextVNode;
        instance.next = null;
        updateProps(instance, nextVNode.props, prevProps, optimized);
        updateSlots(instance, nextVNode.children, optimized);
        pauseTracking();
        flushPreFlushCbs(instance);
        resetTracking();
    };
    const patchChildren = (
        n1,
        n2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized = false,
    ) => {
        const c1 = n1 && n1.children;
        const prevShapeFlag = n1 ? n1.shapeFlag : 0;
        const c2 = n2.children;
        const { patchFlag, shapeFlag } = n2;
        if (patchFlag > 0) {
            if (patchFlag & 128) {
                patchKeyedChildren(
                    c1,
                    c2,
                    container,
                    anchor,
                    parentComponent,
                    parentSuspense,
                    namespace,
                    slotScopeIds,
                    optimized,
                );
                return;
            } else if (patchFlag & 256) {
                patchUnkeyedChildren(
                    c1,
                    c2,
                    container,
                    anchor,
                    parentComponent,
                    parentSuspense,
                    namespace,
                    slotScopeIds,
                    optimized,
                );
                return;
            }
        }
        if (shapeFlag & 8) {
            if (prevShapeFlag & 16) {
                unmountChildren(c1, parentComponent, parentSuspense);
            }
            if (c2 !== c1) {
                hostSetElementText(container, c2);
            }
        } else {
            if (prevShapeFlag & 16) {
                if (shapeFlag & 16) {
                    patchKeyedChildren(
                        c1,
                        c2,
                        container,
                        anchor,
                        parentComponent,
                        parentSuspense,
                        namespace,
                        slotScopeIds,
                        optimized,
                    );
                } else {
                    unmountChildren(c1, parentComponent, parentSuspense, true);
                }
            } else {
                if (prevShapeFlag & 8) {
                    hostSetElementText(container, "");
                }
                if (shapeFlag & 16) {
                    mountChildren(
                        c2,
                        container,
                        anchor,
                        parentComponent,
                        parentSuspense,
                        namespace,
                        slotScopeIds,
                        optimized,
                    );
                }
            }
        }
    };
    const patchUnkeyedChildren = (
        c1,
        c2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
    ) => {
        c1 = c1 || EMPTY_ARR;
        c2 = c2 || EMPTY_ARR;
        const oldLength = c1.length;
        const newLength = c2.length;
        const commonLength = Math.min(oldLength, newLength);
        let i;
        for (i = 0; i < commonLength; i++) {
            const nextChild = (c2[i] = optimized
                ? cloneIfMounted(c2[i])
                : normalizeVNode(c2[i]));
            patch(
                c1[i],
                nextChild,
                container,
                null,
                parentComponent,
                parentSuspense,
                namespace,
                slotScopeIds,
                optimized,
            );
        }
        if (oldLength > newLength) {
            unmountChildren(
                c1,
                parentComponent,
                parentSuspense,
                true,
                false,
                commonLength,
            );
        } else {
            mountChildren(
                c2,
                container,
                anchor,
                parentComponent,
                parentSuspense,
                namespace,
                slotScopeIds,
                optimized,
                commonLength,
            );
        }
    };
    const patchKeyedChildren = (
        c1,
        c2,
        container,
        parentAnchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
    ) => {
        let i = 0;
        const l2 = c2.length;
        let e1 = c1.length - 1;
        let e2 = l2 - 1;
        while (i <= e1 && i <= e2) {
            const n1 = c1[i];
            const n2 = (c2[i] = optimized
                ? cloneIfMounted(c2[i])
                : normalizeVNode(c2[i]));
            if (isSameVNodeType(n1, n2)) {
                patch(
                    n1,
                    n2,
                    container,
                    null,
                    parentComponent,
                    parentSuspense,
                    namespace,
                    slotScopeIds,
                    optimized,
                );
            } else {
                break;
            }
            i++;
        }
        while (i <= e1 && i <= e2) {
            const n1 = c1[e1];
            const n2 = (c2[e2] = optimized
                ? cloneIfMounted(c2[e2])
                : normalizeVNode(c2[e2]));
            if (isSameVNodeType(n1, n2)) {
                patch(
                    n1,
                    n2,
                    container,
                    null,
                    parentComponent,
                    parentSuspense,
                    namespace,
                    slotScopeIds,
                    optimized,
                );
            } else {
                break;
            }
            e1--;
            e2--;
        }
        if (i > e1) {
            if (i <= e2) {
                const nextPos = e2 + 1;
                const anchor = nextPos < l2 ? c2[nextPos].el : parentAnchor;
                while (i <= e2) {
                    patch(
                        null,
                        (c2[i] = optimized
                            ? cloneIfMounted(c2[i])
                            : normalizeVNode(c2[i])),
                        container,
                        anchor,
                        parentComponent,
                        parentSuspense,
                        namespace,
                        slotScopeIds,
                        optimized,
                    );
                    i++;
                }
            }
        } else if (i > e2) {
            while (i <= e1) {
                unmount(c1[i], parentComponent, parentSuspense, true);
                i++;
            }
        } else {
            const s1 = i;
            const s2 = i;
            const keyToNewIndexMap = /* @__PURE__ */ new Map();
            for (i = s2; i <= e2; i++) {
                const nextChild = (c2[i] = optimized
                    ? cloneIfMounted(c2[i])
                    : normalizeVNode(c2[i]));
                if (nextChild.key != null) {
                    keyToNewIndexMap.set(nextChild.key, i);
                }
            }
            let j;
            let patched = 0;
            const toBePatched = e2 - s2 + 1;
            let moved = false;
            let maxNewIndexSoFar = 0;
            const newIndexToOldIndexMap = new Array(toBePatched);
            for (i = 0; i < toBePatched; i++) newIndexToOldIndexMap[i] = 0;
            for (i = s1; i <= e1; i++) {
                const prevChild = c1[i];
                if (patched >= toBePatched) {
                    unmount(prevChild, parentComponent, parentSuspense, true);
                    continue;
                }
                let newIndex;
                if (prevChild.key != null) {
                    newIndex = keyToNewIndexMap.get(prevChild.key);
                } else {
                    for (j = s2; j <= e2; j++) {
                        if (
                            newIndexToOldIndexMap[j - s2] === 0 &&
                            isSameVNodeType(prevChild, c2[j])
                        ) {
                            newIndex = j;
                            break;
                        }
                    }
                }
                if (newIndex === void 0) {
                    unmount(prevChild, parentComponent, parentSuspense, true);
                } else {
                    newIndexToOldIndexMap[newIndex - s2] = i + 1;
                    if (newIndex >= maxNewIndexSoFar) {
                        maxNewIndexSoFar = newIndex;
                    } else {
                        moved = true;
                    }
                    patch(
                        prevChild,
                        c2[newIndex],
                        container,
                        null,
                        parentComponent,
                        parentSuspense,
                        namespace,
                        slotScopeIds,
                        optimized,
                    );
                    patched++;
                }
            }
            const increasingNewIndexSequence = moved
                ? getSequence(newIndexToOldIndexMap)
                : EMPTY_ARR;
            j = increasingNewIndexSequence.length - 1;
            for (i = toBePatched - 1; i >= 0; i--) {
                const nextIndex = s2 + i;
                const nextChild = c2[nextIndex];
                const anchor =
                    nextIndex + 1 < l2 ? c2[nextIndex + 1].el : parentAnchor;
                if (newIndexToOldIndexMap[i] === 0) {
                    patch(
                        null,
                        nextChild,
                        container,
                        anchor,
                        parentComponent,
                        parentSuspense,
                        namespace,
                        slotScopeIds,
                        optimized,
                    );
                } else if (moved) {
                    if (j < 0 || i !== increasingNewIndexSequence[j]) {
                        move(nextChild, container, anchor, 2);
                    } else {
                        j--;
                    }
                }
            }
        }
    };
    const move = (
        vnode,
        container,
        anchor,
        moveType,
        parentSuspense = null,
    ) => {
        const { el, type, transition, children, shapeFlag } = vnode;
        if (shapeFlag & 6) {
            move(vnode.component.subTree, container, anchor, moveType);
            return;
        }
        if (shapeFlag & 128) {
            vnode.suspense.move(container, anchor, moveType);
            return;
        }
        if (shapeFlag & 64) {
            type.move(vnode, container, anchor, internals);
            return;
        }
        if (type === Fragment) {
            hostInsert(el, container, anchor);
            for (let i = 0; i < children.length; i++) {
                move(children[i], container, anchor, moveType);
            }
            hostInsert(vnode.anchor, container, anchor);
            return;
        }
        if (type === Static) {
            moveStaticNode(vnode, container, anchor);
            return;
        }
        const needTransition2 = moveType !== 2 && shapeFlag & 1 && transition;
        if (needTransition2) {
            if (moveType === 0) {
                transition.beforeEnter(el);
                hostInsert(el, container, anchor);
                queuePostRenderEffect(
                    () => transition.enter(el),
                    parentSuspense,
                );
            } else {
                const { leave, delayLeave, afterLeave } = transition;
                const remove22 = () => hostInsert(el, container, anchor);
                const performLeave = () => {
                    leave(el, () => {
                        remove22();
                        afterLeave && afterLeave();
                    });
                };
                if (delayLeave) {
                    delayLeave(el, remove22, performLeave);
                } else {
                    performLeave();
                }
            }
        } else {
            hostInsert(el, container, anchor);
        }
    };
    const unmount = (
        vnode,
        parentComponent,
        parentSuspense,
        doRemove = false,
        optimized = false,
    ) => {
        const {
            type,
            props,
            ref: ref3,
            children,
            dynamicChildren,
            shapeFlag,
            patchFlag,
            dirs,
            cacheIndex,
        } = vnode;
        if (patchFlag === -2) {
            optimized = false;
        }
        if (ref3 != null) {
            setRef(ref3, null, parentSuspense, vnode, true);
        }
        if (cacheIndex != null) {
            parentComponent.renderCache[cacheIndex] = void 0;
        }
        if (shapeFlag & 256) {
            parentComponent.ctx.deactivate(vnode);
            return;
        }
        const shouldInvokeDirs = shapeFlag & 1 && dirs;
        const shouldInvokeVnodeHook = !isAsyncWrapper(vnode);
        let vnodeHook;
        if (
            shouldInvokeVnodeHook &&
            (vnodeHook = props && props.onVnodeBeforeUnmount)
        ) {
            invokeVNodeHook(vnodeHook, parentComponent, vnode);
        }
        if (shapeFlag & 6) {
            unmountComponent(vnode.component, parentSuspense, doRemove);
        } else {
            if (shapeFlag & 128) {
                vnode.suspense.unmount(parentSuspense, doRemove);
                return;
            }
            if (shouldInvokeDirs) {
                invokeDirectiveHook(
                    vnode,
                    null,
                    parentComponent,
                    "beforeUnmount",
                );
            }
            if (shapeFlag & 64) {
                vnode.type.remove(
                    vnode,
                    parentComponent,
                    parentSuspense,
                    internals,
                    doRemove,
                );
            } else if (
                dynamicChildren && // #5154
                // when v-once is used inside a block, setBlockTracking(-1) marks the
                // parent block with hasOnce: true
                // so that it doesn't take the fast path during unmount - otherwise
                // components nested in v-once are never unmounted.
                !dynamicChildren.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
                (type !== Fragment || (patchFlag > 0 && patchFlag & 64))
            ) {
                unmountChildren(
                    dynamicChildren,
                    parentComponent,
                    parentSuspense,
                    false,
                    true,
                );
            } else if (
                (type === Fragment && patchFlag & (128 | 256)) ||
                (!optimized && shapeFlag & 16)
            ) {
                unmountChildren(children, parentComponent, parentSuspense);
            }
            if (doRemove) {
                remove2(vnode);
            }
        }
        if (
            (shouldInvokeVnodeHook &&
                (vnodeHook = props && props.onVnodeUnmounted)) ||
            shouldInvokeDirs
        ) {
            queuePostRenderEffect(() => {
                vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
                shouldInvokeDirs &&
                    invokeDirectiveHook(
                        vnode,
                        null,
                        parentComponent,
                        "unmounted",
                    );
            }, parentSuspense);
        }
    };
    const remove2 = (vnode) => {
        const { type, el, anchor, transition } = vnode;
        if (type === Fragment) {
            {
                removeFragment(el, anchor);
            }
            return;
        }
        if (type === Static) {
            removeStaticNode(vnode);
            return;
        }
        const performRemove = () => {
            hostRemove(el);
            if (transition && !transition.persisted && transition.afterLeave) {
                transition.afterLeave();
            }
        };
        if (vnode.shapeFlag & 1 && transition && !transition.persisted) {
            const { leave, delayLeave } = transition;
            const performLeave = () => leave(el, performRemove);
            if (delayLeave) {
                delayLeave(vnode.el, performRemove, performLeave);
            } else {
                performLeave();
            }
        } else {
            performRemove();
        }
    };
    const removeFragment = (cur, end) => {
        let next;
        while (cur !== end) {
            next = hostNextSibling(cur);
            hostRemove(cur);
            cur = next;
        }
        hostRemove(end);
    };
    const unmountComponent = (instance, parentSuspense, doRemove) => {
        const { bum, scope, job, subTree, um, m, a } = instance;
        invalidateMount(m);
        invalidateMount(a);
        if (bum) {
            invokeArrayFns(bum);
        }
        scope.stop();
        if (job) {
            job.flags |= 8;
            unmount(subTree, instance, parentSuspense, doRemove);
        }
        if (um) {
            queuePostRenderEffect(um, parentSuspense);
        }
        queuePostRenderEffect(() => {
            instance.isUnmounted = true;
        }, parentSuspense);
        if (
            parentSuspense &&
            parentSuspense.pendingBranch &&
            !parentSuspense.isUnmounted &&
            instance.asyncDep &&
            !instance.asyncResolved &&
            instance.suspenseId === parentSuspense.pendingId
        ) {
            parentSuspense.deps--;
            if (parentSuspense.deps === 0) {
                parentSuspense.resolve();
            }
        }
    };
    const unmountChildren = (
        children,
        parentComponent,
        parentSuspense,
        doRemove = false,
        optimized = false,
        start = 0,
    ) => {
        for (let i = start; i < children.length; i++) {
            unmount(
                children[i],
                parentComponent,
                parentSuspense,
                doRemove,
                optimized,
            );
        }
    };
    const getNextHostNode = (vnode) => {
        if (vnode.shapeFlag & 6) {
            return getNextHostNode(vnode.component.subTree);
        }
        if (vnode.shapeFlag & 128) {
            return vnode.suspense.next();
        }
        const el = hostNextSibling(vnode.anchor || vnode.el);
        const teleportEnd = el && el[TeleportEndKey];
        return teleportEnd ? hostNextSibling(teleportEnd) : el;
    };
    let isFlushing = false;
    const render = (vnode, container, namespace) => {
        if (vnode == null) {
            if (container._vnode) {
                unmount(container._vnode, null, null, true);
            }
        } else {
            patch(
                container._vnode || null,
                vnode,
                container,
                null,
                null,
                null,
                namespace,
            );
        }
        container._vnode = vnode;
        if (!isFlushing) {
            isFlushing = true;
            flushPreFlushCbs();
            flushPostFlushCbs();
            isFlushing = false;
        }
    };
    const internals = {
        p: patch,
        um: unmount,
        m: move,
        r: remove2,
        mt: mountComponent,
        mc: mountChildren,
        pc: patchChildren,
        pbc: patchBlockChildren,
        n: getNextHostNode,
        o: options,
    };
    let hydrate;
    return {
        render,
        hydrate,
        createApp: createAppAPI(render),
    };
}
function resolveChildrenNamespace({ type, props }, currentNamespace) {
    return (currentNamespace === "svg" && type === "foreignObject") ||
        (currentNamespace === "mathml" &&
            type === "annotation-xml" &&
            props &&
            props.encoding &&
            props.encoding.includes("html"))
        ? void 0
        : currentNamespace;
}
function toggleRecurse({ effect: effect2, job }, allowed) {
    if (allowed) {
        effect2.flags |= 32;
        job.flags |= 4;
    } else {
        effect2.flags &= -33;
        job.flags &= -5;
    }
}
function needTransition(parentSuspense, transition) {
    return (
        (!parentSuspense ||
            (parentSuspense && !parentSuspense.pendingBranch)) &&
        transition &&
        !transition.persisted
    );
}
function traverseStaticChildren(n1, n2, shallow = false) {
    const ch1 = n1.children;
    const ch2 = n2.children;
    if (isArray(ch1) && isArray(ch2)) {
        for (let i = 0; i < ch1.length; i++) {
            const c1 = ch1[i];
            let c2 = ch2[i];
            if (c2.shapeFlag & 1 && !c2.dynamicChildren) {
                if (c2.patchFlag <= 0 || c2.patchFlag === 32) {
                    c2 = ch2[i] = cloneIfMounted(ch2[i]);
                    c2.el = c1.el;
                }
                if (!shallow && c2.patchFlag !== -2)
                    traverseStaticChildren(c1, c2);
            }
            if (c2.type === Text) {
                c2.el = c1.el;
            }
        }
    }
}
function getSequence(arr) {
    const p2 = arr.slice();
    const result = [0];
    let i, j, u, v, c;
    const len = arr.length;
    for (i = 0; i < len; i++) {
        const arrI = arr[i];
        if (arrI !== 0) {
            j = result[result.length - 1];
            if (arr[j] < arrI) {
                p2[i] = j;
                result.push(i);
                continue;
            }
            u = 0;
            v = result.length - 1;
            while (u < v) {
                c = (u + v) >> 1;
                if (arr[result[c]] < arrI) {
                    u = c + 1;
                } else {
                    v = c;
                }
            }
            if (arrI < arr[result[u]]) {
                if (u > 0) {
                    p2[i] = result[u - 1];
                }
                result[u] = i;
            }
        }
    }
    u = result.length;
    v = result[u - 1];
    while (u-- > 0) {
        result[u] = v;
        v = p2[v];
    }
    return result;
}
function locateNonHydratedAsyncRoot(instance) {
    const subComponent = instance.subTree.component;
    if (subComponent) {
        if (subComponent.asyncDep && !subComponent.asyncResolved) {
            return subComponent;
        } else {
            return locateNonHydratedAsyncRoot(subComponent);
        }
    }
}
function invalidateMount(hooks) {
    if (hooks) {
        for (let i = 0; i < hooks.length; i++) hooks[i].flags |= 8;
    }
}
const ssrContextKey = Symbol.for("v-scx");
const useSSRContext = () => {
    {
        const ctx = inject(ssrContextKey);
        return ctx;
    }
};
function watch(source, cb, options) {
    return doWatch(source, cb, options);
}
function doWatch(source, cb, options = EMPTY_OBJ) {
    const { immediate, deep, flush, once } = options;
    const baseWatchOptions = extend({}, options);
    const runsImmediately = (cb && immediate) || (!cb && flush !== "post");
    let ssrCleanup;
    if (isInSSRComponentSetup) {
        if (flush === "sync") {
            const ctx = useSSRContext();
            ssrCleanup = ctx.__watcherHandles || (ctx.__watcherHandles = []);
        } else if (!runsImmediately) {
            const watchStopHandle = () => {};
            watchStopHandle.stop = NOOP;
            watchStopHandle.resume = NOOP;
            watchStopHandle.pause = NOOP;
            return watchStopHandle;
        }
    }
    const instance = currentInstance;
    baseWatchOptions.call = (fn, type, args) =>
        callWithAsyncErrorHandling(fn, instance, type, args);
    let isPre = false;
    if (flush === "post") {
        baseWatchOptions.scheduler = (job) => {
            queuePostRenderEffect(job, instance && instance.suspense);
        };
    } else if (flush !== "sync") {
        isPre = true;
        baseWatchOptions.scheduler = (job, isFirstRun) => {
            if (isFirstRun) {
                job();
            } else {
                queueJob(job);
            }
        };
    }
    baseWatchOptions.augmentJob = (job) => {
        if (cb) {
            job.flags |= 4;
        }
        if (isPre) {
            job.flags |= 2;
            if (instance) {
                job.id = instance.uid;
                job.i = instance;
            }
        }
    };
    const watchHandle = watch$1(source, cb, baseWatchOptions);
    if (isInSSRComponentSetup) {
        if (ssrCleanup) {
            ssrCleanup.push(watchHandle);
        } else if (runsImmediately) {
            watchHandle();
        }
    }
    return watchHandle;
}
function instanceWatch(source, value, options) {
    const publicThis = this.proxy;
    const getter = isString(source)
        ? source.includes(".")
            ? createPathGetter(publicThis, source)
            : () => publicThis[source]
        : source.bind(publicThis, publicThis);
    let cb;
    if (isFunction(value)) {
        cb = value;
    } else {
        cb = value.handler;
        options = value;
    }
    const reset = setCurrentInstance(this);
    const res = doWatch(getter, cb.bind(publicThis), options);
    reset();
    return res;
}
function createPathGetter(ctx, path) {
    const segments = path.split(".");
    return () => {
        let cur = ctx;
        for (let i = 0; i < segments.length && cur; i++) {
            cur = cur[segments[i]];
        }
        return cur;
    };
}
const getModelModifiers = (props, modelName) => {
    return modelName === "modelValue" || modelName === "model-value"
        ? props.modelModifiers
        : props[`${modelName}Modifiers`] ||
              props[`${camelize(modelName)}Modifiers`] ||
              props[`${hyphenate(modelName)}Modifiers`];
};
function emit(instance, event, ...rawArgs) {
    if (instance.isUnmounted) return;
    const props = instance.vnode.props || EMPTY_OBJ;
    let args = rawArgs;
    const isModelListener2 = event.startsWith("update:");
    const modifiers =
        isModelListener2 && getModelModifiers(props, event.slice(7));
    if (modifiers) {
        if (modifiers.trim) {
            args = rawArgs.map((a) => (isString(a) ? a.trim() : a));
        }
        if (modifiers.number) {
            args = rawArgs.map(looseToNumber);
        }
    }
    let handlerName;
    let handler =
        props[(handlerName = toHandlerKey(event))] || // also try camelCase event handler (#2249)
        props[(handlerName = toHandlerKey(camelize(event)))];
    if (!handler && isModelListener2) {
        handler = props[(handlerName = toHandlerKey(hyphenate(event)))];
    }
    if (handler) {
        callWithAsyncErrorHandling(handler, instance, 6, args);
    }
    const onceHandler = props[handlerName + `Once`];
    if (onceHandler) {
        if (!instance.emitted) {
            instance.emitted = {};
        } else if (instance.emitted[handlerName]) {
            return;
        }
        instance.emitted[handlerName] = true;
        callWithAsyncErrorHandling(onceHandler, instance, 6, args);
    }
}
function normalizeEmitsOptions(comp, appContext, asMixin = false) {
    const cache = appContext.emitsCache;
    const cached = cache.get(comp);
    if (cached !== void 0) {
        return cached;
    }
    const raw = comp.emits;
    let normalized = {};
    let hasExtends = false;
    if (!isFunction(comp)) {
        const extendEmits = (raw2) => {
            const normalizedFromExtend = normalizeEmitsOptions(
                raw2,
                appContext,
                true,
            );
            if (normalizedFromExtend) {
                hasExtends = true;
                extend(normalized, normalizedFromExtend);
            }
        };
        if (!asMixin && appContext.mixins.length) {
            appContext.mixins.forEach(extendEmits);
        }
        if (comp.extends) {
            extendEmits(comp.extends);
        }
        if (comp.mixins) {
            comp.mixins.forEach(extendEmits);
        }
    }
    if (!raw && !hasExtends) {
        if (isObject(comp)) {
            cache.set(comp, null);
        }
        return null;
    }
    if (isArray(raw)) {
        raw.forEach((key) => (normalized[key] = null));
    } else {
        extend(normalized, raw);
    }
    if (isObject(comp)) {
        cache.set(comp, normalized);
    }
    return normalized;
}
function isEmitListener(options, key) {
    if (!options || !isOn(key)) {
        return false;
    }
    key = key.slice(2).replace(/Once$/, "");
    return (
        hasOwn(options, key[0].toLowerCase() + key.slice(1)) ||
        hasOwn(options, hyphenate(key)) ||
        hasOwn(options, key)
    );
}
function markAttrsAccessed() {}
function renderComponentRoot(instance) {
    const {
        type: Component,
        vnode,
        proxy,
        withProxy,
        propsOptions: [propsOptions],
        slots,
        attrs,
        emit: emit2,
        render,
        renderCache,
        props,
        data,
        setupState,
        ctx,
        inheritAttrs,
    } = instance;
    const prev = setCurrentRenderingInstance(instance);
    let result;
    let fallthroughAttrs;
    try {
        if (vnode.shapeFlag & 4) {
            const proxyToUse = withProxy || proxy;
            const thisProxy = false
                ? new Proxy(proxyToUse, {
                      get(target, key, receiver) {
                          warn$1(
                              `Property '${String(
                                  key,
                              )}' was accessed via 'this'. Avoid using 'this' in templates.`,
                          );
                          return Reflect.get(target, key, receiver);
                      },
                  })
                : proxyToUse;
            result = normalizeVNode(
                render.call(
                    thisProxy,
                    proxyToUse,
                    renderCache,
                    false ? shallowReadonly(props) : props,
                    setupState,
                    data,
                    ctx,
                ),
            );
            fallthroughAttrs = attrs;
        } else {
            const render2 = Component;
            if (false);
            result = normalizeVNode(
                render2.length > 1
                    ? render2(
                          false ? shallowReadonly(props) : props,
                          false
                              ? {
                                    get attrs() {
                                        markAttrsAccessed();
                                        return shallowReadonly(attrs);
                                    },
                                    slots,
                                    emit: emit2,
                                }
                              : { attrs, slots, emit: emit2 },
                      )
                    : render2(false ? shallowReadonly(props) : props, null),
            );
            fallthroughAttrs = Component.props
                ? attrs
                : getFunctionalFallthrough(attrs);
        }
    } catch (err) {
        blockStack.length = 0;
        handleError(err, instance, 1);
        result = createVNode(Comment);
    }
    let root = result;
    if (fallthroughAttrs && inheritAttrs !== false) {
        const keys = Object.keys(fallthroughAttrs);
        const { shapeFlag } = root;
        if (keys.length) {
            if (shapeFlag & (1 | 6)) {
                if (propsOptions && keys.some(isModelListener)) {
                    fallthroughAttrs = filterModelListeners(
                        fallthroughAttrs,
                        propsOptions,
                    );
                }
                root = cloneVNode(root, fallthroughAttrs, false, true);
            }
        }
    }
    if (vnode.dirs) {
        root = cloneVNode(root, null, false, true);
        root.dirs = root.dirs ? root.dirs.concat(vnode.dirs) : vnode.dirs;
    }
    if (vnode.transition) {
        setTransitionHooks(root, vnode.transition);
    }
    {
        result = root;
    }
    setCurrentRenderingInstance(prev);
    return result;
}
const getFunctionalFallthrough = (attrs) => {
    let res;
    for (const key in attrs) {
        if (key === "class" || key === "style" || isOn(key)) {
            (res || (res = {}))[key] = attrs[key];
        }
    }
    return res;
};
const filterModelListeners = (attrs, props) => {
    const res = {};
    for (const key in attrs) {
        if (!isModelListener(key) || !(key.slice(9) in props)) {
            res[key] = attrs[key];
        }
    }
    return res;
};
function shouldUpdateComponent(prevVNode, nextVNode, optimized) {
    const { props: prevProps, children: prevChildren, component } = prevVNode;
    const { props: nextProps, children: nextChildren, patchFlag } = nextVNode;
    const emits = component.emitsOptions;
    if (nextVNode.dirs || nextVNode.transition) {
        return true;
    }
    if (optimized && patchFlag >= 0) {
        if (patchFlag & 1024) {
            return true;
        }
        if (patchFlag & 16) {
            if (!prevProps) {
                return !!nextProps;
            }
            return hasPropsChanged(prevProps, nextProps, emits);
        } else if (patchFlag & 8) {
            const dynamicProps = nextVNode.dynamicProps;
            for (let i = 0; i < dynamicProps.length; i++) {
                const key = dynamicProps[i];
                if (
                    nextProps[key] !== prevProps[key] &&
                    !isEmitListener(emits, key)
                ) {
                    return true;
                }
            }
        }
    } else {
        if (prevChildren || nextChildren) {
            if (!nextChildren || !nextChildren.$stable) {
                return true;
            }
        }
        if (prevProps === nextProps) {
            return false;
        }
        if (!prevProps) {
            return !!nextProps;
        }
        if (!nextProps) {
            return true;
        }
        return hasPropsChanged(prevProps, nextProps, emits);
    }
    return false;
}
function hasPropsChanged(prevProps, nextProps, emitsOptions) {
    const nextKeys = Object.keys(nextProps);
    if (nextKeys.length !== Object.keys(prevProps).length) {
        return true;
    }
    for (let i = 0; i < nextKeys.length; i++) {
        const key = nextKeys[i];
        if (
            nextProps[key] !== prevProps[key] &&
            !isEmitListener(emitsOptions, key)
        ) {
            return true;
        }
    }
    return false;
}
function updateHOCHostEl({ vnode, parent }, el) {
    while (parent) {
        const root = parent.subTree;
        if (root.suspense && root.suspense.activeBranch === vnode) {
            root.el = vnode.el;
        }
        if (root === vnode) {
            (vnode = parent.vnode).el = el;
            parent = parent.parent;
        } else {
            break;
        }
    }
}
const isSuspense = (type) => type.__isSuspense;
function queueEffectWithSuspense(fn, suspense) {
    if (suspense && suspense.pendingBranch) {
        if (isArray(fn)) {
            suspense.effects.push(...fn);
        } else {
            suspense.effects.push(fn);
        }
    } else {
        queuePostFlushCb(fn);
    }
}
const Fragment = Symbol.for("v-fgt");
const Text = Symbol.for("v-txt");
const Comment = Symbol.for("v-cmt");
const Static = Symbol.for("v-stc");
const blockStack = [];
let currentBlock = null;
function openBlock(disableTracking = false) {
    blockStack.push((currentBlock = disableTracking ? null : []));
}
function closeBlock() {
    blockStack.pop();
    currentBlock = blockStack[blockStack.length - 1] || null;
}
let isBlockTreeEnabled = 1;
function setBlockTracking(value, inVOnce = false) {
    isBlockTreeEnabled += value;
    if (value < 0 && currentBlock && inVOnce) {
        currentBlock.hasOnce = true;
    }
}
function setupBlock(vnode) {
    vnode.dynamicChildren =
        isBlockTreeEnabled > 0 ? currentBlock || EMPTY_ARR : null;
    closeBlock();
    if (isBlockTreeEnabled > 0 && currentBlock) {
        currentBlock.push(vnode);
    }
    return vnode;
}
function createElementBlock(
    type,
    props,
    children,
    patchFlag,
    dynamicProps,
    shapeFlag,
) {
    return setupBlock(
        createBaseVNode(
            type,
            props,
            children,
            patchFlag,
            dynamicProps,
            shapeFlag,
            true,
        ),
    );
}
function createBlock(type, props, children, patchFlag, dynamicProps) {
    return setupBlock(
        createVNode(type, props, children, patchFlag, dynamicProps, true),
    );
}
function isVNode(value) {
    return value ? value.__v_isVNode === true : false;
}
function isSameVNodeType(n1, n2) {
    return n1.type === n2.type && n1.key === n2.key;
}
const normalizeKey = ({ key }) => (key != null ? key : null);
const normalizeRef = ({ ref: ref3, ref_key, ref_for }) => {
    if (typeof ref3 === "number") {
        ref3 = "" + ref3;
    }
    return ref3 != null
        ? isString(ref3) || isRef(ref3) || isFunction(ref3)
            ? { i: currentRenderingInstance, r: ref3, k: ref_key, f: !!ref_for }
            : ref3
        : null;
};
function createBaseVNode(
    type,
    props = null,
    children = null,
    patchFlag = 0,
    dynamicProps = null,
    shapeFlag = type === Fragment ? 0 : 1,
    isBlockNode = false,
    needFullChildrenNormalization = false,
) {
    const vnode = {
        __v_isVNode: true,
        __v_skip: true,
        type,
        props,
        key: props && normalizeKey(props),
        ref: props && normalizeRef(props),
        scopeId: currentScopeId,
        slotScopeIds: null,
        children,
        component: null,
        suspense: null,
        ssContent: null,
        ssFallback: null,
        dirs: null,
        transition: null,
        el: null,
        anchor: null,
        target: null,
        targetStart: null,
        targetAnchor: null,
        staticCount: 0,
        shapeFlag,
        patchFlag,
        dynamicProps,
        dynamicChildren: null,
        appContext: null,
        ctx: currentRenderingInstance,
    };
    if (needFullChildrenNormalization) {
        normalizeChildren(vnode, children);
        if (shapeFlag & 128) {
            type.normalize(vnode);
        }
    } else if (children) {
        vnode.shapeFlag |= isString(children) ? 8 : 16;
    }
    if (
        isBlockTreeEnabled > 0 && // avoid a block node from tracking itself
        !isBlockNode && // has current parent block
        currentBlock && // presence of a patch flag indicates this node needs patching on updates.
        // component nodes also should always be patched, because even if the
        // component doesn't need to update, it needs to persist the instance on to
        // the next vnode so that it can be properly unmounted later.
        (vnode.patchFlag > 0 || shapeFlag & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
        // vnode should not be considered dynamic due to handler caching.
        vnode.patchFlag !== 32
    ) {
        currentBlock.push(vnode);
    }
    return vnode;
}
const createVNode = _createVNode;
function _createVNode(
    type,
    props = null,
    children = null,
    patchFlag = 0,
    dynamicProps = null,
    isBlockNode = false,
) {
    if (!type || type === NULL_DYNAMIC_COMPONENT) {
        type = Comment;
    }
    if (isVNode(type)) {
        const cloned = cloneVNode(
            type,
            props,
            true,
            /* mergeRef: true */
        );
        if (children) {
            normalizeChildren(cloned, children);
        }
        if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock) {
            if (cloned.shapeFlag & 6) {
                currentBlock[currentBlock.indexOf(type)] = cloned;
            } else {
                currentBlock.push(cloned);
            }
        }
        cloned.patchFlag = -2;
        return cloned;
    }
    if (isClassComponent(type)) {
        type = type.__vccOpts;
    }
    if (props) {
        props = guardReactiveProps(props);
        let { class: klass, style } = props;
        if (klass && !isString(klass)) {
            props.class = normalizeClass(klass);
        }
        if (isObject(style)) {
            if (isProxy(style) && !isArray(style)) {
                style = extend({}, style);
            }
            props.style = normalizeStyle(style);
        }
    }
    const shapeFlag = isString(type)
        ? 1
        : isSuspense(type)
          ? 128
          : isTeleport(type)
            ? 64
            : isObject(type)
              ? 4
              : isFunction(type)
                ? 2
                : 0;
    return createBaseVNode(
        type,
        props,
        children,
        patchFlag,
        dynamicProps,
        shapeFlag,
        isBlockNode,
        true,
    );
}
function guardReactiveProps(props) {
    if (!props) return null;
    return isProxy(props) || isInternalObject(props)
        ? extend({}, props)
        : props;
}
function cloneVNode(
    vnode,
    extraProps,
    mergeRef = false,
    cloneTransition = false,
) {
    const { props, ref: ref3, patchFlag, children, transition } = vnode;
    const mergedProps = extraProps
        ? mergeProps(props || {}, extraProps)
        : props;
    const cloned = {
        __v_isVNode: true,
        __v_skip: true,
        type: vnode.type,
        props: mergedProps,
        key: mergedProps && normalizeKey(mergedProps),
        ref:
            extraProps && extraProps.ref
                ? // #2078 in the case of <component :is="vnode" ref="extra"/>
                  // if the vnode itself already has a ref, cloneVNode will need to merge
                  // the refs so the single vnode can be set on multiple refs
                  mergeRef && ref3
                    ? isArray(ref3)
                        ? ref3.concat(normalizeRef(extraProps))
                        : [ref3, normalizeRef(extraProps)]
                    : normalizeRef(extraProps)
                : ref3,
        scopeId: vnode.scopeId,
        slotScopeIds: vnode.slotScopeIds,
        children,
        target: vnode.target,
        targetStart: vnode.targetStart,
        targetAnchor: vnode.targetAnchor,
        staticCount: vnode.staticCount,
        shapeFlag: vnode.shapeFlag,
        // if the vnode is cloned with extra props, we can no longer assume its
        // existing patch flag to be reliable and need to add the FULL_PROPS flag.
        // note: preserve flag for fragments since they use the flag for children
        // fast paths only.
        patchFlag:
            extraProps && vnode.type !== Fragment
                ? patchFlag === -1
                    ? 16
                    : patchFlag | 16
                : patchFlag,
        dynamicProps: vnode.dynamicProps,
        dynamicChildren: vnode.dynamicChildren,
        appContext: vnode.appContext,
        dirs: vnode.dirs,
        transition,
        // These should technically only be non-null on mounted VNodes. However,
        // they *should* be copied for kept-alive vnodes. So we just always copy
        // them since them being non-null during a mount doesn't affect the logic as
        // they will simply be overwritten.
        component: vnode.component,
        suspense: vnode.suspense,
        ssContent: vnode.ssContent && cloneVNode(vnode.ssContent),
        ssFallback: vnode.ssFallback && cloneVNode(vnode.ssFallback),
        el: vnode.el,
        anchor: vnode.anchor,
        ctx: vnode.ctx,
        ce: vnode.ce,
    };
    if (transition && cloneTransition) {
        setTransitionHooks(cloned, transition.clone(cloned));
    }
    return cloned;
}
function createTextVNode(text = " ", flag = 0) {
    return createVNode(Text, null, text, flag);
}
function createStaticVNode(content, numberOfNodes) {
    const vnode = createVNode(Static, null, content);
    vnode.staticCount = numberOfNodes;
    return vnode;
}
function createCommentVNode(text = "", asBlock = false) {
    return asBlock
        ? (openBlock(), createBlock(Comment, null, text))
        : createVNode(Comment, null, text);
}
function normalizeVNode(child) {
    if (child == null || typeof child === "boolean") {
        return createVNode(Comment);
    } else if (isArray(child)) {
        return createVNode(
            Fragment,
            null,
            // #3666, avoid reference pollution when reusing vnode
            child.slice(),
        );
    } else if (isVNode(child)) {
        return cloneIfMounted(child);
    } else {
        return createVNode(Text, null, String(child));
    }
}
function cloneIfMounted(child) {
    return (child.el === null && child.patchFlag !== -1) || child.memo
        ? child
        : cloneVNode(child);
}
function normalizeChildren(vnode, children) {
    let type = 0;
    const { shapeFlag } = vnode;
    if (children == null) {
        children = null;
    } else if (isArray(children)) {
        type = 16;
    } else if (typeof children === "object") {
        if (shapeFlag & (1 | 64)) {
            const slot = children.default;
            if (slot) {
                slot._c && (slot._d = false);
                normalizeChildren(vnode, slot());
                slot._c && (slot._d = true);
            }
            return;
        } else {
            type = 32;
            const slotFlag = children._;
            if (!slotFlag && !isInternalObject(children)) {
                children._ctx = currentRenderingInstance;
            } else if (slotFlag === 3 && currentRenderingInstance) {
                if (currentRenderingInstance.slots._ === 1) {
                    children._ = 1;
                } else {
                    children._ = 2;
                    vnode.patchFlag |= 1024;
                }
            }
        }
    } else if (isFunction(children)) {
        children = { default: children, _ctx: currentRenderingInstance };
        type = 32;
    } else {
        children = String(children);
        if (shapeFlag & 64) {
            type = 16;
            children = [createTextVNode(children)];
        } else {
            type = 8;
        }
    }
    vnode.children = children;
    vnode.shapeFlag |= type;
}
function mergeProps(...args) {
    const ret = {};
    for (let i = 0; i < args.length; i++) {
        const toMerge = args[i];
        for (const key in toMerge) {
            if (key === "class") {
                if (ret.class !== toMerge.class) {
                    ret.class = normalizeClass([ret.class, toMerge.class]);
                }
            } else if (key === "style") {
                ret.style = normalizeStyle([ret.style, toMerge.style]);
            } else if (isOn(key)) {
                const existing = ret[key];
                const incoming = toMerge[key];
                if (
                    incoming &&
                    existing !== incoming &&
                    !(isArray(existing) && existing.includes(incoming))
                ) {
                    ret[key] = existing
                        ? [].concat(existing, incoming)
                        : incoming;
                }
            } else if (key !== "") {
                ret[key] = toMerge[key];
            }
        }
    }
    return ret;
}
function invokeVNodeHook(hook, instance, vnode, prevVNode = null) {
    callWithAsyncErrorHandling(hook, instance, 7, [vnode, prevVNode]);
}
const emptyAppContext = createAppContext();
let uid = 0;
function createComponentInstance(vnode, parent, suspense) {
    const type = vnode.type;
    const appContext =
        (parent ? parent.appContext : vnode.appContext) || emptyAppContext;
    const instance = {
        uid: uid++,
        vnode,
        type,
        parent,
        appContext,
        root: null,
        // to be immediately set
        next: null,
        subTree: null,
        // will be set synchronously right after creation
        effect: null,
        update: null,
        // will be set synchronously right after creation
        job: null,
        scope: new EffectScope(
            true,
            /* detached */
        ),
        render: null,
        proxy: null,
        exposed: null,
        exposeProxy: null,
        withProxy: null,
        provides: parent ? parent.provides : Object.create(appContext.provides),
        ids: parent ? parent.ids : ["", 0, 0],
        accessCache: null,
        renderCache: [],
        // local resolved assets
        components: null,
        directives: null,
        // resolved props and emits options
        propsOptions: normalizePropsOptions(type, appContext),
        emitsOptions: normalizeEmitsOptions(type, appContext),
        // emit
        emit: null,
        // to be set immediately
        emitted: null,
        // props default value
        propsDefaults: EMPTY_OBJ,
        // inheritAttrs
        inheritAttrs: type.inheritAttrs,
        // state
        ctx: EMPTY_OBJ,
        data: EMPTY_OBJ,
        props: EMPTY_OBJ,
        attrs: EMPTY_OBJ,
        slots: EMPTY_OBJ,
        refs: EMPTY_OBJ,
        setupState: EMPTY_OBJ,
        setupContext: null,
        // suspense related
        suspense,
        suspenseId: suspense ? suspense.pendingId : 0,
        asyncDep: null,
        asyncResolved: false,
        // lifecycle hooks
        // not using enums here because it results in computed properties
        isMounted: false,
        isUnmounted: false,
        isDeactivated: false,
        bc: null,
        c: null,
        bm: null,
        m: null,
        bu: null,
        u: null,
        um: null,
        bum: null,
        da: null,
        a: null,
        rtg: null,
        rtc: null,
        ec: null,
        sp: null,
    };
    {
        instance.ctx = { _: instance };
    }
    instance.root = parent ? parent.root : instance;
    instance.emit = emit.bind(null, instance);
    if (vnode.ce) {
        vnode.ce(instance);
    }
    return instance;
}
let currentInstance = null;
let internalSetCurrentInstance;
let setInSSRSetupState;
{
    const g = getGlobalThis();
    const registerGlobalSetter = (key, setter) => {
        let setters;
        if (!(setters = g[key])) setters = g[key] = [];
        setters.push(setter);
        return (v) => {
            if (setters.length > 1) setters.forEach((set2) => set2(v));
            else setters[0](v);
        };
    };
    internalSetCurrentInstance = registerGlobalSetter(
        `__VUE_INSTANCE_SETTERS__`,
        (v) => (currentInstance = v),
    );
    setInSSRSetupState = registerGlobalSetter(
        `__VUE_SSR_SETTERS__`,
        (v) => (isInSSRComponentSetup = v),
    );
}
const setCurrentInstance = (instance) => {
    const prev = currentInstance;
    internalSetCurrentInstance(instance);
    instance.scope.on();
    return () => {
        instance.scope.off();
        internalSetCurrentInstance(prev);
    };
};
const unsetCurrentInstance = () => {
    currentInstance && currentInstance.scope.off();
    internalSetCurrentInstance(null);
};
function isStatefulComponent(instance) {
    return instance.vnode.shapeFlag & 4;
}
let isInSSRComponentSetup = false;
function setupComponent(instance, isSSR = false, optimized = false) {
    isSSR && setInSSRSetupState(isSSR);
    const { props, children } = instance.vnode;
    const isStateful = isStatefulComponent(instance);
    initProps(instance, props, isStateful, isSSR);
    initSlots(instance, children, optimized);
    const setupResult = isStateful
        ? setupStatefulComponent(instance, isSSR)
        : void 0;
    isSSR && setInSSRSetupState(false);
    return setupResult;
}
function setupStatefulComponent(instance, isSSR) {
    const Component = instance.type;
    instance.accessCache = /* @__PURE__ */ Object.create(null);
    instance.proxy = new Proxy(instance.ctx, PublicInstanceProxyHandlers);
    const { setup } = Component;
    if (setup) {
        pauseTracking();
        const setupContext = (instance.setupContext =
            setup.length > 1 ? createSetupContext(instance) : null);
        const reset = setCurrentInstance(instance);
        const setupResult = callWithErrorHandling(setup, instance, 0, [
            instance.props,
            setupContext,
        ]);
        const isAsyncSetup = isPromise$1(setupResult);
        resetTracking();
        reset();
        if ((isAsyncSetup || instance.sp) && !isAsyncWrapper(instance)) {
            markAsyncBoundary(instance);
        }
        if (isAsyncSetup) {
            setupResult.then(unsetCurrentInstance, unsetCurrentInstance);
            if (isSSR) {
                return setupResult
                    .then((resolvedResult) => {
                        handleSetupResult(instance, resolvedResult);
                    })
                    .catch((e) => {
                        handleError(e, instance, 0);
                    });
            } else {
                instance.asyncDep = setupResult;
            }
        } else {
            handleSetupResult(instance, setupResult);
        }
    } else {
        finishComponentSetup(instance);
    }
}
function handleSetupResult(instance, setupResult, isSSR) {
    if (isFunction(setupResult)) {
        if (instance.type.__ssrInlineRender) {
            instance.ssrRender = setupResult;
        } else {
            instance.render = setupResult;
        }
    } else if (isObject(setupResult)) {
        instance.setupState = proxyRefs(setupResult);
    } else;
    finishComponentSetup(instance);
}
function finishComponentSetup(instance, isSSR, skipOptions) {
    const Component = instance.type;
    if (!instance.render) {
        instance.render = Component.render || NOOP;
    }
    {
        const reset = setCurrentInstance(instance);
        pauseTracking();
        try {
            applyOptions(instance);
        } finally {
            resetTracking();
            reset();
        }
    }
}
const attrsProxyHandlers = {
    get(target, key) {
        track(target, "get", "");
        return target[key];
    },
};
function createSetupContext(instance) {
    const expose = (exposed) => {
        instance.exposed = exposed || {};
    };
    {
        return {
            attrs: new Proxy(instance.attrs, attrsProxyHandlers),
            slots: instance.slots,
            emit: instance.emit,
            expose,
        };
    }
}
function getComponentPublicInstance(instance) {
    if (instance.exposed) {
        return (
            instance.exposeProxy ||
            (instance.exposeProxy = new Proxy(
                proxyRefs(markRaw(instance.exposed)),
                {
                    get(target, key) {
                        if (key in target) {
                            return target[key];
                        } else if (key in publicPropertiesMap) {
                            return publicPropertiesMap[key](instance);
                        }
                    },
                    has(target, key) {
                        return key in target || key in publicPropertiesMap;
                    },
                },
            ))
        );
    } else {
        return instance.proxy;
    }
}
const classifyRE = /(?:^|[-_])(\w)/g;
const classify = (str) =>
    str.replace(classifyRE, (c) => c.toUpperCase()).replace(/[-_]/g, "");
function getComponentName(Component, includeInferred = true) {
    return isFunction(Component)
        ? Component.displayName || Component.name
        : Component.name || (includeInferred && Component.__name);
}
function formatComponentName(instance, Component, isRoot = false) {
    let name = getComponentName(Component);
    if (!name && Component.__file) {
        const match = Component.__file.match(/([^/\\]+)\.\w+$/);
        if (match) {
            name = match[1];
        }
    }
    if (!name && instance && instance.parent) {
        const inferFromRegistry = (registry) => {
            for (const key in registry) {
                if (registry[key] === Component) {
                    return key;
                }
            }
        };
        name =
            inferFromRegistry(
                instance.components || instance.parent.type.components,
            ) || inferFromRegistry(instance.appContext.components);
    }
    return name ? classify(name) : isRoot ? `App` : `Anonymous`;
}
function isClassComponent(value) {
    return isFunction(value) && "__vccOpts" in value;
}
const computed = (getterOrOptions, debugOptions) => {
    const c = computed$1(getterOrOptions, debugOptions, isInSSRComponentSetup);
    return c;
};
const version$1 = "3.5.13";
/**
 * @vue/runtime-dom v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
let policy = void 0;
const tt = typeof window !== "undefined" && window.trustedTypes;
if (tt) {
    try {
        policy = /* @__PURE__ */ tt.createPolicy("vue", {
            createHTML: (val) => val,
        });
    } catch (e) {}
}
const unsafeToTrustedHTML = policy
    ? (val) => policy.createHTML(val)
    : (val) => val;
const svgNS = "http://www.w3.org/2000/svg";
const mathmlNS = "http://www.w3.org/1998/Math/MathML";
const doc = typeof document !== "undefined" ? document : null;
const templateContainer = doc && /* @__PURE__ */ doc.createElement("template");
const nodeOps = {
    insert: (child, parent, anchor) => {
        parent.insertBefore(child, anchor || null);
    },
    remove: (child) => {
        const parent = child.parentNode;
        if (parent) {
            parent.removeChild(child);
        }
    },
    createElement: (tag, namespace, is, props) => {
        const el =
            namespace === "svg"
                ? doc.createElementNS(svgNS, tag)
                : namespace === "mathml"
                  ? doc.createElementNS(mathmlNS, tag)
                  : is
                    ? doc.createElement(tag, { is })
                    : doc.createElement(tag);
        if (tag === "select" && props && props.multiple != null) {
            el.setAttribute("multiple", props.multiple);
        }
        return el;
    },
    createText: (text) => doc.createTextNode(text),
    createComment: (text) => doc.createComment(text),
    setText: (node, text) => {
        node.nodeValue = text;
    },
    setElementText: (el, text) => {
        el.textContent = text;
    },
    parentNode: (node) => node.parentNode,
    nextSibling: (node) => node.nextSibling,
    querySelector: (selector) => doc.querySelector(selector),
    setScopeId(el, id) {
        el.setAttribute(id, "");
    },
    // __UNSAFE__
    // Reason: innerHTML.
    // Static content here can only come from compiled templates.
    // As long as the user only uses trusted templates, this is safe.
    insertStaticContent(content, parent, anchor, namespace, start, end) {
        const before = anchor ? anchor.previousSibling : parent.lastChild;
        if (start && (start === end || start.nextSibling)) {
            while (true) {
                parent.insertBefore(start.cloneNode(true), anchor);
                if (start === end || !(start = start.nextSibling)) break;
            }
        } else {
            templateContainer.innerHTML = unsafeToTrustedHTML(
                namespace === "svg"
                    ? `<svg>${content}</svg>`
                    : namespace === "mathml"
                      ? `<math>${content}</math>`
                      : content,
            );
            const template = templateContainer.content;
            if (namespace === "svg" || namespace === "mathml") {
                const wrapper = template.firstChild;
                while (wrapper.firstChild) {
                    template.appendChild(wrapper.firstChild);
                }
                template.removeChild(wrapper);
            }
            parent.insertBefore(template, anchor);
        }
        return [
            // first
            before ? before.nextSibling : parent.firstChild,
            // last
            anchor ? anchor.previousSibling : parent.lastChild,
        ];
    },
};
const vtcKey = Symbol("_vtc");
function patchClass(el, value, isSVG) {
    const transitionClasses = el[vtcKey];
    if (transitionClasses) {
        value = (
            value ? [value, ...transitionClasses] : [...transitionClasses]
        ).join(" ");
    }
    if (value == null) {
        el.removeAttribute("class");
    } else if (isSVG) {
        el.setAttribute("class", value);
    } else {
        el.className = value;
    }
}
const vShowOriginalDisplay = Symbol("_vod");
const vShowHidden = Symbol("_vsh");
const CSS_VAR_TEXT = Symbol("");
const displayRE = /(^|;)\s*display\s*:/;
function patchStyle(el, prev, next) {
    const style = el.style;
    const isCssString = isString(next);
    let hasControlledDisplay = false;
    if (next && !isCssString) {
        if (prev) {
            if (!isString(prev)) {
                for (const key in prev) {
                    if (next[key] == null) {
                        setStyle(style, key, "");
                    }
                }
            } else {
                for (const prevStyle of prev.split(";")) {
                    const key = prevStyle
                        .slice(0, prevStyle.indexOf(":"))
                        .trim();
                    if (next[key] == null) {
                        setStyle(style, key, "");
                    }
                }
            }
        }
        for (const key in next) {
            if (key === "display") {
                hasControlledDisplay = true;
            }
            setStyle(style, key, next[key]);
        }
    } else {
        if (isCssString) {
            if (prev !== next) {
                const cssVarText = style[CSS_VAR_TEXT];
                if (cssVarText) {
                    next += ";" + cssVarText;
                }
                style.cssText = next;
                hasControlledDisplay = displayRE.test(next);
            }
        } else if (prev) {
            el.removeAttribute("style");
        }
    }
    if (vShowOriginalDisplay in el) {
        el[vShowOriginalDisplay] = hasControlledDisplay ? style.display : "";
        if (el[vShowHidden]) {
            style.display = "none";
        }
    }
}
const importantRE = /\s*!important$/;
function setStyle(style, name, val) {
    if (isArray(val)) {
        val.forEach((v) => setStyle(style, name, v));
    } else {
        if (val == null) val = "";
        if (name.startsWith("--")) {
            style.setProperty(name, val);
        } else {
            const prefixed = autoPrefix(style, name);
            if (importantRE.test(val)) {
                style.setProperty(
                    hyphenate(prefixed),
                    val.replace(importantRE, ""),
                    "important",
                );
            } else {
                style[prefixed] = val;
            }
        }
    }
}
const prefixes = ["Webkit", "Moz", "ms"];
const prefixCache = {};
function autoPrefix(style, rawName) {
    const cached = prefixCache[rawName];
    if (cached) {
        return cached;
    }
    let name = camelize(rawName);
    if (name !== "filter" && name in style) {
        return (prefixCache[rawName] = name);
    }
    name = capitalize(name);
    for (let i = 0; i < prefixes.length; i++) {
        const prefixed = prefixes[i] + name;
        if (prefixed in style) {
            return (prefixCache[rawName] = prefixed);
        }
    }
    return rawName;
}
const xlinkNS = "http://www.w3.org/1999/xlink";
function patchAttr(
    el,
    key,
    value,
    isSVG,
    instance,
    isBoolean = isSpecialBooleanAttr(key),
) {
    if (isSVG && key.startsWith("xlink:")) {
        if (value == null) {
            el.removeAttributeNS(xlinkNS, key.slice(6, key.length));
        } else {
            el.setAttributeNS(xlinkNS, key, value);
        }
    } else {
        if (value == null || (isBoolean && !includeBooleanAttr(value))) {
            el.removeAttribute(key);
        } else {
            el.setAttribute(
                key,
                isBoolean ? "" : isSymbol(value) ? String(value) : value,
            );
        }
    }
}
function patchDOMProp(el, key, value, parentComponent, attrName) {
    if (key === "innerHTML" || key === "textContent") {
        if (value != null) {
            el[key] = key === "innerHTML" ? unsafeToTrustedHTML(value) : value;
        }
        return;
    }
    const tag = el.tagName;
    if (
        key === "value" &&
        tag !== "PROGRESS" && // custom elements may use _value internally
        !tag.includes("-")
    ) {
        const oldValue =
            tag === "OPTION" ? el.getAttribute("value") || "" : el.value;
        const newValue =
            value == null
                ? // #11647: value should be set as empty string for null and undefined,
                  // but <input type="checkbox"> should be set as 'on'.
                  el.type === "checkbox"
                    ? "on"
                    : ""
                : String(value);
        if (oldValue !== newValue || !("_value" in el)) {
            el.value = newValue;
        }
        if (value == null) {
            el.removeAttribute(key);
        }
        el._value = value;
        return;
    }
    let needRemove = false;
    if (value === "" || value == null) {
        const type = typeof el[key];
        if (type === "boolean") {
            value = includeBooleanAttr(value);
        } else if (value == null && type === "string") {
            value = "";
            needRemove = true;
        } else if (type === "number") {
            value = 0;
            needRemove = true;
        }
    }
    try {
        el[key] = value;
    } catch (e) {}
    needRemove && el.removeAttribute(attrName || key);
}
function addEventListener(el, event, handler, options) {
    el.addEventListener(event, handler, options);
}
function removeEventListener(el, event, handler, options) {
    el.removeEventListener(event, handler, options);
}
const veiKey = Symbol("_vei");
function patchEvent(el, rawName, prevValue, nextValue, instance = null) {
    const invokers = el[veiKey] || (el[veiKey] = {});
    const existingInvoker = invokers[rawName];
    if (nextValue && existingInvoker) {
        existingInvoker.value = nextValue;
    } else {
        const [name, options] = parseName(rawName);
        if (nextValue) {
            const invoker = (invokers[rawName] = createInvoker(
                nextValue,
                instance,
            ));
            addEventListener(el, name, invoker, options);
        } else if (existingInvoker) {
            removeEventListener(el, name, existingInvoker, options);
            invokers[rawName] = void 0;
        }
    }
}
const optionsModifierRE = /(?:Once|Passive|Capture)$/;
function parseName(name) {
    let options;
    if (optionsModifierRE.test(name)) {
        options = {};
        let m;
        while ((m = name.match(optionsModifierRE))) {
            name = name.slice(0, name.length - m[0].length);
            options[m[0].toLowerCase()] = true;
        }
    }
    const event = name[2] === ":" ? name.slice(3) : hyphenate(name.slice(2));
    return [event, options];
}
let cachedNow = 0;
const p = /* @__PURE__ */ Promise.resolve();
const getNow = () =>
    cachedNow || (p.then(() => (cachedNow = 0)), (cachedNow = Date.now()));
function createInvoker(initialValue, instance) {
    const invoker = (e) => {
        if (!e._vts) {
            e._vts = Date.now();
        } else if (e._vts <= invoker.attached) {
            return;
        }
        callWithAsyncErrorHandling(
            patchStopImmediatePropagation(e, invoker.value),
            instance,
            5,
            [e],
        );
    };
    invoker.value = initialValue;
    invoker.attached = getNow();
    return invoker;
}
function patchStopImmediatePropagation(e, value) {
    if (isArray(value)) {
        const originalStop = e.stopImmediatePropagation;
        e.stopImmediatePropagation = () => {
            originalStop.call(e);
            e._stopped = true;
        };
        return value.map((fn) => (e2) => !e2._stopped && fn && fn(e2));
    } else {
        return value;
    }
}
const isNativeOn = (key) =>
    key.charCodeAt(0) === 111 &&
    key.charCodeAt(1) === 110 && // lowercase letter
    key.charCodeAt(2) > 96 &&
    key.charCodeAt(2) < 123;
const patchProp = (
    el,
    key,
    prevValue,
    nextValue,
    namespace,
    parentComponent,
) => {
    const isSVG = namespace === "svg";
    if (key === "class") {
        patchClass(el, nextValue, isSVG);
    } else if (key === "style") {
        patchStyle(el, prevValue, nextValue);
    } else if (isOn(key)) {
        if (!isModelListener(key)) {
            patchEvent(el, key, prevValue, nextValue, parentComponent);
        }
    } else if (
        key[0] === "."
            ? ((key = key.slice(1)), true)
            : key[0] === "^"
              ? ((key = key.slice(1)), false)
              : shouldSetAsProp(el, key, nextValue, isSVG)
    ) {
        patchDOMProp(el, key, nextValue);
        if (
            !el.tagName.includes("-") &&
            (key === "value" || key === "checked" || key === "selected")
        ) {
            patchAttr(
                el,
                key,
                nextValue,
                isSVG,
                parentComponent,
                key !== "value",
            );
        }
    } else if (
        // #11081 force set props for possible async custom element
        el._isVueCE &&
        (/[A-Z]/.test(key) || !isString(nextValue))
    ) {
        patchDOMProp(el, camelize(key), nextValue, parentComponent, key);
    } else {
        if (key === "true-value") {
            el._trueValue = nextValue;
        } else if (key === "false-value") {
            el._falseValue = nextValue;
        }
        patchAttr(el, key, nextValue, isSVG);
    }
};
function shouldSetAsProp(el, key, value, isSVG) {
    if (isSVG) {
        if (key === "innerHTML" || key === "textContent") {
            return true;
        }
        if (key in el && isNativeOn(key) && isFunction(value)) {
            return true;
        }
        return false;
    }
    if (key === "spellcheck" || key === "draggable" || key === "translate") {
        return false;
    }
    if (key === "form") {
        return false;
    }
    if (key === "list" && el.tagName === "INPUT") {
        return false;
    }
    if (key === "type" && el.tagName === "TEXTAREA") {
        return false;
    }
    if (key === "width" || key === "height") {
        const tag = el.tagName;
        if (
            tag === "IMG" ||
            tag === "VIDEO" ||
            tag === "CANVAS" ||
            tag === "SOURCE"
        ) {
            return false;
        }
    }
    if (isNativeOn(key) && isString(value)) {
        return false;
    }
    return key in el;
}
const getModelAssigner = (vnode) => {
    const fn = vnode.props["onUpdate:modelValue"] || false;
    return isArray(fn) ? (value) => invokeArrayFns(fn, value) : fn;
};
function onCompositionStart(e) {
    e.target.composing = true;
}
function onCompositionEnd(e) {
    const target = e.target;
    if (target.composing) {
        target.composing = false;
        target.dispatchEvent(new Event("input"));
    }
}
const assignKey = Symbol("_assign");
const vModelText = {
    created(el, { modifiers: { lazy, trim, number } }, vnode) {
        el[assignKey] = getModelAssigner(vnode);
        const castToNumber =
            number || (vnode.props && vnode.props.type === "number");
        addEventListener(el, lazy ? "change" : "input", (e) => {
            if (e.target.composing) return;
            let domValue = el.value;
            if (trim) {
                domValue = domValue.trim();
            }
            if (castToNumber) {
                domValue = looseToNumber(domValue);
            }
            el[assignKey](domValue);
        });
        if (trim) {
            addEventListener(el, "change", () => {
                el.value = el.value.trim();
            });
        }
        if (!lazy) {
            addEventListener(el, "compositionstart", onCompositionStart);
            addEventListener(el, "compositionend", onCompositionEnd);
            addEventListener(el, "change", onCompositionEnd);
        }
    },
    // set value on mounted so it's after min/max for type="range"
    mounted(el, { value }) {
        el.value = value == null ? "" : value;
    },
    beforeUpdate(
        el,
        { value, oldValue, modifiers: { lazy, trim, number } },
        vnode,
    ) {
        el[assignKey] = getModelAssigner(vnode);
        if (el.composing) return;
        const elValue =
            (number || el.type === "number") && !/^0\d/.test(el.value)
                ? looseToNumber(el.value)
                : el.value;
        const newValue = value == null ? "" : value;
        if (elValue === newValue) {
            return;
        }
        if (document.activeElement === el && el.type !== "range") {
            if (lazy && value === oldValue) {
                return;
            }
            if (trim && el.value.trim() === newValue) {
                return;
            }
        }
        el.value = newValue;
    },
};
const vModelSelect = {
    // <select multiple> value need to be deep traversed
    deep: true,
    created(el, { value, modifiers: { number } }, vnode) {
        const isSetModel = isSet(value);
        addEventListener(el, "change", () => {
            const selectedVal = Array.prototype.filter
                .call(el.options, (o) => o.selected)
                .map((o) =>
                    number ? looseToNumber(getValue(o)) : getValue(o),
                );
            el[assignKey](
                el.multiple
                    ? isSetModel
                        ? new Set(selectedVal)
                        : selectedVal
                    : selectedVal[0],
            );
            el._assigning = true;
            nextTick(() => {
                el._assigning = false;
            });
        });
        el[assignKey] = getModelAssigner(vnode);
    },
    // set value in mounted & updated because <select> relies on its children
    // <option>s.
    mounted(el, { value }) {
        setSelected(el, value);
    },
    beforeUpdate(el, _binding, vnode) {
        el[assignKey] = getModelAssigner(vnode);
    },
    updated(el, { value }) {
        if (!el._assigning) {
            setSelected(el, value);
        }
    },
};
function setSelected(el, value) {
    const isMultiple = el.multiple;
    const isArrayValue = isArray(value);
    if (isMultiple && !isArrayValue && !isSet(value)) {
        return;
    }
    for (let i = 0, l = el.options.length; i < l; i++) {
        const option = el.options[i];
        const optionValue = getValue(option);
        if (isMultiple) {
            if (isArrayValue) {
                const optionType = typeof optionValue;
                if (optionType === "string" || optionType === "number") {
                    option.selected = value.some(
                        (v) => String(v) === String(optionValue),
                    );
                } else {
                    option.selected = looseIndexOf(value, optionValue) > -1;
                }
            } else {
                option.selected = value.has(optionValue);
            }
        } else if (looseEqual(getValue(option), value)) {
            if (el.selectedIndex !== i) el.selectedIndex = i;
            return;
        }
    }
    if (!isMultiple && el.selectedIndex !== -1) {
        el.selectedIndex = -1;
    }
}
function getValue(el) {
    return "_value" in el ? el._value : el.value;
}
const rendererOptions = /* @__PURE__ */ extend({ patchProp }, nodeOps);
let renderer;
function ensureRenderer() {
    return renderer || (renderer = createRenderer(rendererOptions));
}
const createApp = (...args) => {
    const app = ensureRenderer().createApp(...args);
    const { mount } = app;
    app.mount = (containerOrSelector) => {
        const container = normalizeContainer(containerOrSelector);
        if (!container) return;
        const component = app._component;
        if (
            !isFunction(component) &&
            !component.render &&
            !component.template
        ) {
            component.template = container.innerHTML;
        }
        if (container.nodeType === 1) {
            container.textContent = "";
        }
        const proxy = mount(container, false, resolveRootNamespace(container));
        if (container instanceof Element) {
            container.removeAttribute("v-cloak");
            container.setAttribute("data-v-app", "");
        }
        return proxy;
    };
    return app;
};
function resolveRootNamespace(container) {
    if (container instanceof SVGElement) {
        return "svg";
    }
    if (
        typeof MathMLElement === "function" &&
        container instanceof MathMLElement
    ) {
        return "mathml";
    }
}
function normalizeContainer(container) {
    if (isString(container)) {
        const res = document.querySelector(container);
        return res;
    }
    return container;
}
/*!
 * pinia v2.3.1
 * (c) 2025 Eduardo San Martin Morote
 * @license MIT
 */
let activePinia;
const setActivePinia = (pinia2) => (activePinia = pinia2);
const piniaSymbol =
    /* istanbul ignore next */
    Symbol();
function isPlainObject(o) {
    return (
        o &&
        typeof o === "object" &&
        Object.prototype.toString.call(o) === "[object Object]" &&
        typeof o.toJSON !== "function"
    );
}
var MutationType;
(function (MutationType2) {
    MutationType2["direct"] = "direct";
    MutationType2["patchObject"] = "patch object";
    MutationType2["patchFunction"] = "patch function";
})(MutationType || (MutationType = {}));
function createPinia() {
    const scope = effectScope(true);
    const state = scope.run(() => ref({}));
    let _p = [];
    let toBeInstalled = [];
    const pinia2 = markRaw({
        install(app) {
            setActivePinia(pinia2);
            {
                pinia2._a = app;
                app.provide(piniaSymbol, pinia2);
                app.config.globalProperties.$pinia = pinia2;
                toBeInstalled.forEach((plugin) => _p.push(plugin));
                toBeInstalled = [];
            }
        },
        use(plugin) {
            if (!this._a && true) {
                toBeInstalled.push(plugin);
            } else {
                _p.push(plugin);
            }
            return this;
        },
        _p,
        // it's actually undefined here
        // @ts-expect-error
        _a: null,
        _e: scope,
        _s: /* @__PURE__ */ new Map(),
        state,
    });
    return pinia2;
}
const noop = () => {};
function addSubscription(subscriptions, callback, detached, onCleanup = noop) {
    subscriptions.push(callback);
    const removeSubscription = () => {
        const idx = subscriptions.indexOf(callback);
        if (idx > -1) {
            subscriptions.splice(idx, 1);
            onCleanup();
        }
    };
    if (!detached && getCurrentScope()) {
        onScopeDispose(removeSubscription);
    }
    return removeSubscription;
}
function triggerSubscriptions(subscriptions, ...args) {
    subscriptions.slice().forEach((callback) => {
        callback(...args);
    });
}
const fallbackRunWithContext = (fn) => fn();
const ACTION_MARKER = Symbol();
const ACTION_NAME = Symbol();
function mergeReactiveObjects(target, patchToApply) {
    if (target instanceof Map && patchToApply instanceof Map) {
        patchToApply.forEach((value, key) => target.set(key, value));
    } else if (target instanceof Set && patchToApply instanceof Set) {
        patchToApply.forEach(target.add, target);
    }
    for (const key in patchToApply) {
        if (!patchToApply.hasOwnProperty(key)) continue;
        const subPatch = patchToApply[key];
        const targetValue = target[key];
        if (
            isPlainObject(targetValue) &&
            isPlainObject(subPatch) &&
            target.hasOwnProperty(key) &&
            !isRef(subPatch) &&
            !isReactive(subPatch)
        ) {
            target[key] = mergeReactiveObjects(targetValue, subPatch);
        } else {
            target[key] = subPatch;
        }
    }
    return target;
}
const skipHydrateSymbol =
    /* istanbul ignore next */
    Symbol();
function shouldHydrate(obj) {
    return !isPlainObject(obj) || !obj.hasOwnProperty(skipHydrateSymbol);
}
const { assign } = Object;
function isComputed(o) {
    return !!(isRef(o) && o.effect);
}
function createOptionsStore(id, options, pinia2, hot) {
    const { state, actions, getters } = options;
    const initialState = pinia2.state.value[id];
    let store;
    function setup() {
        if (!initialState && true) {
            {
                pinia2.state.value[id] = state ? state() : {};
            }
        }
        const localState = toRefs(pinia2.state.value[id]);
        return assign(
            localState,
            actions,
            Object.keys(getters || {}).reduce((computedGetters, name) => {
                computedGetters[name] = markRaw(
                    computed(() => {
                        setActivePinia(pinia2);
                        const store2 = pinia2._s.get(id);
                        return getters[name].call(store2, store2);
                    }),
                );
                return computedGetters;
            }, {}),
        );
    }
    store = createSetupStore(id, setup, options, pinia2, hot, true);
    return store;
}
function createSetupStore(
    $id,
    setup,
    options = {},
    pinia2,
    hot,
    isOptionsStore,
) {
    let scope;
    const optionsForPlugin = assign({ actions: {} }, options);
    const $subscribeOptions = { deep: true };
    let isListening;
    let isSyncListening;
    let subscriptions = [];
    let actionSubscriptions = [];
    let debuggerEvents;
    const initialState = pinia2.state.value[$id];
    if (!isOptionsStore && !initialState && true) {
        {
            pinia2.state.value[$id] = {};
        }
    }
    ref({});
    let activeListener;
    function $patch(partialStateOrMutator) {
        let subscriptionMutation;
        isListening = isSyncListening = false;
        if (typeof partialStateOrMutator === "function") {
            partialStateOrMutator(pinia2.state.value[$id]);
            subscriptionMutation = {
                type: MutationType.patchFunction,
                storeId: $id,
                events: debuggerEvents,
            };
        } else {
            mergeReactiveObjects(
                pinia2.state.value[$id],
                partialStateOrMutator,
            );
            subscriptionMutation = {
                type: MutationType.patchObject,
                payload: partialStateOrMutator,
                storeId: $id,
                events: debuggerEvents,
            };
        }
        const myListenerId = (activeListener = Symbol());
        nextTick().then(() => {
            if (activeListener === myListenerId) {
                isListening = true;
            }
        });
        isSyncListening = true;
        triggerSubscriptions(
            subscriptions,
            subscriptionMutation,
            pinia2.state.value[$id],
        );
    }
    const $reset = isOptionsStore
        ? function $reset2() {
              const { state } = options;
              const newState = state ? state() : {};
              this.$patch(($state) => {
                  assign($state, newState);
              });
          }
        : /* istanbul ignore next */
          noop;
    function $dispose() {
        scope.stop();
        subscriptions = [];
        actionSubscriptions = [];
        pinia2._s.delete($id);
    }
    const action = (fn, name = "") => {
        if (ACTION_MARKER in fn) {
            fn[ACTION_NAME] = name;
            return fn;
        }
        const wrappedAction = function () {
            setActivePinia(pinia2);
            const args = Array.from(arguments);
            const afterCallbackList = [];
            const onErrorCallbackList = [];
            function after(callback) {
                afterCallbackList.push(callback);
            }
            function onError(callback) {
                onErrorCallbackList.push(callback);
            }
            triggerSubscriptions(actionSubscriptions, {
                args,
                name: wrappedAction[ACTION_NAME],
                store,
                after,
                onError,
            });
            let ret;
            try {
                ret = fn.apply(this && this.$id === $id ? this : store, args);
            } catch (error) {
                triggerSubscriptions(onErrorCallbackList, error);
                throw error;
            }
            if (ret instanceof Promise) {
                return ret
                    .then((value) => {
                        triggerSubscriptions(afterCallbackList, value);
                        return value;
                    })
                    .catch((error) => {
                        triggerSubscriptions(onErrorCallbackList, error);
                        return Promise.reject(error);
                    });
            }
            triggerSubscriptions(afterCallbackList, ret);
            return ret;
        };
        wrappedAction[ACTION_MARKER] = true;
        wrappedAction[ACTION_NAME] = name;
        return wrappedAction;
    };
    const partialStore = {
        _p: pinia2,
        // _s: scope,
        $id,
        $onAction: addSubscription.bind(null, actionSubscriptions),
        $patch,
        $reset,
        $subscribe(callback, options2 = {}) {
            const removeSubscription = addSubscription(
                subscriptions,
                callback,
                options2.detached,
                () => stopWatcher(),
            );
            const stopWatcher = scope.run(() =>
                watch(
                    () => pinia2.state.value[$id],
                    (state) => {
                        if (
                            options2.flush === "sync"
                                ? isSyncListening
                                : isListening
                        ) {
                            callback(
                                {
                                    storeId: $id,
                                    type: MutationType.direct,
                                    events: debuggerEvents,
                                },
                                state,
                            );
                        }
                    },
                    assign({}, $subscribeOptions, options2),
                ),
            );
            return removeSubscription;
        },
        $dispose,
    };
    const store = reactive(partialStore);
    pinia2._s.set($id, store);
    const runWithContext =
        (pinia2._a && pinia2._a.runWithContext) || fallbackRunWithContext;
    const setupStore = runWithContext(() =>
        pinia2._e.run(() =>
            (scope = effectScope()).run(() => setup({ action })),
        ),
    );
    for (const key in setupStore) {
        const prop = setupStore[key];
        if ((isRef(prop) && !isComputed(prop)) || isReactive(prop)) {
            if (!isOptionsStore) {
                if (initialState && shouldHydrate(prop)) {
                    if (isRef(prop)) {
                        prop.value = initialState[key];
                    } else {
                        mergeReactiveObjects(prop, initialState[key]);
                    }
                }
                {
                    pinia2.state.value[$id][key] = prop;
                }
            }
        } else if (typeof prop === "function") {
            const actionValue = action(prop, key);
            {
                setupStore[key] = actionValue;
            }
            optionsForPlugin.actions[key] = prop;
        } else;
    }
    {
        assign(store, setupStore);
        assign(toRaw(store), setupStore);
    }
    Object.defineProperty(store, "$state", {
        get: () => pinia2.state.value[$id],
        set: (state) => {
            $patch(($state) => {
                assign($state, state);
            });
        },
    });
    pinia2._p.forEach((extender) => {
        {
            assign(
                store,
                scope.run(() =>
                    extender({
                        store,
                        app: pinia2._a,
                        pinia: pinia2,
                        options: optionsForPlugin,
                    }),
                ),
            );
        }
    });
    if (initialState && isOptionsStore && options.hydrate) {
        options.hydrate(store.$state, initialState);
    }
    isListening = true;
    isSyncListening = true;
    return store;
}
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function defineStore(idOrOptions, setup, setupOptions) {
    let id;
    let options;
    const isSetupStore = typeof setup === "function";
    if (typeof idOrOptions === "string") {
        id = idOrOptions;
        options = isSetupStore ? setupOptions : setup;
    } else {
        options = idOrOptions;
        id = idOrOptions.id;
    }
    function useStore(pinia2, hot) {
        const hasContext = hasInjectionContext();
        pinia2 = // in test mode, ignore the argument provided as we can always retrieve a
            // pinia instance with getActivePinia()
            pinia2 || (hasContext ? inject(piniaSymbol, null) : null);
        if (pinia2) setActivePinia(pinia2);
        pinia2 = activePinia;
        if (!pinia2._s.has(id)) {
            if (isSetupStore) {
                createSetupStore(id, setup, options, pinia2);
            } else {
                createOptionsStore(id, options, pinia2);
            }
        }
        const store = pinia2._s.get(id);
        return store;
    }
    useStore.$id = id;
    return useStore;
}
const suspectProtoRx =
    /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx =
    /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
    if (
        key === "__proto__" ||
        (key === "constructor" &&
            value &&
            typeof value === "object" &&
            "prototype" in value)
    ) {
        warnKeyDropped(key);
        return;
    }
    return value;
}
function warnKeyDropped(key) {
    console.warn(
        `[destr] Dropping "${key}" key to prevent prototype pollution.`,
    );
}
function destr(value, options = {}) {
    if (typeof value !== "string") {
        return value;
    }
    const _value = value.trim();
    if (
        // eslint-disable-next-line unicorn/prefer-at
        value[0] === '"' &&
        value.endsWith('"') &&
        !value.includes("\\")
    ) {
        return _value.slice(1, -1);
    }
    if (_value.length <= 9) {
        const _lval = _value.toLowerCase();
        if (_lval === "true") {
            return true;
        }
        if (_lval === "false") {
            return false;
        }
        if (_lval === "undefined") {
            return void 0;
        }
        if (_lval === "null") {
            return null;
        }
        if (_lval === "nan") {
            return Number.NaN;
        }
        if (_lval === "infinity") {
            return Number.POSITIVE_INFINITY;
        }
        if (_lval === "-infinity") {
            return Number.NEGATIVE_INFINITY;
        }
    }
    if (!JsonSigRx.test(value)) {
        if (options.strict) {
            throw new SyntaxError("[destr] Invalid JSON");
        }
        return value;
    }
    try {
        if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
            if (options.strict) {
                throw new Error("[destr] Possible prototype pollution");
            }
            return JSON.parse(value, jsonParseTransform);
        }
        return JSON.parse(value);
    } catch (error) {
        if (options.strict) {
            throw error;
        }
        return value;
    }
}
function get(obj, path) {
    if (obj == null) return void 0;
    let value = obj;
    for (let i = 0; i < path.length; i++) {
        if (value == null || value[path[i]] == null) return void 0;
        value = value[path[i]];
    }
    return value;
}
function set(obj, value, path) {
    if (path.length === 0) return value;
    const idx = path[0];
    if (path.length > 1) {
        value = set(
            typeof obj !== "object" ||
                obj === null ||
                !Object.prototype.hasOwnProperty.call(obj, idx)
                ? Number.isInteger(Number(path[1]))
                    ? []
                    : {}
                : obj[idx],
            value,
            Array.prototype.slice.call(path, 1),
        );
    }
    if (Number.isInteger(Number(idx)) && Array.isArray(obj))
        return obj.slice()[idx];
    return Object.assign({}, obj, { [idx]: value });
}
function unset(obj, path) {
    if (obj == null || path.length === 0) return obj;
    if (path.length === 1) {
        if (obj == null) return obj;
        if (Number.isInteger(path[0]) && Array.isArray(obj))
            return Array.prototype.slice.call(obj, 0).splice(path[0], 1);
        const result = {};
        for (const p2 in obj) result[p2] = obj[p2];
        delete result[path[0]];
        return result;
    }
    if (obj[path[0]] == null) {
        if (Number.isInteger(path[0]) && Array.isArray(obj))
            return Array.prototype.concat.call([], obj);
        const result = {};
        for (const p2 in obj) result[p2] = obj[p2];
        return result;
    }
    return set(obj, unset(obj[path[0]], Array.prototype.slice.call(path, 1)), [
        path[0],
    ]);
}
function deepPickUnsafe(obj, paths) {
    return paths
        .map((p2) => p2.split("."))
        .map((p2) => [p2, get(obj, p2)])
        .filter((t) => t[1] !== void 0)
        .reduce((acc, cur) => set(acc, cur[1], cur[0]), {});
}
function deepOmitUnsafe(obj, paths) {
    return paths
        .map((p2) => p2.split("."))
        .reduce((acc, cur) => unset(acc, cur), obj);
}
function hydrateStore(
    store,
    {
        storage,
        serializer,
        key,
        debug,
        pick,
        omit,
        beforeHydrate,
        afterHydrate,
    },
    context,
    runHooks = true,
) {
    try {
        if (runHooks) beforeHydrate == null ? void 0 : beforeHydrate(context);
        const fromStorage = storage.getItem(key);
        if (fromStorage) {
            const deserialized = serializer.deserialize(fromStorage);
            const picked = pick
                ? deepPickUnsafe(deserialized, pick)
                : deserialized;
            const omitted = omit ? deepOmitUnsafe(picked, omit) : picked;
            store.$patch(omitted);
        }
        if (runHooks) afterHydrate == null ? void 0 : afterHydrate(context);
    } catch (error) {
        if (debug) console.error("[pinia-plugin-persistedstate]", error);
    }
}
function persistState(state, { storage, serializer, key, debug, pick, omit }) {
    try {
        const picked = pick ? deepPickUnsafe(state, pick) : state;
        const omitted = omit ? deepOmitUnsafe(picked, omit) : picked;
        const toStorage = serializer.serialize(omitted);
        storage.setItem(key, toStorage);
    } catch (error) {
        if (debug) console.error("[pinia-plugin-persistedstate]", error);
    }
}
function createPersistence(context, optionsParser, auto) {
    const {
        pinia: pinia2,
        store,
        options: { persist = auto },
    } = context;
    if (!persist) return;
    if (!(store.$id in pinia2.state.value)) {
        const originalStore = pinia2._s.get(store.$id.replace("__hot:", ""));
        if (originalStore)
            Promise.resolve().then(() => originalStore.$persist());
        return;
    }
    const persistenceOptions = Array.isArray(persist)
        ? persist
        : persist === true
          ? [{}]
          : [persist];
    const persistences = persistenceOptions.map(optionsParser);
    store.$hydrate = ({ runHooks = true } = {}) => {
        persistences.forEach((p2) => {
            hydrateStore(store, p2, context, runHooks);
        });
    };
    store.$persist = () => {
        persistences.forEach((p2) => {
            persistState(store.$state, p2);
        });
    };
    persistences.forEach((p2) => {
        hydrateStore(store, p2, context);
        store.$subscribe((_mutation, state) => persistState(state, p2), {
            detached: true,
        });
    });
}
function createPersistedState(options = {}) {
    return function (context) {
        createPersistence(
            context,
            (p2) => ({
                key: (options.key ? options.key : (x) => x)(
                    p2.key ?? context.store.$id,
                ),
                debug: p2.debug ?? options.debug ?? false,
                serializer: p2.serializer ??
                    options.serializer ?? {
                        serialize: (data) => JSON.stringify(data),
                        deserialize: (data) => destr(data),
                    },
                storage: p2.storage ?? options.storage ?? window.localStorage,
                beforeHydrate: p2.beforeHydrate,
                afterHydrate: p2.afterHydrate,
                pick: p2.pick,
                omit: p2.omit,
            }),
            options.auto ?? false,
        );
    };
}
var src_default = createPersistedState();
var __assign = function () {
    __assign =
        Object.assign ||
        function __assign2(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p2 in s)
                    if (Object.prototype.hasOwnProperty.call(s, p2))
                        t[p2] = s[p2];
            }
            return t;
        };
    return __assign.apply(this, arguments);
};
function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P
            ? value
            : new P(function (resolve) {
                  resolve(value);
              });
    }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done
                ? resolve(result.value)
                : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}
function __generator(thisArg, body) {
    var _ = {
            label: 0,
            sent: function () {
                if (t[0] & 1) throw t[1];
                return t[1];
            },
            trys: [],
            ops: [],
        },
        f,
        y,
        t,
        g = Object.create(
            (typeof Iterator === "function" ? Iterator : Object).prototype,
        );
    return (
        (g.next = verb(0)),
        (g["throw"] = verb(1)),
        (g["return"] = verb(2)),
        typeof Symbol === "function" &&
            (g[Symbol.iterator] = function () {
                return this;
            }),
        g
    );
    function verb(n) {
        return function (v) {
            return step([n, v]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while ((g && ((g = 0), op[0] && (_ = 0)), _))
            try {
                if (
                    ((f = 1),
                    y &&
                        (t =
                            op[0] & 2
                                ? y["return"]
                                : op[0]
                                  ? y["throw"] ||
                                    ((t = y["return"]) && t.call(y), 0)
                                  : y.next) &&
                        !(t = t.call(y, op[1])).done)
                )
                    return t;
                if (((y = 0), t)) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0:
                    case 1:
                        t = op;
                        break;
                    case 4:
                        _.label++;
                        return { value: op[1], done: false };
                    case 5:
                        _.label++;
                        y = op[1];
                        op = [0];
                        continue;
                    case 7:
                        op = _.ops.pop();
                        _.trys.pop();
                        continue;
                    default:
                        if (
                            !((t = _.trys),
                            (t = t.length > 0 && t[t.length - 1])) &&
                            (op[0] === 6 || op[0] === 2)
                        ) {
                            _ = 0;
                            continue;
                        }
                        if (
                            op[0] === 3 &&
                            (!t || (op[1] > t[0] && op[1] < t[3]))
                        ) {
                            _.label = op[1];
                            break;
                        }
                        if (op[0] === 6 && _.label < t[1]) {
                            _.label = t[1];
                            t = op;
                            break;
                        }
                        if (t && _.label < t[2]) {
                            _.label = t[2];
                            _.ops.push(op);
                            break;
                        }
                        if (t[2]) _.ops.pop();
                        _.trys.pop();
                        continue;
                }
                op = body.call(thisArg, _);
            } catch (e) {
                op = [6, e];
                y = 0;
            } finally {
                f = t = 0;
            }
        if (op[0] & 5) throw op[1];
        return { value: op[0] ? op[1] : void 0, done: true };
    }
}
function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2)
        for (var i = 0, l = from.length, ar; i < l; i++) {
            if (ar || !(i in from)) {
                if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                ar[i] = from[i];
            }
        }
    return to.concat(ar || Array.prototype.slice.call(from));
}
typeof SuppressedError === "function"
    ? SuppressedError
    : function (error, suppressed, message) {
          var e = new Error(message);
          return (
              (e.name = "SuppressedError"),
              (e.error = error),
              (e.suppressed = suppressed),
              e
          );
      };
var version = "4.5.1";
function wait(durationMs, resolveWith) {
    return new Promise(function (resolve) {
        return setTimeout(resolve, durationMs, resolveWith);
    });
}
function releaseEventLoop() {
    return new Promise(function (resolve) {
        var channel = new MessageChannel();
        channel.port1.onmessage = function () {
            return resolve();
        };
        channel.port2.postMessage(null);
    });
}
function requestIdleCallbackIfAvailable(fallbackTimeout, deadlineTimeout) {
    if (deadlineTimeout === void 0) {
        deadlineTimeout = Infinity;
    }
    var requestIdleCallback = window.requestIdleCallback;
    if (requestIdleCallback) {
        return new Promise(function (resolve) {
            return requestIdleCallback.call(
                window,
                function () {
                    return resolve();
                },
                { timeout: deadlineTimeout },
            );
        });
    } else {
        return wait(Math.min(fallbackTimeout, deadlineTimeout));
    }
}
function isPromise(value) {
    return !!value && typeof value.then === "function";
}
function awaitIfAsync(action, callback) {
    try {
        var returnedValue = action();
        if (isPromise(returnedValue)) {
            returnedValue.then(
                function (result) {
                    return callback(true, result);
                },
                function (error) {
                    return callback(false, error);
                },
            );
        } else {
            callback(true, returnedValue);
        }
    } catch (error) {
        callback(false, error);
    }
}
function mapWithBreaks(items, callback, loopReleaseInterval) {
    if (loopReleaseInterval === void 0) {
        loopReleaseInterval = 16;
    }
    return __awaiter(this, void 0, void 0, function () {
        var results, lastLoopReleaseTime, i, now;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    results = Array(items.length);
                    lastLoopReleaseTime = Date.now();
                    i = 0;
                    _a.label = 1;
                case 1:
                    if (!(i < items.length)) return [3, 4];
                    results[i] = callback(items[i], i);
                    now = Date.now();
                    if (!(now >= lastLoopReleaseTime + loopReleaseInterval))
                        return [3, 3];
                    lastLoopReleaseTime = now;
                    return [4, releaseEventLoop()];
                case 2:
                    _a.sent();
                    _a.label = 3;
                case 3:
                    ++i;
                    return [3, 1];
                case 4:
                    return [2, results];
            }
        });
    });
}
function suppressUnhandledRejectionWarning(promise) {
    promise.then(void 0, function () {
        return void 0;
    });
    return promise;
}
function includes(haystack, needle) {
    for (var i = 0, l = haystack.length; i < l; ++i) {
        if (haystack[i] === needle) {
            return true;
        }
    }
    return false;
}
function excludes(haystack, needle) {
    return !includes(haystack, needle);
}
function toInt(value) {
    return parseInt(value);
}
function toFloat(value) {
    return parseFloat(value);
}
function replaceNaN(value, replacement) {
    return typeof value === "number" && isNaN(value) ? replacement : value;
}
function countTruthy(values) {
    return values.reduce(function (sum, value) {
        return sum + (value ? 1 : 0);
    }, 0);
}
function round(value, base) {
    if (base === void 0) {
        base = 1;
    }
    if (Math.abs(base) >= 1) {
        return Math.round(value / base) * base;
    } else {
        var counterBase = 1 / base;
        return Math.round(value * counterBase) / counterBase;
    }
}
function parseSimpleCssSelector(selector) {
    var _a, _b;
    var errorMessage = "Unexpected syntax '".concat(selector, "'");
    var tagMatch = /^\s*([a-z-]*)(.*)$/i.exec(selector);
    var tag = tagMatch[1] || void 0;
    var attributes = {};
    var partsRegex = /([.:#][\w-]+|\[.+?\])/gi;
    var addAttribute = function (name, value) {
        attributes[name] = attributes[name] || [];
        attributes[name].push(value);
    };
    for (;;) {
        var match = partsRegex.exec(tagMatch[2]);
        if (!match) {
            break;
        }
        var part = match[0];
        switch (part[0]) {
            case ".":
                addAttribute("class", part.slice(1));
                break;
            case "#":
                addAttribute("id", part.slice(1));
                break;
            case "[": {
                var attributeMatch =
                    /^\[([\w-]+)([~|^$*]?=("(.*?)"|([\w-]+)))?(\s+[is])?\]$/.exec(
                        part,
                    );
                if (attributeMatch) {
                    addAttribute(
                        attributeMatch[1],
                        (_b =
                            (_a = attributeMatch[4]) !== null && _a !== void 0
                                ? _a
                                : attributeMatch[5]) !== null && _b !== void 0
                            ? _b
                            : "",
                    );
                } else {
                    throw new Error(errorMessage);
                }
                break;
            }
            default:
                throw new Error(errorMessage);
        }
    }
    return [tag, attributes];
}
function getUTF8Bytes(input) {
    var result = new Uint8Array(input.length);
    for (var i = 0; i < input.length; i++) {
        var charCode = input.charCodeAt(i);
        if (charCode > 127) {
            return new TextEncoder().encode(input);
        }
        result[i] = charCode;
    }
    return result;
}
function x64Add(m, n) {
    var m0 = m[0] >>> 16,
        m1 = m[0] & 65535,
        m2 = m[1] >>> 16,
        m3 = m[1] & 65535;
    var n0 = n[0] >>> 16,
        n1 = n[0] & 65535,
        n2 = n[1] >>> 16,
        n3 = n[1] & 65535;
    var o0 = 0,
        o1 = 0,
        o2 = 0,
        o3 = 0;
    o3 += m3 + n3;
    o2 += o3 >>> 16;
    o3 &= 65535;
    o2 += m2 + n2;
    o1 += o2 >>> 16;
    o2 &= 65535;
    o1 += m1 + n1;
    o0 += o1 >>> 16;
    o1 &= 65535;
    o0 += m0 + n0;
    o0 &= 65535;
    m[0] = (o0 << 16) | o1;
    m[1] = (o2 << 16) | o3;
}
function x64Multiply(m, n) {
    var m0 = m[0] >>> 16,
        m1 = m[0] & 65535,
        m2 = m[1] >>> 16,
        m3 = m[1] & 65535;
    var n0 = n[0] >>> 16,
        n1 = n[0] & 65535,
        n2 = n[1] >>> 16,
        n3 = n[1] & 65535;
    var o0 = 0,
        o1 = 0,
        o2 = 0,
        o3 = 0;
    o3 += m3 * n3;
    o2 += o3 >>> 16;
    o3 &= 65535;
    o2 += m2 * n3;
    o1 += o2 >>> 16;
    o2 &= 65535;
    o2 += m3 * n2;
    o1 += o2 >>> 16;
    o2 &= 65535;
    o1 += m1 * n3;
    o0 += o1 >>> 16;
    o1 &= 65535;
    o1 += m2 * n2;
    o0 += o1 >>> 16;
    o1 &= 65535;
    o1 += m3 * n1;
    o0 += o1 >>> 16;
    o1 &= 65535;
    o0 += m0 * n3 + m1 * n2 + m2 * n1 + m3 * n0;
    o0 &= 65535;
    m[0] = (o0 << 16) | o1;
    m[1] = (o2 << 16) | o3;
}
function x64Rotl(m, bits) {
    var m0 = m[0];
    bits %= 64;
    if (bits === 32) {
        m[0] = m[1];
        m[1] = m0;
    } else if (bits < 32) {
        m[0] = (m0 << bits) | (m[1] >>> (32 - bits));
        m[1] = (m[1] << bits) | (m0 >>> (32 - bits));
    } else {
        bits -= 32;
        m[0] = (m[1] << bits) | (m0 >>> (32 - bits));
        m[1] = (m0 << bits) | (m[1] >>> (32 - bits));
    }
}
function x64LeftShift(m, bits) {
    bits %= 64;
    if (bits === 0) {
        return;
    } else if (bits < 32) {
        m[0] = m[1] >>> (32 - bits);
        m[1] = m[1] << bits;
    } else {
        m[0] = m[1] << (bits - 32);
        m[1] = 0;
    }
}
function x64Xor(m, n) {
    m[0] ^= n[0];
    m[1] ^= n[1];
}
var F1 = [4283543511, 3981806797];
var F2 = [3301882366, 444984403];
function x64Fmix(h) {
    var shifted = [0, h[0] >>> 1];
    x64Xor(h, shifted);
    x64Multiply(h, F1);
    shifted[1] = h[0] >>> 1;
    x64Xor(h, shifted);
    x64Multiply(h, F2);
    shifted[1] = h[0] >>> 1;
    x64Xor(h, shifted);
}
var C1 = [2277735313, 289559509];
var C2 = [1291169091, 658871167];
var M$1 = [0, 5];
var N1 = [0, 1390208809];
var N2 = [0, 944331445];
function x64hash128(input, seed) {
    var key = getUTF8Bytes(input);
    seed = seed || 0;
    var length = [0, key.length];
    var remainder = length[1] % 16;
    var bytes = length[1] - remainder;
    var h1 = [0, seed];
    var h2 = [0, seed];
    var k1 = [0, 0];
    var k2 = [0, 0];
    var i;
    for (i = 0; i < bytes; i = i + 16) {
        k1[0] =
            key[i + 4] |
            (key[i + 5] << 8) |
            (key[i + 6] << 16) |
            (key[i + 7] << 24);
        k1[1] =
            key[i] |
            (key[i + 1] << 8) |
            (key[i + 2] << 16) |
            (key[i + 3] << 24);
        k2[0] =
            key[i + 12] |
            (key[i + 13] << 8) |
            (key[i + 14] << 16) |
            (key[i + 15] << 24);
        k2[1] =
            key[i + 8] |
            (key[i + 9] << 8) |
            (key[i + 10] << 16) |
            (key[i + 11] << 24);
        x64Multiply(k1, C1);
        x64Rotl(k1, 31);
        x64Multiply(k1, C2);
        x64Xor(h1, k1);
        x64Rotl(h1, 27);
        x64Add(h1, h2);
        x64Multiply(h1, M$1);
        x64Add(h1, N1);
        x64Multiply(k2, C2);
        x64Rotl(k2, 33);
        x64Multiply(k2, C1);
        x64Xor(h2, k2);
        x64Rotl(h2, 31);
        x64Add(h2, h1);
        x64Multiply(h2, M$1);
        x64Add(h2, N2);
    }
    k1[0] = 0;
    k1[1] = 0;
    k2[0] = 0;
    k2[1] = 0;
    var val = [0, 0];
    switch (remainder) {
        case 15:
            val[1] = key[i + 14];
            x64LeftShift(val, 48);
            x64Xor(k2, val);
        case 14:
            val[1] = key[i + 13];
            x64LeftShift(val, 40);
            x64Xor(k2, val);
        case 13:
            val[1] = key[i + 12];
            x64LeftShift(val, 32);
            x64Xor(k2, val);
        case 12:
            val[1] = key[i + 11];
            x64LeftShift(val, 24);
            x64Xor(k2, val);
        case 11:
            val[1] = key[i + 10];
            x64LeftShift(val, 16);
            x64Xor(k2, val);
        case 10:
            val[1] = key[i + 9];
            x64LeftShift(val, 8);
            x64Xor(k2, val);
        case 9:
            val[1] = key[i + 8];
            x64Xor(k2, val);
            x64Multiply(k2, C2);
            x64Rotl(k2, 33);
            x64Multiply(k2, C1);
            x64Xor(h2, k2);
        case 8:
            val[1] = key[i + 7];
            x64LeftShift(val, 56);
            x64Xor(k1, val);
        case 7:
            val[1] = key[i + 6];
            x64LeftShift(val, 48);
            x64Xor(k1, val);
        case 6:
            val[1] = key[i + 5];
            x64LeftShift(val, 40);
            x64Xor(k1, val);
        case 5:
            val[1] = key[i + 4];
            x64LeftShift(val, 32);
            x64Xor(k1, val);
        case 4:
            val[1] = key[i + 3];
            x64LeftShift(val, 24);
            x64Xor(k1, val);
        case 3:
            val[1] = key[i + 2];
            x64LeftShift(val, 16);
            x64Xor(k1, val);
        case 2:
            val[1] = key[i + 1];
            x64LeftShift(val, 8);
            x64Xor(k1, val);
        case 1:
            val[1] = key[i];
            x64Xor(k1, val);
            x64Multiply(k1, C1);
            x64Rotl(k1, 31);
            x64Multiply(k1, C2);
            x64Xor(h1, k1);
    }
    x64Xor(h1, length);
    x64Xor(h2, length);
    x64Add(h1, h2);
    x64Add(h2, h1);
    x64Fmix(h1);
    x64Fmix(h2);
    x64Add(h1, h2);
    x64Add(h2, h1);
    return (
        ("00000000" + (h1[0] >>> 0).toString(16)).slice(-8) +
        ("00000000" + (h1[1] >>> 0).toString(16)).slice(-8) +
        ("00000000" + (h2[0] >>> 0).toString(16)).slice(-8) +
        ("00000000" + (h2[1] >>> 0).toString(16)).slice(-8)
    );
}
function errorToObject(error) {
    var _a;
    return __assign(
        {
            name: error.name,
            message: error.message,
            stack:
                (_a = error.stack) === null || _a === void 0
                    ? void 0
                    : _a.split("\n"),
        },
        error,
    );
}
function isFunctionNative(func) {
    return /^function\s.*?\{\s*\[native code]\s*}$/.test(String(func));
}
function isFinalResultLoaded(loadResult) {
    return typeof loadResult !== "function";
}
function loadSource(source, sourceOptions) {
    var sourceLoadPromise = suppressUnhandledRejectionWarning(
        new Promise(function (resolveLoad) {
            var loadStartTime = Date.now();
            awaitIfAsync(source.bind(null, sourceOptions), function () {
                var loadArgs = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    loadArgs[_i] = arguments[_i];
                }
                var loadDuration = Date.now() - loadStartTime;
                if (!loadArgs[0]) {
                    return resolveLoad(function () {
                        return { error: loadArgs[1], duration: loadDuration };
                    });
                }
                var loadResult = loadArgs[1];
                if (isFinalResultLoaded(loadResult)) {
                    return resolveLoad(function () {
                        return { value: loadResult, duration: loadDuration };
                    });
                }
                resolveLoad(function () {
                    return new Promise(function (resolveGet) {
                        var getStartTime = Date.now();
                        awaitIfAsync(loadResult, function () {
                            var getArgs = [];
                            for (var _i2 = 0; _i2 < arguments.length; _i2++) {
                                getArgs[_i2] = arguments[_i2];
                            }
                            var duration =
                                loadDuration + Date.now() - getStartTime;
                            if (!getArgs[0]) {
                                return resolveGet({
                                    error: getArgs[1],
                                    duration,
                                });
                            }
                            resolveGet({ value: getArgs[1], duration });
                        });
                    });
                });
            });
        }),
    );
    return function getComponent() {
        return sourceLoadPromise.then(function (finalizeSource) {
            return finalizeSource();
        });
    };
}
function loadSources(
    sources2,
    sourceOptions,
    excludeSources,
    loopReleaseInterval,
) {
    var includedSources = Object.keys(sources2).filter(function (sourceKey) {
        return excludes(excludeSources, sourceKey);
    });
    var sourceGettersPromise = suppressUnhandledRejectionWarning(
        mapWithBreaks(
            includedSources,
            function (sourceKey) {
                return loadSource(sources2[sourceKey], sourceOptions);
            },
            loopReleaseInterval,
        ),
    );
    return function getComponents() {
        return __awaiter(this, void 0, void 0, function () {
            var sourceGetters,
                componentPromises,
                componentArray,
                components,
                index;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        return [4, sourceGettersPromise];
                    case 1:
                        sourceGetters = _a.sent();
                        return [
                            4,
                            mapWithBreaks(
                                sourceGetters,
                                function (sourceGetter) {
                                    return suppressUnhandledRejectionWarning(
                                        sourceGetter(),
                                    );
                                },
                                loopReleaseInterval,
                            ),
                        ];
                    case 2:
                        componentPromises = _a.sent();
                        return [
                            4,
                            Promise.all(componentPromises),
                            // Keeping the component keys order the same as the source keys order
                        ];
                    case 3:
                        componentArray = _a.sent();
                        components = {};
                        for (
                            index = 0;
                            index < includedSources.length;
                            ++index
                        ) {
                            components[includedSources[index]] =
                                componentArray[index];
                        }
                        return [2, components];
                }
            });
        });
    };
}
function isTrident() {
    var w = window;
    var n = navigator;
    return (
        countTruthy([
            "MSCSSMatrix" in w,
            "msSetImmediate" in w,
            "msIndexedDB" in w,
            "msMaxTouchPoints" in n,
            "msPointerEnabled" in n,
        ]) >= 4
    );
}
function isEdgeHTML() {
    var w = window;
    var n = navigator;
    return (
        countTruthy([
            "msWriteProfilerMark" in w,
            "MSStream" in w,
            "msLaunchUri" in n,
            "msSaveBlob" in n,
        ]) >= 3 && !isTrident()
    );
}
function isChromium() {
    var w = window;
    var n = navigator;
    return (
        countTruthy([
            "webkitPersistentStorage" in n,
            "webkitTemporaryStorage" in n,
            n.vendor.indexOf("Google") === 0,
            "webkitResolveLocalFileSystemURL" in w,
            "BatteryManager" in w,
            "webkitMediaStream" in w,
            "webkitSpeechGrammar" in w,
        ]) >= 5
    );
}
function isWebKit() {
    var w = window;
    var n = navigator;
    return (
        countTruthy([
            "ApplePayError" in w,
            "CSSPrimitiveValue" in w,
            "Counter" in w,
            n.vendor.indexOf("Apple") === 0,
            "RGBColor" in w,
            "WebKitMediaKeys" in w,
        ]) >= 4
    );
}
function isDesktopWebKit() {
    var w = window;
    var HTMLElement = w.HTMLElement,
        Document = w.Document;
    return (
        countTruthy([
            "safari" in w,
            !("ongestureend" in w),
            !("TouchEvent" in w),
            !("orientation" in w),
            HTMLElement && !("autocapitalize" in HTMLElement.prototype),
            Document && "pointerLockElement" in Document.prototype,
        ]) >= 4
    );
}
function isSafariWebKit() {
    var w = window;
    return (
        // Filters-out Chrome, Yandex, DuckDuckGo (macOS and iOS), Edge
        isFunctionNative(w.print) && // Doesn't work in Safari < 15.4
        String(w.browser) === "[object WebPageNamespace]"
    );
}
function isGecko() {
    var _a, _b;
    var w = window;
    return (
        countTruthy([
            "buildID" in navigator,
            "MozAppearance" in
                ((_b =
                    (_a = document.documentElement) === null || _a === void 0
                        ? void 0
                        : _a.style) !== null && _b !== void 0
                    ? _b
                    : {}),
            "onmozfullscreenchange" in w,
            "mozInnerScreenX" in w,
            "CSSMozDocumentRule" in w,
            "CanvasCaptureMediaStream" in w,
        ]) >= 4
    );
}
function isChromium86OrNewer() {
    var w = window;
    return (
        countTruthy([
            !("MediaSettingsRange" in w),
            "RTCEncodedAudioFrame" in w,
            "" + w.Intl === "[object Intl]",
            "" + w.Reflect === "[object Reflect]",
        ]) >= 3
    );
}
function isChromium122OrNewer() {
    var w = window;
    var URLPattern = w.URLPattern;
    return (
        countTruthy([
            "union" in Set.prototype,
            "Iterator" in w,
            URLPattern && "hasRegExpGroups" in URLPattern.prototype,
            "RGB8" in WebGLRenderingContext.prototype,
        ]) >= 3
    );
}
function isWebKit606OrNewer() {
    var w = window;
    return (
        countTruthy([
            "DOMRectList" in w,
            "RTCPeerConnectionIceEvent" in w,
            "SVGGeometryElement" in w,
            "ontransitioncancel" in w,
        ]) >= 3
    );
}
function isWebKit616OrNewer() {
    var w = window;
    var n = navigator;
    var CSS = w.CSS,
        HTMLButtonElement = w.HTMLButtonElement;
    return (
        countTruthy([
            !("getStorageUpdates" in n),
            HTMLButtonElement && "popover" in HTMLButtonElement.prototype,
            "CSSCounterStyleRule" in w,
            CSS.supports("font-size-adjust: ex-height 0.5"),
            CSS.supports("text-transform: full-width"),
        ]) >= 4
    );
}
function isIPad() {
    if (navigator.platform === "iPad") {
        return true;
    }
    var s = screen;
    var screenRatio = s.width / s.height;
    return (
        countTruthy([
            // Since iOS 13. Doesn't work in Chrome on iPadOS <15, but works in desktop mode.
            "MediaSource" in window,
            // Since iOS 12. Doesn't work in Chrome on iPadOS.
            !!Element.prototype.webkitRequestFullscreen,
            // iPhone 4S that runs iOS 9 matches this, but it is not supported
            // Doesn't work in incognito mode of Safari ≥17 with split screen because of tracking prevention
            screenRatio > 0.65 && screenRatio < 1.53,
        ]) >= 2
    );
}
function getFullscreenElement() {
    var d = document;
    return (
        d.fullscreenElement ||
        d.msFullscreenElement ||
        d.mozFullScreenElement ||
        d.webkitFullscreenElement ||
        null
    );
}
function exitFullscreen() {
    var d = document;
    return (
        d.exitFullscreen ||
        d.msExitFullscreen ||
        d.mozCancelFullScreen ||
        d.webkitExitFullscreen
    ).call(d);
}
function isAndroid() {
    var isItChromium = isChromium();
    var isItGecko = isGecko();
    var w = window;
    var n = navigator;
    var c = "connection";
    if (isItChromium) {
        return (
            countTruthy([
                !("SharedWorker" in w),
                // `typechange` is deprecated, but it's still present on Android (tested on Chrome Mobile 117)
                // Removal proposal https://bugs.chromium.org/p/chromium/issues/detail?id=699892
                // Note: this expression returns true on ChromeOS, so additional detectors are required to avoid false-positives
                n[c] && "ontypechange" in n[c],
                !("sinkId" in new Audio()),
            ]) >= 2
        );
    } else if (isItGecko) {
        return (
            countTruthy([
                "onorientationchange" in w,
                "orientation" in w,
                /android/i.test(n.appVersion),
            ]) >= 2
        );
    } else {
        return false;
    }
}
function isSamsungInternet() {
    var n = navigator;
    var w = window;
    var audioPrototype = Audio.prototype;
    var visualViewport = w.visualViewport;
    return (
        countTruthy([
            "srLatency" in audioPrototype,
            "srChannelCount" in audioPrototype,
            "devicePosture" in n,
            visualViewport && "segments" in visualViewport,
            "getTextInformation" in Image.prototype,
            // Not available in Samsung Internet 21
        ]) >= 3
    );
}
function getAudioFingerprint() {
    if (doesBrowserPerformAntifingerprinting$1()) {
        return -4;
    }
    return getUnstableAudioFingerprint();
}
function getUnstableAudioFingerprint() {
    var w = window;
    var AudioContext2 = w.OfflineAudioContext || w.webkitOfflineAudioContext;
    if (!AudioContext2) {
        return -2;
    }
    if (doesBrowserSuspendAudioContext()) {
        return -1;
    }
    var hashFromIndex = 4500;
    var hashToIndex = 5e3;
    var context = new AudioContext2(1, hashToIndex, 44100);
    var oscillator = context.createOscillator();
    oscillator.type = "triangle";
    oscillator.frequency.value = 1e4;
    var compressor = context.createDynamicsCompressor();
    compressor.threshold.value = -50;
    compressor.knee.value = 40;
    compressor.ratio.value = 12;
    compressor.attack.value = 0;
    compressor.release.value = 0.25;
    oscillator.connect(compressor);
    compressor.connect(context.destination);
    oscillator.start(0);
    var _a = startRenderingAudio(context),
        renderPromise = _a[0],
        finishRendering = _a[1];
    var fingerprintPromise = suppressUnhandledRejectionWarning(
        renderPromise.then(
            function (buffer) {
                return getHash(
                    buffer.getChannelData(0).subarray(hashFromIndex),
                );
            },
            function (error) {
                if (error.name === "timeout" || error.name === "suspended") {
                    return -3;
                }
                throw error;
            },
        ),
    );
    return function () {
        finishRendering();
        return fingerprintPromise;
    };
}
function doesBrowserSuspendAudioContext() {
    return isWebKit() && !isDesktopWebKit() && !isWebKit606OrNewer();
}
function doesBrowserPerformAntifingerprinting$1() {
    return (
        // Safari ≥17
        (isWebKit() && isWebKit616OrNewer() && isSafariWebKit()) || // Samsung Internet ≥26
        (isChromium() && isSamsungInternet() && isChromium122OrNewer())
    );
}
function startRenderingAudio(context) {
    var renderTryMaxCount = 3;
    var renderRetryDelay = 500;
    var runningMaxAwaitTime = 500;
    var runningSufficientTime = 5e3;
    var finalize = function () {
        return void 0;
    };
    var resultPromise = new Promise(function (resolve, reject) {
        var isFinalized = false;
        var renderTryCount = 0;
        var startedRunningAt = 0;
        context.oncomplete = function (event) {
            return resolve(event.renderedBuffer);
        };
        var startRunningTimeout = function () {
            setTimeout(
                function () {
                    return reject(
                        makeInnerError(
                            "timeout",
                            /* InnerErrorName.Timeout */
                        ),
                    );
                },
                Math.min(
                    runningMaxAwaitTime,
                    startedRunningAt + runningSufficientTime - Date.now(),
                ),
            );
        };
        var tryRender = function () {
            try {
                var renderingPromise = context.startRendering();
                if (isPromise(renderingPromise)) {
                    suppressUnhandledRejectionWarning(renderingPromise);
                }
                switch (context.state) {
                    case "running":
                        startedRunningAt = Date.now();
                        if (isFinalized) {
                            startRunningTimeout();
                        }
                        break;
                    case "suspended":
                        if (!document.hidden) {
                            renderTryCount++;
                        }
                        if (
                            isFinalized &&
                            renderTryCount >= renderTryMaxCount
                        ) {
                            reject(
                                makeInnerError(
                                    "suspended",
                                    /* InnerErrorName.Suspended */
                                ),
                            );
                        } else {
                            setTimeout(tryRender, renderRetryDelay);
                        }
                        break;
                }
            } catch (error) {
                reject(error);
            }
        };
        tryRender();
        finalize = function () {
            if (!isFinalized) {
                isFinalized = true;
                if (startedRunningAt > 0) {
                    startRunningTimeout();
                }
            }
        };
    });
    return [resultPromise, finalize];
}
function getHash(signal) {
    var hash = 0;
    for (var i = 0; i < signal.length; ++i) {
        hash += Math.abs(signal[i]);
    }
    return hash;
}
function makeInnerError(name) {
    var error = new Error(name);
    error.name = name;
    return error;
}
function withIframe(action, initialHtml, domPollInterval) {
    var _a, _b, _c;
    if (domPollInterval === void 0) {
        domPollInterval = 50;
    }
    return __awaiter(this, void 0, void 0, function () {
        var d, iframe;
        return __generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    d = document;
                    _d.label = 1;
                case 1:
                    if (!!d.body) return [3, 3];
                    return [4, wait(domPollInterval)];
                case 2:
                    _d.sent();
                    return [3, 1];
                case 3:
                    iframe = d.createElement("iframe");
                    _d.label = 4;
                case 4:
                    _d.trys.push([4, , 10, 11]);
                    return [
                        4,
                        new Promise(function (_resolve, _reject) {
                            var isComplete = false;
                            var resolve = function () {
                                isComplete = true;
                                _resolve();
                            };
                            var reject = function (error) {
                                isComplete = true;
                                _reject(error);
                            };
                            iframe.onload = resolve;
                            iframe.onerror = reject;
                            var style = iframe.style;
                            style.setProperty("display", "block", "important");
                            style.position = "absolute";
                            style.top = "0";
                            style.left = "0";
                            style.visibility = "hidden";
                            if (initialHtml && "srcdoc" in iframe) {
                                iframe.srcdoc = initialHtml;
                            } else {
                                iframe.src = "about:blank";
                            }
                            d.body.appendChild(iframe);
                            var checkReadyState = function () {
                                var _a2, _b2;
                                if (isComplete) {
                                    return;
                                }
                                if (
                                    ((_b2 =
                                        (_a2 = iframe.contentWindow) === null ||
                                        _a2 === void 0
                                            ? void 0
                                            : _a2.document) === null ||
                                    _b2 === void 0
                                        ? void 0
                                        : _b2.readyState) === "complete"
                                ) {
                                    resolve();
                                } else {
                                    setTimeout(checkReadyState, 10);
                                }
                            };
                            checkReadyState();
                        }),
                    ];
                case 5:
                    _d.sent();
                    _d.label = 6;
                case 6:
                    if (
                        !!((_b =
                            (_a = iframe.contentWindow) === null ||
                            _a === void 0
                                ? void 0
                                : _a.document) === null || _b === void 0
                            ? void 0
                            : _b.body)
                    )
                        return [3, 8];
                    return [4, wait(domPollInterval)];
                case 7:
                    _d.sent();
                    return [3, 6];
                case 8:
                    return [4, action(iframe, iframe.contentWindow)];
                case 9:
                    return [2, _d.sent()];
                case 10:
                    (_c = iframe.parentNode) === null || _c === void 0
                        ? void 0
                        : _c.removeChild(iframe);
                    return [
                        7,
                        /*endfinally*/
                    ];
                case 11:
                    return [
                        2,
                        /*return*/
                    ];
            }
        });
    });
}
function selectorToElement(selector) {
    var _a = parseSimpleCssSelector(selector),
        tag = _a[0],
        attributes = _a[1];
    var element = document.createElement(
        tag !== null && tag !== void 0 ? tag : "div",
    );
    for (var _i = 0, _b = Object.keys(attributes); _i < _b.length; _i++) {
        var name_1 = _b[_i];
        var value = attributes[name_1].join(" ");
        if (name_1 === "style") {
            addStyleString(element.style, value);
        } else {
            element.setAttribute(name_1, value);
        }
    }
    return element;
}
function addStyleString(style, source) {
    for (var _i = 0, _a = source.split(";"); _i < _a.length; _i++) {
        var property = _a[_i];
        var match = /^\s*([\w-]+)\s*:\s*(.+?)(\s*!([\w-]+))?\s*$/.exec(
            property,
        );
        if (match) {
            var name_2 = match[1],
                value = match[2],
                priority = match[4];
            style.setProperty(name_2, value, priority || "");
        }
    }
}
function isAnyParentCrossOrigin() {
    var currentWindow = window;
    for (;;) {
        var parentWindow = currentWindow.parent;
        if (!parentWindow || parentWindow === currentWindow) {
            return false;
        }
        try {
            if (
                parentWindow.location.origin !== currentWindow.location.origin
            ) {
                return true;
            }
        } catch (error) {
            if (error instanceof Error && error.name === "SecurityError") {
                return true;
            }
            throw error;
        }
        currentWindow = parentWindow;
    }
}
var testString = "mmMwWLliI0O&1";
var textSize = "48px";
var baseFonts = ["monospace", "sans-serif", "serif"];
var fontList = [
    // This is android-specific font from "Roboto" family
    "sans-serif-thin",
    "ARNO PRO",
    "Agency FB",
    "Arabic Typesetting",
    "Arial Unicode MS",
    "AvantGarde Bk BT",
    "BankGothic Md BT",
    "Batang",
    "Bitstream Vera Sans Mono",
    "Calibri",
    "Century",
    "Century Gothic",
    "Clarendon",
    "EUROSTILE",
    "Franklin Gothic",
    "Futura Bk BT",
    "Futura Md BT",
    "GOTHAM",
    "Gill Sans",
    "HELV",
    "Haettenschweiler",
    "Helvetica Neue",
    "Humanst521 BT",
    "Leelawadee",
    "Letter Gothic",
    "Levenim MT",
    "Lucida Bright",
    "Lucida Sans",
    "Menlo",
    "MS Mincho",
    "MS Outlook",
    "MS Reference Specialty",
    "MS UI Gothic",
    "MT Extra",
    "MYRIAD PRO",
    "Marlett",
    "Meiryo UI",
    "Microsoft Uighur",
    "Minion Pro",
    "Monotype Corsiva",
    "PMingLiU",
    "Pristina",
    "SCRIPTINA",
    "Segoe UI Light",
    "Serifa",
    "SimHei",
    "Small Fonts",
    "Staccato222 BT",
    "TRAJAN PRO",
    "Univers CE 55 Medium",
    "Vrinda",
    "ZWAdobeF",
];
function getFonts() {
    var _this = this;
    return withIframe(function (_, _a) {
        var document2 = _a.document;
        return __awaiter(_this, void 0, void 0, function () {
            var holder,
                spansContainer,
                defaultWidth,
                defaultHeight,
                createSpan,
                createSpanWithFonts,
                initializeBaseFontsSpans,
                initializeFontsSpans,
                isFontAvailable,
                baseFontsSpans,
                fontsSpans,
                index;
            return __generator(this, function (_b) {
                holder = document2.body;
                holder.style.fontSize = textSize;
                spansContainer = document2.createElement("div");
                spansContainer.style.setProperty(
                    "visibility",
                    "hidden",
                    "important",
                );
                defaultWidth = {};
                defaultHeight = {};
                createSpan = function (fontFamily) {
                    var span = document2.createElement("span");
                    var style = span.style;
                    style.position = "absolute";
                    style.top = "0";
                    style.left = "0";
                    style.fontFamily = fontFamily;
                    span.textContent = testString;
                    spansContainer.appendChild(span);
                    return span;
                };
                createSpanWithFonts = function (fontToDetect, baseFont) {
                    return createSpan(
                        "'".concat(fontToDetect, "',").concat(baseFont),
                    );
                };
                initializeBaseFontsSpans = function () {
                    return baseFonts.map(createSpan);
                };
                initializeFontsSpans = function () {
                    var spans = {};
                    var _loop_1 = function (font2) {
                        spans[font2] = baseFonts.map(function (baseFont) {
                            return createSpanWithFonts(font2, baseFont);
                        });
                    };
                    for (
                        var _i = 0, fontList_1 = fontList;
                        _i < fontList_1.length;
                        _i++
                    ) {
                        var font = fontList_1[_i];
                        _loop_1(font);
                    }
                    return spans;
                };
                isFontAvailable = function (fontSpans) {
                    return baseFonts.some(function (baseFont, baseFontIndex) {
                        return (
                            fontSpans[baseFontIndex].offsetWidth !==
                                defaultWidth[baseFont] ||
                            fontSpans[baseFontIndex].offsetHeight !==
                                defaultHeight[baseFont]
                        );
                    });
                };
                baseFontsSpans = initializeBaseFontsSpans();
                fontsSpans = initializeFontsSpans();
                holder.appendChild(spansContainer);
                for (index = 0; index < baseFonts.length; index++) {
                    defaultWidth[baseFonts[index]] =
                        baseFontsSpans[index].offsetWidth;
                    defaultHeight[baseFonts[index]] =
                        baseFontsSpans[index].offsetHeight;
                }
                return [
                    2,
                    fontList.filter(function (font) {
                        return isFontAvailable(fontsSpans[font]);
                    }),
                ];
            });
        });
    });
}
function getPlugins() {
    var rawPlugins = navigator.plugins;
    if (!rawPlugins) {
        return void 0;
    }
    var plugins = [];
    for (var i = 0; i < rawPlugins.length; ++i) {
        var plugin = rawPlugins[i];
        if (!plugin) {
            continue;
        }
        var mimeTypes = [];
        for (var j = 0; j < plugin.length; ++j) {
            var mimeType = plugin[j];
            mimeTypes.push({
                type: mimeType.type,
                suffixes: mimeType.suffixes,
            });
        }
        plugins.push({
            name: plugin.name,
            description: plugin.description,
            mimeTypes,
        });
    }
    return plugins;
}
function getCanvasFingerprint() {
    return getUnstableCanvasFingerprint(doesBrowserPerformAntifingerprinting());
}
function getUnstableCanvasFingerprint(skipImages) {
    var _a;
    var winding = false;
    var geometry;
    var text;
    var _b = makeCanvasContext(),
        canvas = _b[0],
        context = _b[1];
    if (!isSupported(canvas, context)) {
        geometry = text = "unsupported";
    } else {
        winding = doesSupportWinding(context);
        if (skipImages) {
            geometry = text = "skipped";
        } else {
            (_a = renderImages(canvas, context)),
                (geometry = _a[0]),
                (text = _a[1]);
        }
    }
    return { winding, geometry, text };
}
function makeCanvasContext() {
    var canvas = document.createElement("canvas");
    canvas.width = 1;
    canvas.height = 1;
    return [canvas, canvas.getContext("2d")];
}
function isSupported(canvas, context) {
    return !!(context && canvas.toDataURL);
}
function doesSupportWinding(context) {
    context.rect(0, 0, 10, 10);
    context.rect(2, 2, 6, 6);
    return !context.isPointInPath(5, 5, "evenodd");
}
function renderImages(canvas, context) {
    renderTextImage(canvas, context);
    var textImage1 = canvasToString(canvas);
    var textImage2 = canvasToString(canvas);
    if (textImage1 !== textImage2) {
        return [
            "unstable",
            "unstable",
            /* ImageStatus.Unstable */
        ];
    }
    renderGeometryImage(canvas, context);
    var geometryImage = canvasToString(canvas);
    return [geometryImage, textImage1];
}
function renderTextImage(canvas, context) {
    canvas.width = 240;
    canvas.height = 60;
    context.textBaseline = "alphabetic";
    context.fillStyle = "#f60";
    context.fillRect(100, 1, 62, 20);
    context.fillStyle = "#069";
    context.font = '11pt "Times New Roman"';
    var printedText = "Cwm fjordbank gly ".concat(
        String.fromCharCode(55357, 56835),
        /* 😃 */
    );
    context.fillText(printedText, 2, 15);
    context.fillStyle = "rgba(102, 204, 0, 0.2)";
    context.font = "18pt Arial";
    context.fillText(printedText, 4, 45);
}
function renderGeometryImage(canvas, context) {
    canvas.width = 122;
    canvas.height = 110;
    context.globalCompositeOperation = "multiply";
    for (
        var _i = 0,
            _a = [
                ["#f2f", 40, 40],
                ["#2ff", 80, 40],
                ["#ff2", 60, 80],
            ];
        _i < _a.length;
        _i++
    ) {
        var _b = _a[_i],
            color = _b[0],
            x = _b[1],
            y = _b[2];
        context.fillStyle = color;
        context.beginPath();
        context.arc(x, y, 40, 0, Math.PI * 2, true);
        context.closePath();
        context.fill();
    }
    context.fillStyle = "#f9c";
    context.arc(60, 60, 60, 0, Math.PI * 2, true);
    context.arc(60, 60, 20, 0, Math.PI * 2, true);
    context.fill("evenodd");
}
function canvasToString(canvas) {
    return canvas.toDataURL();
}
function doesBrowserPerformAntifingerprinting() {
    return isWebKit() && isWebKit616OrNewer() && isSafariWebKit();
}
function getTouchSupport() {
    var n = navigator;
    var maxTouchPoints = 0;
    var touchEvent;
    if (n.maxTouchPoints !== void 0) {
        maxTouchPoints = toInt(n.maxTouchPoints);
    } else if (n.msMaxTouchPoints !== void 0) {
        maxTouchPoints = n.msMaxTouchPoints;
    }
    try {
        document.createEvent("TouchEvent");
        touchEvent = true;
    } catch (_a) {
        touchEvent = false;
    }
    var touchStart = "ontouchstart" in window;
    return {
        maxTouchPoints,
        touchEvent,
        touchStart,
    };
}
function getOsCpu() {
    return navigator.oscpu;
}
function getLanguages() {
    var n = navigator;
    var result = [];
    var language =
        n.language || n.userLanguage || n.browserLanguage || n.systemLanguage;
    if (language !== void 0) {
        result.push([language]);
    }
    if (Array.isArray(n.languages)) {
        if (!(isChromium() && isChromium86OrNewer())) {
            result.push(n.languages);
        }
    } else if (typeof n.languages === "string") {
        var languages = n.languages;
        if (languages) {
            result.push(languages.split(","));
        }
    }
    return result;
}
function getColorDepth() {
    return window.screen.colorDepth;
}
function getDeviceMemory() {
    return replaceNaN(toFloat(navigator.deviceMemory), void 0);
}
function getScreenResolution() {
    if (isWebKit() && isWebKit616OrNewer() && isSafariWebKit()) {
        return void 0;
    }
    return getUnstableScreenResolution();
}
function getUnstableScreenResolution() {
    var s = screen;
    var parseDimension = function (value) {
        return replaceNaN(toInt(value), null);
    };
    var dimensions = [parseDimension(s.width), parseDimension(s.height)];
    dimensions.sort().reverse();
    return dimensions;
}
var screenFrameCheckInterval = 2500;
var roundingPrecision = 10;
var screenFrameBackup;
var screenFrameSizeTimeoutId;
function watchScreenFrame() {
    if (screenFrameSizeTimeoutId !== void 0) {
        return;
    }
    var checkScreenFrame = function () {
        var frameSize = getCurrentScreenFrame();
        if (isFrameSizeNull(frameSize)) {
            screenFrameSizeTimeoutId = setTimeout(
                checkScreenFrame,
                screenFrameCheckInterval,
            );
        } else {
            screenFrameBackup = frameSize;
            screenFrameSizeTimeoutId = void 0;
        }
    };
    checkScreenFrame();
}
function getUnstableScreenFrame() {
    var _this = this;
    watchScreenFrame();
    return function () {
        return __awaiter(_this, void 0, void 0, function () {
            var frameSize;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        frameSize = getCurrentScreenFrame();
                        if (!isFrameSizeNull(frameSize)) return [3, 2];
                        if (screenFrameBackup) {
                            return [
                                2,
                                __spreadArray([], screenFrameBackup, true),
                            ];
                        }
                        if (!getFullscreenElement()) return [3, 2];
                        return [4, exitFullscreen()];
                    case 1:
                        _a.sent();
                        frameSize = getCurrentScreenFrame();
                        _a.label = 2;
                    case 2:
                        if (!isFrameSizeNull(frameSize)) {
                            screenFrameBackup = frameSize;
                        }
                        return [2, frameSize];
                }
            });
        });
    };
}
function getScreenFrame() {
    var _this = this;
    if (isWebKit() && isWebKit616OrNewer() && isSafariWebKit()) {
        return function () {
            return Promise.resolve(void 0);
        };
    }
    var screenFrameGetter = getUnstableScreenFrame();
    return function () {
        return __awaiter(_this, void 0, void 0, function () {
            var frameSize, processSize;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        return [4, screenFrameGetter()];
                    case 1:
                        frameSize = _a.sent();
                        processSize = function (sideSize) {
                            return sideSize === null
                                ? null
                                : round(sideSize, roundingPrecision);
                        };
                        return [
                            2,
                            [
                                processSize(frameSize[0]),
                                processSize(frameSize[1]),
                                processSize(frameSize[2]),
                                processSize(frameSize[3]),
                            ],
                        ];
                }
            });
        });
    };
}
function getCurrentScreenFrame() {
    var s = screen;
    return [
        replaceNaN(toFloat(s.availTop), null),
        replaceNaN(
            toFloat(s.width) -
                toFloat(s.availWidth) -
                replaceNaN(toFloat(s.availLeft), 0),
            null,
        ),
        replaceNaN(
            toFloat(s.height) -
                toFloat(s.availHeight) -
                replaceNaN(toFloat(s.availTop), 0),
            null,
        ),
        replaceNaN(toFloat(s.availLeft), null),
    ];
}
function isFrameSizeNull(frameSize) {
    for (var i = 0; i < 4; ++i) {
        if (frameSize[i]) {
            return false;
        }
    }
    return true;
}
function getHardwareConcurrency() {
    return replaceNaN(toInt(navigator.hardwareConcurrency), void 0);
}
function getTimezone() {
    var _a;
    var DateTimeFormat =
        (_a = window.Intl) === null || _a === void 0
            ? void 0
            : _a.DateTimeFormat;
    if (DateTimeFormat) {
        var timezone = new DateTimeFormat().resolvedOptions().timeZone;
        if (timezone) {
            return timezone;
        }
    }
    var offset = -getTimezoneOffset();
    return "UTC".concat(offset >= 0 ? "+" : "").concat(offset);
}
function getTimezoneOffset() {
    var currentYear = /* @__PURE__ */ new Date().getFullYear();
    return Math.max(
        // `getTimezoneOffset` returns a number as a string in some unidentified cases
        toFloat(new Date(currentYear, 0, 1).getTimezoneOffset()),
        toFloat(new Date(currentYear, 6, 1).getTimezoneOffset()),
    );
}
function getSessionStorage() {
    try {
        return !!window.sessionStorage;
    } catch (error) {
        return true;
    }
}
function getLocalStorage() {
    try {
        return !!window.localStorage;
    } catch (e) {
        return true;
    }
}
function getIndexedDB() {
    if (isTrident() || isEdgeHTML()) {
        return void 0;
    }
    try {
        return !!window.indexedDB;
    } catch (e) {
        return true;
    }
}
function getOpenDatabase() {
    return !!window.openDatabase;
}
function getCpuClass() {
    return navigator.cpuClass;
}
function getPlatform() {
    var platform = navigator.platform;
    if (platform === "MacIntel") {
        if (isWebKit() && !isDesktopWebKit()) {
            return isIPad() ? "iPad" : "iPhone";
        }
    }
    return platform;
}
function getVendor() {
    return navigator.vendor || "";
}
function getVendorFlavors() {
    var flavors = [];
    for (
        var _i = 0,
            _a = [
                // Blink and some browsers on iOS
                "chrome",
                // Safari on macOS
                "safari",
                // Chrome on iOS (checked in 85 on 13 and 87 on 14)
                "__crWeb",
                "__gCrWeb",
                // Yandex Browser on iOS, macOS and Android (checked in 21.2 on iOS 14, macOS and Android)
                "yandex",
                // Yandex Browser on iOS (checked in 21.2 on 14)
                "__yb",
                "__ybro",
                // Firefox on iOS (checked in 32 on 14)
                "__firefox__",
                // Edge on iOS (checked in 46 on 14)
                "__edgeTrackingPreventionStatistics",
                "webkit",
                // Opera Touch on iOS (checked in 2.6 on 14)
                "oprt",
                // Samsung Internet on Android (checked in 11.1)
                "samsungAr",
                // UC Browser on Android (checked in 12.10 and 13.0)
                "ucweb",
                "UCShellJava",
                // Puffin on Android (checked in 9.0)
                "puffinDevice",
                // UC on iOS and Opera on Android have no specific global variables
                // Edge for Android isn't checked
            ];
        _i < _a.length;
        _i++
    ) {
        var key = _a[_i];
        var value = window[key];
        if (value && typeof value === "object") {
            flavors.push(key);
        }
    }
    return flavors.sort();
}
function areCookiesEnabled() {
    var d = document;
    try {
        d.cookie = "cookietest=1; SameSite=Strict;";
        var result = d.cookie.indexOf("cookietest=") !== -1;
        d.cookie =
            "cookietest=1; SameSite=Strict; expires=Thu, 01-Jan-1970 00:00:01 GMT";
        return result;
    } catch (e) {
        return false;
    }
}
function getFilters() {
    return {};
}
function getDomBlockers(_a) {
    var _b = _a === void 0 ? {} : _a,
        debug = _b.debug;
    return __awaiter(this, void 0, void 0, function () {
        var filters,
            filterNames,
            allSelectors,
            blockedSelectors,
            activeBlockers;
        var _c;
        return __generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    if (!isApplicable()) {
                        return [2, void 0];
                    }
                    filters = getFilters();
                    filterNames = Object.keys(filters);
                    allSelectors = (_c = []).concat.apply(
                        _c,
                        filterNames.map(function (filterName) {
                            return filters[filterName];
                        }),
                    );
                    return [4, getBlockedSelectors(allSelectors)];
                case 1:
                    blockedSelectors = _d.sent();
                    if (debug) {
                        printDebug(filters, blockedSelectors);
                    }
                    activeBlockers = filterNames.filter(function (filterName) {
                        var selectors = filters[filterName];
                        var blockedCount = countTruthy(
                            selectors.map(function (selector) {
                                return blockedSelectors[selector];
                            }),
                        );
                        return blockedCount > selectors.length * 0.6;
                    });
                    activeBlockers.sort();
                    return [2, activeBlockers];
            }
        });
    });
}
function isApplicable() {
    return isWebKit() || isAndroid();
}
function getBlockedSelectors(selectors) {
    var _a;
    return __awaiter(this, void 0, void 0, function () {
        var d, root, elements, blockedSelectors, i, element, holder, i;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    d = document;
                    root = d.createElement("div");
                    elements = new Array(selectors.length);
                    blockedSelectors = {};
                    forceShow(root);
                    for (i = 0; i < selectors.length; ++i) {
                        element = selectorToElement(selectors[i]);
                        if (element.tagName === "DIALOG") {
                            element.show();
                        }
                        holder = d.createElement("div");
                        forceShow(holder);
                        holder.appendChild(element);
                        root.appendChild(holder);
                        elements[i] = element;
                    }
                    _b.label = 1;
                case 1:
                    if (!!d.body) return [3, 3];
                    return [4, wait(50)];
                case 2:
                    _b.sent();
                    return [3, 1];
                case 3:
                    d.body.appendChild(root);
                    try {
                        for (i = 0; i < selectors.length; ++i) {
                            if (!elements[i].offsetParent) {
                                blockedSelectors[selectors[i]] = true;
                            }
                        }
                    } finally {
                        (_a = root.parentNode) === null || _a === void 0
                            ? void 0
                            : _a.removeChild(root);
                    }
                    return [2, blockedSelectors];
            }
        });
    });
}
function forceShow(element) {
    element.style.setProperty("visibility", "hidden", "important");
    element.style.setProperty("display", "block", "important");
}
function printDebug(filters, blockedSelectors) {
    var message = "DOM blockers debug:\n```";
    for (var _i = 0, _a = Object.keys(filters); _i < _a.length; _i++) {
        var filterName = _a[_i];
        message += "\n".concat(filterName, ":");
        for (var _b = 0, _c = filters[filterName]; _b < _c.length; _b++) {
            var selector = _c[_b];
            message += "\n  "
                .concat(blockedSelectors[selector] ? "🚫" : "➡️", " ")
                .concat(selector);
        }
    }
    console.log("".concat(message, "\n```"));
}
function getColorGamut() {
    for (var _i = 0, _a = ["rec2020", "p3", "srgb"]; _i < _a.length; _i++) {
        var gamut = _a[_i];
        if (matchMedia("(color-gamut: ".concat(gamut, ")")).matches) {
            return gamut;
        }
    }
    return void 0;
}
function areColorsInverted() {
    if (doesMatch$5("inverted")) {
        return true;
    }
    if (doesMatch$5("none")) {
        return false;
    }
    return void 0;
}
function doesMatch$5(value) {
    return matchMedia("(inverted-colors: ".concat(value, ")")).matches;
}
function areColorsForced() {
    if (doesMatch$4("active")) {
        return true;
    }
    if (doesMatch$4("none")) {
        return false;
    }
    return void 0;
}
function doesMatch$4(value) {
    return matchMedia("(forced-colors: ".concat(value, ")")).matches;
}
var maxValueToCheck = 100;
function getMonochromeDepth() {
    if (!matchMedia("(min-monochrome: 0)").matches) {
        return void 0;
    }
    for (var i = 0; i <= maxValueToCheck; ++i) {
        if (matchMedia("(max-monochrome: ".concat(i, ")")).matches) {
            return i;
        }
    }
    throw new Error("Too high value");
}
function getContrastPreference() {
    if (doesMatch$3("no-preference")) {
        return 0;
    }
    if (doesMatch$3("high") || doesMatch$3("more")) {
        return 1;
    }
    if (doesMatch$3("low") || doesMatch$3("less")) {
        return -1;
    }
    if (doesMatch$3("forced")) {
        return 10;
    }
    return void 0;
}
function doesMatch$3(value) {
    return matchMedia("(prefers-contrast: ".concat(value, ")")).matches;
}
function isMotionReduced() {
    if (doesMatch$2("reduce")) {
        return true;
    }
    if (doesMatch$2("no-preference")) {
        return false;
    }
    return void 0;
}
function doesMatch$2(value) {
    return matchMedia("(prefers-reduced-motion: ".concat(value, ")")).matches;
}
function isTransparencyReduced() {
    if (doesMatch$1("reduce")) {
        return true;
    }
    if (doesMatch$1("no-preference")) {
        return false;
    }
    return void 0;
}
function doesMatch$1(value) {
    return matchMedia("(prefers-reduced-transparency: ".concat(value, ")"))
        .matches;
}
function isHDR() {
    if (doesMatch("high")) {
        return true;
    }
    if (doesMatch("standard")) {
        return false;
    }
    return void 0;
}
function doesMatch(value) {
    return matchMedia("(dynamic-range: ".concat(value, ")")).matches;
}
var M = Math;
var fallbackFn = function () {
    return 0;
};
function getMathFingerprint() {
    var acos = M.acos || fallbackFn;
    var acosh = M.acosh || fallbackFn;
    var asin = M.asin || fallbackFn;
    var asinh = M.asinh || fallbackFn;
    var atanh = M.atanh || fallbackFn;
    var atan = M.atan || fallbackFn;
    var sin = M.sin || fallbackFn;
    var sinh = M.sinh || fallbackFn;
    var cos = M.cos || fallbackFn;
    var cosh = M.cosh || fallbackFn;
    var tan = M.tan || fallbackFn;
    var tanh = M.tanh || fallbackFn;
    var exp = M.exp || fallbackFn;
    var expm1 = M.expm1 || fallbackFn;
    var log1p = M.log1p || fallbackFn;
    var powPI = function (value) {
        return M.pow(M.PI, value);
    };
    var acoshPf = function (value) {
        return M.log(value + M.sqrt(value * value - 1));
    };
    var asinhPf = function (value) {
        return M.log(value + M.sqrt(value * value + 1));
    };
    var atanhPf = function (value) {
        return M.log((1 + value) / (1 - value)) / 2;
    };
    var sinhPf = function (value) {
        return M.exp(value) - 1 / M.exp(value) / 2;
    };
    var coshPf = function (value) {
        return (M.exp(value) + 1 / M.exp(value)) / 2;
    };
    var expm1Pf = function (value) {
        return M.exp(value) - 1;
    };
    var tanhPf = function (value) {
        return (M.exp(2 * value) - 1) / (M.exp(2 * value) + 1);
    };
    var log1pPf = function (value) {
        return M.log(1 + value);
    };
    return {
        acos: acos(0.12312423423423424),
        acosh: acosh(1e308),
        acoshPf: acoshPf(1e154),
        asin: asin(0.12312423423423424),
        asinh: asinh(1),
        asinhPf: asinhPf(1),
        atanh: atanh(0.5),
        atanhPf: atanhPf(0.5),
        atan: atan(0.5),
        sin: sin(-1e300),
        sinh: sinh(1),
        sinhPf: sinhPf(1),
        cos: cos(10.000000000123),
        cosh: cosh(1),
        coshPf: coshPf(1),
        tan: tan(-1e300),
        tanh: tanh(1),
        tanhPf: tanhPf(1),
        exp: exp(1),
        expm1: expm1(1),
        expm1Pf: expm1Pf(1),
        log1p: log1p(10),
        log1pPf: log1pPf(10),
        powPI: powPI(-100),
    };
}
var defaultText = "mmMwWLliI0fiflO&1";
var presets = {
    /**
     * The default font. User can change it in desktop Chrome, desktop Firefox, IE 11,
     * Android Chrome (but only when the size is ≥ than the default) and Android Firefox.
     */
    default: [],
    /** OS font on macOS. User can change its size and weight. Applies after Safari restart. */
    apple: [{ font: "-apple-system-body" }],
    /** User can change it in desktop Chrome and desktop Firefox. */
    serif: [{ fontFamily: "serif" }],
    /** User can change it in desktop Chrome and desktop Firefox. */
    sans: [{ fontFamily: "sans-serif" }],
    /** User can change it in desktop Chrome and desktop Firefox. */
    mono: [{ fontFamily: "monospace" }],
    /**
     * Check the smallest allowed font size. User can change it in desktop Chrome, desktop Firefox and desktop Safari.
     * The height can be 0 in Chrome on a retina display.
     */
    min: [{ fontSize: "1px" }],
    /** Tells one OS from another in desktop Chrome. */
    system: [{ fontFamily: "system-ui" }],
};
function getFontPreferences() {
    return withNaturalFonts(function (document2, container) {
        var elements = {};
        var sizes = {};
        for (var _i = 0, _a = Object.keys(presets); _i < _a.length; _i++) {
            var key = _a[_i];
            var _b = presets[key],
                _c = _b[0],
                style = _c === void 0 ? {} : _c,
                _d = _b[1],
                text = _d === void 0 ? defaultText : _d;
            var element = document2.createElement("span");
            element.textContent = text;
            element.style.whiteSpace = "nowrap";
            for (var _e = 0, _f = Object.keys(style); _e < _f.length; _e++) {
                var name_1 = _f[_e];
                var value = style[name_1];
                if (value !== void 0) {
                    element.style[name_1] = value;
                }
            }
            elements[key] = element;
            container.append(document2.createElement("br"), element);
        }
        for (var _g = 0, _h = Object.keys(presets); _g < _h.length; _g++) {
            var key = _h[_g];
            sizes[key] = elements[key].getBoundingClientRect().width;
        }
        return sizes;
    });
}
function withNaturalFonts(action, containerWidthPx) {
    if (containerWidthPx === void 0) {
        containerWidthPx = 4e3;
    }
    return withIframe(function (_, iframeWindow) {
        var iframeDocument = iframeWindow.document;
        var iframeBody = iframeDocument.body;
        var bodyStyle = iframeBody.style;
        bodyStyle.width = "".concat(containerWidthPx, "px");
        bodyStyle.webkitTextSizeAdjust = bodyStyle.textSizeAdjust = "none";
        if (isChromium()) {
            iframeBody.style.zoom = "".concat(
                1 / iframeWindow.devicePixelRatio,
            );
        } else if (isWebKit()) {
            iframeBody.style.zoom = "reset";
        }
        var linesOfText = iframeDocument.createElement("div");
        linesOfText.textContent = __spreadArray(
            [],
            Array((containerWidthPx / 20) << 0),
            true,
        )
            .map(function () {
                return "word";
            })
            .join(" ");
        iframeBody.appendChild(linesOfText);
        return action(iframeDocument, iframeBody);
    }, '<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">');
}
function isPdfViewerEnabled() {
    return navigator.pdfViewerEnabled;
}
function getArchitecture() {
    var f = new Float32Array(1);
    var u8 = new Uint8Array(f.buffer);
    f[0] = Infinity;
    f[0] = f[0] - f[0];
    return u8[3];
}
function getApplePayState() {
    var ApplePaySession = window.ApplePaySession;
    if (
        typeof (ApplePaySession === null || ApplePaySession === void 0
            ? void 0
            : ApplePaySession.canMakePayments) !== "function"
    ) {
        return -1;
    }
    if (willPrintConsoleError()) {
        return -3;
    }
    try {
        return ApplePaySession.canMakePayments() ? 1 : 0;
    } catch (error) {
        return getStateFromError(error);
    }
}
var willPrintConsoleError = isAnyParentCrossOrigin;
function getStateFromError(error) {
    if (
        error instanceof Error &&
        error.name === "InvalidAccessError" &&
        /\bfrom\b.*\binsecure\b/i.test(error.message)
    ) {
        return -2;
    }
    throw error;
}
function getPrivateClickMeasurement() {
    var _a;
    var link = document.createElement("a");
    var sourceId =
        (_a = link.attributionSourceId) !== null && _a !== void 0
            ? _a
            : link.attributionsourceid;
    return sourceId === void 0 ? void 0 : String(sourceId);
}
var STATUS_NO_GL_CONTEXT = -1;
var STATUS_GET_PARAMETER_NOT_A_FUNCTION = -2;
var validContextParameters = /* @__PURE__ */ new Set([
    10752, 2849, 2884, 2885, 2886, 2928, 2929, 2930, 2931, 2932, 2960, 2961,
    2962, 2963, 2964, 2965, 2966, 2967, 2968, 2978, 3024, 3042, 3088, 3089,
    3106, 3107, 32773, 32777, 32777, 32823, 32824, 32936, 32937, 32938, 32939,
    32968, 32969, 32970, 32971, 3317, 33170, 3333, 3379, 3386, 33901, 33902,
    34016, 34024, 34076, 3408, 3410, 3411, 3412, 3413, 3414, 3415, 34467, 34816,
    34817, 34818, 34819, 34877, 34921, 34930, 35660, 35661, 35724, 35738, 35739,
    36003, 36004, 36005, 36347, 36348, 36349, 37440, 37441, 37443, 7936, 7937,
    7938,
    // SAMPLE_ALPHA_TO_COVERAGE (32926) and SAMPLE_COVERAGE (32928) are excluded because they trigger a console warning
    // in IE, Chrome ≤ 59 and Safari ≤ 13 and give no entropy.
]);
var validExtensionParams = /* @__PURE__ */ new Set([
    34047, 35723, 36063, 34852, 34853, 34854, 34229, 36392, 36795, 38449,
    // MAX_VIEWS_OVR
]);
var shaderTypes = ["FRAGMENT_SHADER", "VERTEX_SHADER"];
var precisionTypes = [
    "LOW_FLOAT",
    "MEDIUM_FLOAT",
    "HIGH_FLOAT",
    "LOW_INT",
    "MEDIUM_INT",
    "HIGH_INT",
];
var rendererInfoExtensionName = "WEBGL_debug_renderer_info";
var polygonModeExtensionName = "WEBGL_polygon_mode";
function getWebGlBasics(_a) {
    var _b, _c, _d, _e, _f, _g;
    var cache = _a.cache;
    var gl = getWebGLContext(cache);
    if (!gl) {
        return STATUS_NO_GL_CONTEXT;
    }
    if (!isValidParameterGetter(gl)) {
        return STATUS_GET_PARAMETER_NOT_A_FUNCTION;
    }
    var debugExtension = shouldAvoidDebugRendererInfo()
        ? null
        : gl.getExtension(rendererInfoExtensionName);
    return {
        version:
            ((_b = gl.getParameter(gl.VERSION)) === null || _b === void 0
                ? void 0
                : _b.toString()) || "",
        vendor:
            ((_c = gl.getParameter(gl.VENDOR)) === null || _c === void 0
                ? void 0
                : _c.toString()) || "",
        vendorUnmasked: debugExtension
            ? (_d = gl.getParameter(debugExtension.UNMASKED_VENDOR_WEBGL)) ===
                  null || _d === void 0
                ? void 0
                : _d.toString()
            : "",
        renderer:
            ((_e = gl.getParameter(gl.RENDERER)) === null || _e === void 0
                ? void 0
                : _e.toString()) || "",
        rendererUnmasked: debugExtension
            ? (_f = gl.getParameter(debugExtension.UNMASKED_RENDERER_WEBGL)) ===
                  null || _f === void 0
                ? void 0
                : _f.toString()
            : "",
        shadingLanguageVersion:
            ((_g = gl.getParameter(gl.SHADING_LANGUAGE_VERSION)) === null ||
            _g === void 0
                ? void 0
                : _g.toString()) || "",
    };
}
function getWebGlExtensions(_a) {
    var cache = _a.cache;
    var gl = getWebGLContext(cache);
    if (!gl) {
        return STATUS_NO_GL_CONTEXT;
    }
    if (!isValidParameterGetter(gl)) {
        return STATUS_GET_PARAMETER_NOT_A_FUNCTION;
    }
    var extensions = gl.getSupportedExtensions();
    var contextAttributes = gl.getContextAttributes();
    var unsupportedExtensions = [];
    var attributes = [];
    var parameters = [];
    var extensionParameters = [];
    var shaderPrecisions = [];
    if (contextAttributes) {
        for (
            var _i = 0, _b = Object.keys(contextAttributes);
            _i < _b.length;
            _i++
        ) {
            var attributeName = _b[_i];
            attributes.push(
                ""
                    .concat(attributeName, "=")
                    .concat(contextAttributes[attributeName]),
            );
        }
    }
    var constants = getConstantsFromPrototype(gl);
    for (var _c = 0, constants_1 = constants; _c < constants_1.length; _c++) {
        var constant = constants_1[_c];
        var code = gl[constant];
        parameters.push(
            ""
                .concat(constant, "=")
                .concat(code)
                .concat(
                    validContextParameters.has(code)
                        ? "=".concat(gl.getParameter(code))
                        : "",
                ),
        );
    }
    if (extensions) {
        for (
            var _d = 0, extensions_1 = extensions;
            _d < extensions_1.length;
            _d++
        ) {
            var name_1 = extensions_1[_d];
            if (
                (name_1 === rendererInfoExtensionName &&
                    shouldAvoidDebugRendererInfo()) ||
                (name_1 === polygonModeExtensionName &&
                    shouldAvoidPolygonModeExtensions())
            ) {
                continue;
            }
            var extension = gl.getExtension(name_1);
            if (!extension) {
                unsupportedExtensions.push(name_1);
                continue;
            }
            for (
                var _e = 0, _f = getConstantsFromPrototype(extension);
                _e < _f.length;
                _e++
            ) {
                var constant = _f[_e];
                var code = extension[constant];
                extensionParameters.push(
                    ""
                        .concat(constant, "=")
                        .concat(code)
                        .concat(
                            validExtensionParams.has(code)
                                ? "=".concat(gl.getParameter(code))
                                : "",
                        ),
                );
            }
        }
    }
    for (
        var _g = 0, shaderTypes_1 = shaderTypes;
        _g < shaderTypes_1.length;
        _g++
    ) {
        var shaderType = shaderTypes_1[_g];
        for (
            var _h = 0, precisionTypes_1 = precisionTypes;
            _h < precisionTypes_1.length;
            _h++
        ) {
            var precisionType = precisionTypes_1[_h];
            var shaderPrecision = getShaderPrecision(
                gl,
                shaderType,
                precisionType,
            );
            shaderPrecisions.push(
                ""
                    .concat(shaderType, ".")
                    .concat(precisionType, "=")
                    .concat(shaderPrecision.join(",")),
            );
        }
    }
    extensionParameters.sort();
    parameters.sort();
    return {
        contextAttributes: attributes,
        parameters,
        shaderPrecisions,
        extensions,
        extensionParameters,
        unsupportedExtensions,
    };
}
function getWebGLContext(cache) {
    if (cache.webgl) {
        return cache.webgl.context;
    }
    var canvas = document.createElement("canvas");
    var context;
    canvas.addEventListener("webglCreateContextError", function () {
        return (context = void 0);
    });
    for (
        var _i = 0, _a = ["webgl", "experimental-webgl"];
        _i < _a.length;
        _i++
    ) {
        var type = _a[_i];
        try {
            context = canvas.getContext(type);
        } catch (_b) {}
        if (context) {
            break;
        }
    }
    cache.webgl = { context };
    return context;
}
function getShaderPrecision(gl, shaderType, precisionType) {
    var shaderPrecision = gl.getShaderPrecisionFormat(
        gl[shaderType],
        gl[precisionType],
    );
    return shaderPrecision
        ? [
              shaderPrecision.rangeMin,
              shaderPrecision.rangeMax,
              shaderPrecision.precision,
          ]
        : [];
}
function getConstantsFromPrototype(obj) {
    var keys = Object.keys(obj.__proto__);
    return keys.filter(isConstantLike);
}
function isConstantLike(key) {
    return typeof key === "string" && !key.match(/[^A-Z0-9_x]/);
}
function shouldAvoidDebugRendererInfo() {
    return isGecko();
}
function shouldAvoidPolygonModeExtensions() {
    return isChromium() || isWebKit();
}
function isValidParameterGetter(gl) {
    return typeof gl.getParameter === "function";
}
function getAudioContextBaseLatency() {
    var _a;
    var isAllowedPlatform = isAndroid() || isWebKit();
    if (!isAllowedPlatform) {
        return -2;
    }
    if (!window.AudioContext) {
        return -1;
    }
    return (_a = new AudioContext().baseLatency) !== null && _a !== void 0
        ? _a
        : -1;
}
var sources = {
    // READ FIRST:
    // See https://github.com/fingerprintjs/fingerprintjs/blob/master/contributing.md#how-to-make-an-entropy-source
    // to learn how entropy source works and how to make your own.
    // The sources run in this exact order.
    // The asynchronous sources are at the start to run in parallel with other sources.
    fonts: getFonts,
    domBlockers: getDomBlockers,
    fontPreferences: getFontPreferences,
    audio: getAudioFingerprint,
    screenFrame: getScreenFrame,
    canvas: getCanvasFingerprint,
    osCpu: getOsCpu,
    languages: getLanguages,
    colorDepth: getColorDepth,
    deviceMemory: getDeviceMemory,
    screenResolution: getScreenResolution,
    hardwareConcurrency: getHardwareConcurrency,
    timezone: getTimezone,
    sessionStorage: getSessionStorage,
    localStorage: getLocalStorage,
    indexedDB: getIndexedDB,
    openDatabase: getOpenDatabase,
    cpuClass: getCpuClass,
    platform: getPlatform,
    plugins: getPlugins,
    touchSupport: getTouchSupport,
    vendor: getVendor,
    vendorFlavors: getVendorFlavors,
    cookiesEnabled: areCookiesEnabled,
    colorGamut: getColorGamut,
    invertedColors: areColorsInverted,
    forcedColors: areColorsForced,
    monochrome: getMonochromeDepth,
    contrast: getContrastPreference,
    reducedMotion: isMotionReduced,
    reducedTransparency: isTransparencyReduced,
    hdr: isHDR,
    math: getMathFingerprint,
    pdfViewerEnabled: isPdfViewerEnabled,
    architecture: getArchitecture,
    applePay: getApplePayState,
    privateClickMeasurement: getPrivateClickMeasurement,
    audioBaseLatency: getAudioContextBaseLatency,
    // Some sources can affect other sources (e.g. WebGL can affect canvas), so it's important to run these sources
    // after other sources.
    webGlBasics: getWebGlBasics,
    webGlExtensions: getWebGlExtensions,
};
function loadBuiltinSources(options) {
    return loadSources(sources, options, []);
}
var commentTemplate = "$ if upgrade to Pro: https://fpjs.dev/pro";
function getConfidence(components) {
    var openConfidenceScore = getOpenConfidenceScore(components);
    var proConfidenceScore = deriveProConfidenceScore(openConfidenceScore);
    return {
        score: openConfidenceScore,
        comment: commentTemplate.replace(/\$/g, "".concat(proConfidenceScore)),
    };
}
function getOpenConfidenceScore(components) {
    if (isAndroid()) {
        return 0.4;
    }
    if (isWebKit()) {
        return isDesktopWebKit() && !(isWebKit616OrNewer() && isSafariWebKit())
            ? 0.5
            : 0.3;
    }
    var platform =
        "value" in components.platform ? components.platform.value : "";
    if (/^Win/.test(platform)) {
        return 0.6;
    }
    if (/^Mac/.test(platform)) {
        return 0.5;
    }
    return 0.7;
}
function deriveProConfidenceScore(openConfidenceScore) {
    return round(0.99 + 0.01 * openConfidenceScore, 1e-4);
}
function componentsToCanonicalString(components) {
    var result = "";
    for (
        var _i = 0, _a = Object.keys(components).sort();
        _i < _a.length;
        _i++
    ) {
        var componentKey = _a[_i];
        var component = components[componentKey];
        var value =
            "error" in component ? "error" : JSON.stringify(component.value);
        result += ""
            .concat(result ? "|" : "")
            .concat(componentKey.replace(/([:|\\])/g, "\\$1"), ":")
            .concat(value);
    }
    return result;
}
function componentsToDebugString(components) {
    return JSON.stringify(
        components,
        function (_key, value) {
            if (value instanceof Error) {
                return errorToObject(value);
            }
            return value;
        },
        2,
    );
}
function hashComponents(components) {
    return x64hash128(componentsToCanonicalString(components));
}
function makeLazyGetResult(components) {
    var visitorIdCache;
    var confidence = getConfidence(components);
    return {
        get visitorId() {
            if (visitorIdCache === void 0) {
                visitorIdCache = hashComponents(this.components);
            }
            return visitorIdCache;
        },
        set visitorId(visitorId) {
            visitorIdCache = visitorId;
        },
        confidence,
        components,
        version,
    };
}
function prepareForSources(delayFallback) {
    if (delayFallback === void 0) {
        delayFallback = 50;
    }
    return requestIdleCallbackIfAvailable(delayFallback, delayFallback * 2);
}
function makeAgent(getComponents, debug) {
    var creationTime = Date.now();
    return {
        get: function (options) {
            return __awaiter(this, void 0, void 0, function () {
                var startTime, components, result;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            startTime = Date.now();
                            return [4, getComponents()];
                        case 1:
                            components = _a.sent();
                            result = makeLazyGetResult(components);
                            if (
                                debug ||
                                (options === null || options === void 0
                                    ? void 0
                                    : options.debug)
                            ) {
                                console.log(
                                    "Copy the text below to get the debug data:\n\n```\nversion: "
                                        .concat(result.version, "\nuserAgent: ")
                                        .concat(
                                            navigator.userAgent,
                                            "\ntimeBetweenLoadAndGet: ",
                                        )
                                        .concat(
                                            startTime - creationTime,
                                            "\nvisitorId: ",
                                        )
                                        .concat(
                                            result.visitorId,
                                            "\ncomponents: ",
                                        )
                                        .concat(
                                            componentsToDebugString(components),
                                            "\n```",
                                        ),
                                );
                            }
                            return [2, result];
                    }
                });
            });
        },
    };
}
function monitor() {
    if (window.__fpjs_d_m || Math.random() >= 1e-3) {
        return;
    }
    try {
        var request = new XMLHttpRequest();
        request.open(
            "get",
            "https://m1.openfpcdn.io/fingerprintjs/v".concat(
                version,
                "/npm-monitoring",
            ),
            true,
        );
        request.send();
    } catch (error) {
        console.error(error);
    }
}
function load(options) {
    var _a;
    if (options === void 0) {
        options = {};
    }
    return __awaiter(this, void 0, void 0, function () {
        var delayFallback, debug, getComponents;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    if (
                        (_a = options.monitoring) !== null && _a !== void 0
                            ? _a
                            : true
                    ) {
                        monitor();
                    }
                    (delayFallback = options.delayFallback),
                        (debug = options.debug);
                    return [4, prepareForSources(delayFallback)];
                case 1:
                    _b.sent();
                    getComponents = loadBuiltinSources({ cache: {}, debug });
                    return [2, makeAgent(getComponents, debug)];
            }
        });
    });
}
const useUserStore = /* @__PURE__ */ defineStore("ysd-user", () => {
    const userId = ref(null);
    const userUuid = ref(null);
    const init = async () => {
        const storageData = await chrome.storage.local.get(null);
        if (storageData.userId) {
            userId.value = storageData.userId;
        }
        if (storageData.userUuid) {
            userUuid.value = storageData.userUuid;
        }
        if (!userId.value) {
            try {
                userId.value = await generateUserId();
                await chrome.storage.local.set({ userId: userId.value });
            } catch (e) {}
        }
    };
    const generateUserId = async () => {
        try {
            const fp = await load();
            const result = await fp.get();
            if (result.visitorId) {
                return result.visitorId;
            }
        } catch (e) {}
        return null;
    };
    return {
        userId,
        userUuid,
        init,
    };
});
const useConfigStore = /* @__PURE__ */ defineStore("ysd-config", () => {
    const isModalContactShow = ref(false);
    const isModalPaywallShow = ref(false);
    const showPaywall = async () => {
        isModalPaywallShow.value = true;
        try {
            const hookUrl = new URL(
                "https://antonkhoteev.com/khoteev-api/ysd/actions/paywall",
            );
            if (userStore.userId)
                hookUrl.searchParams.append("userId", userStore.userId);
            await fetch(hookUrl, { method: "GET" });
        } catch (e) {}
    };
    const showContact = () => {
        isModalContactShow.value = true;
    };
    const user = ref({
        language: "en",
    });
    const rating = ref({
        show: false,
    });
    const paywall = ref({
        show: false,
        isPaid: false,
    });
    const userStore = useUserStore();
    const init = async () => {
        var _a, _b;
        try {
            const getConfigUrl = new URL(
                "https://antonkhoteev.com/khoteev-api/ysd/config",
            );
            if (userStore.userId)
                getConfigUrl.searchParams.append("userId", userStore.userId);
            if (userStore.userUuid)
                getConfigUrl.searchParams.append(
                    "userUuid",
                    userStore.userUuid,
                );
            if (
                (_b =
                    (_a = chrome.runtime) == null
                        ? void 0
                        : _a.getManifest()) == null
                    ? void 0
                    : _b.version
            )
                getConfigUrl.searchParams.append(
                    "version",
                    chrome.runtime.getManifest().version,
                );
            const response = await fetch(getConfigUrl, { method: "GET" });
            const config = await response.json();
            if (config.user) {
                user.value = config.user;
            }
            if (config.rating) {
                rating.value = config.rating;
            }
            if (config.paywall) {
                paywall.value = config.paywall;
            }
        } catch (e) {}
    };
    return {
        isModalContactShow,
        isModalPaywallShow,
        user,
        rating,
        paywall,
        init,
        showContact,
        showPaywall,
    };
});
const useVideoInfoStore = /* @__PURE__ */ defineStore("ysd-video-info", () => {
    const subtitlesStore = useSubtitlesStore();
    const isInitialized = ref(false);
    const tabId = ref(null);
    const videoId = ref(null);
    const currentTime = ref(0);
    const init = async () => {
        await initCommunication();
        isInitialized.value = true;
    };
    const initCommunication = () => {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage(
                { type: "SIDEBAR_GET_TAB_ID" },
                (response) => {
                    if (!response || !response.tabId) {
                        chrome.runtime.sendMessage({
                            type: "SIDEBAR_CLOSE_SIDEBAR",
                        });
                        return reject(new Error("tabId not found"));
                    }
                    tabId.value = response.tabId;
                    chrome.runtime.onMessage.addListener(
                        (message, sender, sendResponse) => {
                            if (
                                message.type ===
                                `CHANNEL_CURRENT_TIME_${tabId.value}`
                            ) {
                                currentTime.value = message.value;
                            }
                            if (
                                message.type ===
                                `CHANNEL_VIDEO_ID_${tabId.value}`
                            ) {
                                videoId.value = message.value;
                            }
                        },
                    );
                    resolve(tabId.value);
                },
            );
        });
    };
    watch(videoId, async (newValue, oldValue) => {
        if (!newValue) {
            chrome.runtime.sendMessage({ type: "SIDEBAR_CLOSE_SIDEBAR" });
        }
        if (oldValue !== newValue) {
            await subtitlesStore.reset();
        }
    });
    const jumpToTime = (time) => {
        chrome.runtime.sendMessage({
            type: "MESSAGE_TO_TAB_PROXY",
            tabId: tabId.value,
            value: {
                type: "JUMP_TO_TIME",
                value: time,
            },
        });
    };
    return {
        tabId,
        videoId,
        currentTime,
        isInitialized,
        init,
        jumpToTime,
    };
});
const useSubtitlesStore = /* @__PURE__ */ defineStore("ysd-subtitles", () => {
    const videoInfoStore = useVideoInfoStore();
    const panelStore = usePanelStore();
    const configStore = useConfigStore();
    const userStore = useUserStore();
    const isDownloading = ref(false);
    const videoTitle = ref(null);
    const originalLanguages = ref([]);
    const translateLanguages = ref([]);
    const subtitles = ref([]);
    const translations = ref([]);
    const youtubeObject = ref(null);
    const useAlternativeUrl = ref(false);
    const alternativeUrl = ref(null);
    let youtubeObjectLoadCounter = 0;
    watch(
        () => youtubeObject.value,
        async (newValue, oldValue) => {
            var _a, _b, _c, _d, _e, _f;
            const captionsExist =
                ((_c =
                    (_b =
                        (_a = newValue == null ? void 0 : newValue.captions) ==
                        null
                            ? void 0
                            : _a.playerCaptionsTracklistRenderer) == null
                        ? void 0
                        : _b.captionTracks) == null
                    ? void 0
                    : _c.length) > 0;
            const isUnavailable =
                ((_d =
                    newValue == null ? void 0 : newValue.playabilityStatus) ==
                null
                    ? void 0
                    : _d.status) === "ERROR";
            if (!captionsExist || isUnavailable) {
                if (youtubeObjectLoadCounter <= 5) {
                    setTimeout(() => {
                        initYoutubeObject();
                    }, 1e3);
                }
            } else {
                if (
                    ((_e = newValue == null ? void 0 : newValue.videoDetails) ==
                    null
                        ? void 0
                        : _e.videoId) ===
                    ((_f = oldValue == null ? void 0 : oldValue.videoDetails) ==
                    null
                        ? void 0
                        : _f.videoId)
                ) {
                    return;
                }
                try {
                    await initLanguages();
                    await initSubtitles();
                    await fetchVideoTitle();
                } catch (e) {}
            }
        },
        { immediate: true },
    );
    const initLanguages = async () => {
        var _a, _b, _c, _d, _e, _f;
        const captionTracks =
            (_c =
                (_b =
                    (_a = youtubeObject.value) == null
                        ? void 0
                        : _a.captions) == null
                    ? void 0
                    : _b.playerCaptionsTracklistRenderer) == null
                ? void 0
                : _c.captionTracks;
        const translationLanguages =
            (_f =
                (_e =
                    (_d = youtubeObject.value) == null
                        ? void 0
                        : _d.captions) == null
                    ? void 0
                    : _e.playerCaptionsTracklistRenderer) == null
                ? void 0
                : _f.translationLanguages;
        if (captionTracks && captionTracks.length > 0) {
            originalLanguages.value = [];
            captionTracks.map((track2) => {
                originalLanguages.value.push({
                    code: track2.languageCode,
                    name: track2.name.simpleText,
                });
            });
            const oLang = originalLanguages.value.find(
                (language) => language.code === panelStore.originalLanguage,
            );
            if (!oLang) {
                panelStore.originalLanguage = originalLanguages.value[0].code;
            }
        }
        if (translationLanguages && translationLanguages.length > 0) {
            translateLanguages.value = [];
            translationLanguages.map((track2) => {
                translateLanguages.value.push({
                    code: track2.languageCode,
                    name: track2.languageName.simpleText,
                });
            });
            const tLang = translateLanguages.value.find(
                (language) =>
                    language.code === panelStore.defaultTranslateLanguage,
            );
            if (!tLang) {
                panelStore.translateLanguage = "en";
            } else {
                panelStore.translateLanguage = tLang.code;
            }
        }
    };
    const initAlternativeUrl = async () => {
        const response = await fetch(
            `https://antonkhoteev.com/khoteev-api/ysd/video/${encodeURIComponent(videoInfoStore.videoId)}/url`,
            {
                method: "GET",
                headers: {
                    Accept: "application/json",
                },
            },
        );
        if (!response.ok) {
            return;
        }
        const data = await response.json();
        alternativeUrl.value = data == null ? void 0 : data.url;
    };
    const initSubtitles = async () => {
        try {
            await fetchSubtitles();
            await fetchTranslatedSubtitles();
        } catch (e) {}
    };
    const resetTranslations = async () => {
        translations.value = [];
    };
    const reset = async () => {
        videoTitle.value = null;
        panelStore.originalLanguage = null;
        panelStore.translateLanguage = null;
        originalLanguages.value = [];
        translateLanguages.value = [];
        subtitles.value = [];
        translations.value = [];
        youtubeObjectLoadCounter = 0;
        youtubeObject.value = null;
    };
    const mergedSubtitles = computed(() => {
        return mergeSubtitles();
    });
    const subtitlesWithTranslations = computed(() => {
        return mergeSubtitlesAndTranslations();
    });
    const activeSubtitle = computed(() => {
        return (
            mergedSubtitles.value.find((sub) => {
                return (
                    videoInfoStore.currentTime >= sub.start &&
                    videoInfoStore.currentTime <= sub.end
                );
            }) || null
        );
    });
    const initYoutubeObject = async () => {
        youtubeObjectLoadCounter++;
        let response = await fetch(
            `https://www.youtube.com/watch?v=${videoInfoStore.videoId}`,
        );
        const pageText = await response.text();
        const match = pageText.match(
            /ytInitialPlayerResponse\s*=\s*({.+?})\s*;/,
        );
        if (!match) {
            throw new Error("Unknown error");
        }
        youtubeObject.value = JSON.parse(match[1]);
    };
    const fetchVideoTitle = async () => {
        var _a, _b;
        videoTitle.value =
            ((_b =
                (_a = youtubeObject.value) == null
                    ? void 0
                    : _a.videoDetails) == null
                ? void 0
                : _b.title) ?? null;
    };
    const fetchSubtitles = async () => {
        isDownloading.value = true;
        await fetchSubtitlesDirectYoutube();
        if (subtitles.value.length === 0) {
            await initAlternativeUrl();
            useAlternativeUrl.value = true;
            await fetchSubtitlesDirectYoutube();
        }
        isDownloading.value = false;
        try {
            const actionUrl = new URL(
                "https://antonkhoteev.com/khoteev-api/ysd/actions/subs-loading",
            );
            actionUrl.searchParams.append("video", videoInfoStore.videoId);
            actionUrl.searchParams.append("olang", panelStore.originalLanguage);
            actionUrl.searchParams.append(
                "tlang",
                panelStore.translateLanguage,
            );
            actionUrl.searchParams.append("dual", panelStore.isDualSubtitles);
            if (userStore.userId)
                actionUrl.searchParams.append("userId", userStore.userId);
            if (userStore.userUuid)
                actionUrl.searchParams.append("userUuid", userStore.userUuid);
            await fetch(actionUrl, { method: "GET" });
        } catch (e) {}
    };
    const fetchSubtitlesDirectYoutube = async () => {
        var _a, _b, _c, _d;
        const captionTracks =
            (_c =
                (_b =
                    (_a = youtubeObject.value) == null
                        ? void 0
                        : _a.captions) == null
                    ? void 0
                    : _b.playerCaptionsTracklistRenderer) == null
                ? void 0
                : _c.captionTracks;
        if (!captionTracks || captionTracks.length === 0) {
            return;
        }
        let subtitleUrl;
        if (useAlternativeUrl.value) {
            subtitleUrl = new URL(alternativeUrl.value);
            subtitleUrl.searchParams.set("lang", panelStore.originalLanguage);
        } else {
            subtitleUrl =
                (_d = captionTracks.find(
                    (track2) =>
                        track2.languageCode === panelStore.originalLanguage,
                )) == null
                    ? void 0
                    : _d.baseUrl;
            if (!subtitleUrl) {
                subtitleUrl = captionTracks[0].baseUrl;
            }
        }
        const subtitleResponse = await fetch(subtitleUrl.toString());
        const subtitleXml = await subtitleResponse.text();
        if (subtitleXml.length === 0) {
            return;
        }
        subtitles.value = await parseYouTubeSubtitles(subtitleXml);
    };
    const fetchTranslatedSubtitles = async () => {
        console.log("fetchTranslatedSubtitles");
        isDownloading.value = true;
        await fetchTranslatedSubtitlesDirectYoutube();
        if (translations.value.length === 0) {
            await fetchTranslatedSubtitlesDirectYoutube();
        }
        isDownloading.value = false;
    };
    const fetchTranslatedSubtitlesDirectYoutube = async () => {
        var _a, _b, _c, _d;
        console.log("fetchTranslatedSubtitlesDirectYoutube");
        const captionTracks =
            (_c =
                (_b =
                    (_a = youtubeObject.value) == null
                        ? void 0
                        : _a.captions) == null
                    ? void 0
                    : _b.playerCaptionsTracklistRenderer) == null
                ? void 0
                : _c.captionTracks;
        if (!captionTracks || captionTracks.length === 0) {
            isDownloading.value = false;
            return;
        }
        let subtitleUrl;
        if (useAlternativeUrl.value) {
            subtitleUrl = alternativeUrl.value;
        } else {
            subtitleUrl =
                (_d = captionTracks.find(
                    (track2) =>
                        track2.languageCode === panelStore.originalLanguage,
                )) == null
                    ? void 0
                    : _d.baseUrl;
            if (!subtitleUrl) {
                subtitleUrl = captionTracks[0].baseUrl;
            }
        }
        const translationUrl = new URL(subtitleUrl);
        translationUrl.searchParams.append(
            "tlang",
            panelStore.translateLanguage,
        );
        const translationsResponse = await fetch(translationUrl.toString());
        const translationsXml = await translationsResponse.text();
        console.log("translationsXml", translationsXml);
        const parsed = await parseYouTubeSubtitles(translationsXml);
        for (const item of parsed) {
            translations.value.push(item);
        }
    };
    const parseYouTubeSubtitles = async (xmlText) => {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(xmlText, "application/xml");
        const textNodes = Array.from(xmlDoc.getElementsByTagName("text"));
        const formatTime = (time) => {
            const hours = Math.floor(time / 3600);
            const minutes = Math.floor((time % 3600) / 60);
            const seconds = Math.floor(time % 60);
            if (hours > 0) {
                return `${String(hours)}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
            } else {
                return `${String(minutes)}:${String(seconds).padStart(2, "0")}`;
            }
        };
        return textNodes.map((node, index) => {
            const start = parseFloat(node.getAttribute("start"));
            const nextNode = textNodes[index + 1];
            const end = nextNode
                ? parseFloat(nextNode.getAttribute("start"))
                : start + parseFloat(node.getAttribute("dur") || 0);
            return {
                text:
                    node.textContent
                        .replace(/&#39;/g, "'")
                        .replace(/&quot;/g, '"')
                        .replace(/&amp;/g, "&") + " ",
                start,
                end,
                startInFormat: formatTime(start),
            };
        });
    };
    const mergeSubtitlesAndTranslations = () => {
        return subtitles.value.map((sub, i) => ({
            start: sub.start,
            startInFormat: sub.startInFormat,
            end: sub.end,
            text: `${sub.text}`,
            translate: translations.value[i]
                ? `${translations.value[i].text}`
                : "",
        }));
    };
    const mergeSubtitles = () => {
        const merged = [];
        let buffer = {
            text: "",
            translate: "",
            start: null,
            end: null,
            startInFormat: null,
            textSegments: [],
            translateSegments: [],
        };
        subtitles.value.forEach((sub, index) => {
            var _a, _b;
            const cleanText = sub.text.replace(/\s+/g, " ").trim();
            const translationText =
                ((_b =
                    (_a = translations.value[index]) == null
                        ? void 0
                        : _a.text) == null
                    ? void 0
                    : _b.replace(/\s+/g, " ").trim()) || "";
            if (buffer.text.length === 0) {
                buffer = {
                    ...sub,
                    text: cleanText,
                    translate: translationText,
                    textSegments: [
                        { text: cleanText, start: sub.start, end: sub.end },
                    ],
                    translateSegments: [
                        {
                            text: translationText,
                            start: sub.start,
                            end: sub.end,
                        },
                    ],
                };
            } else if (
                buffer.text.length + cleanText.length + 1 <=
                panelStore.blockSize
            ) {
                buffer.text += " " + cleanText;
                buffer.translate += " " + translationText;
                buffer.end = sub.end;
                buffer.textSegments.push({
                    text: cleanText,
                    start: sub.start,
                    end: sub.end,
                });
                buffer.translateSegments.push({
                    text: translationText,
                    start: sub.start,
                    end: sub.end,
                });
            } else {
                merged.push({ ...buffer });
                buffer = {
                    ...sub,
                    text: cleanText,
                    translate: translationText,
                    textSegments: [
                        { text: cleanText, start: sub.start, end: sub.end },
                    ],
                    translateSegments: [
                        {
                            text: translationText,
                            start: sub.start,
                            end: sub.end,
                        },
                    ],
                };
            }
        });
        if (buffer.text.length > 0) {
            merged.push(buffer);
        }
        return merged;
    };
    const scrollToActiveSubtitle = () => {
        const highlightedText = document.querySelector(".highlighted-text");
        if (highlightedText) {
            const parentTextItem =
                highlightedText == null
                    ? void 0
                    : highlightedText.closest(".subtitle");
            if (parentTextItem) {
                parentTextItem.scrollIntoView({
                    behavior: "smooth",
                    block: "center",
                });
            }
            return;
        }
        const highlightedTranslate = document.querySelector(
            ".highlighted-translate",
        );
        if (highlightedTranslate) {
            const parentTranslateItem =
                highlightedTranslate == null
                    ? void 0
                    : highlightedTranslate.closest(".subtitle");
            if (parentTranslateItem) {
                parentTranslateItem.scrollIntoView({
                    behavior: "smooth",
                    block: "center",
                });
            }
        }
    };
    const copySubtitles = async () => {
        const merged = mergedSubtitles.value;
        const { displayMode, isShowTime } = panelStore;
        const textToCopy = merged
            .map((item) => {
                var _a;
                const lines = [];
                if (isShowTime) {
                    lines.push(item.startInFormat);
                }
                const original = item.text.trim();
                const translate =
                    ((_a = item.translate) == null ? void 0 : _a.trim()) ?? "";
                if (displayMode === "original-translate") {
                    lines.push(original, translate);
                } else if (displayMode === "translate-original") {
                    lines.push(translate, original);
                } else if (displayMode === "original-only") {
                    lines.push(original);
                } else if (displayMode === "translate-only") {
                    lines.push(translate);
                }
                return lines.join("\n");
            })
            .join("\n\n");
        try {
            await navigator.clipboard.writeText(textToCopy);
        } catch (e) {}
        try {
            const actionUrl = new URL(
                "https://antonkhoteev.com/khoteev-api/ysd/actions/copy",
            );
            if (userStore.userId)
                actionUrl.searchParams.append("userId", userStore.userId);
            if (userStore.userUuid)
                actionUrl.searchParams.append("userUuid", userStore.userUuid);
            await fetch(actionUrl, { method: "GET" });
        } catch (e) {}
    };
    const downloadSubtitles = async () => {
        if (configStore.paywall.show) {
            await configStore.showPaywall();
            return;
        }
        const merged = mergedSubtitles.value;
        const { displayMode, format } = panelStore;
        const buildTextBlock = (original, translate) => {
            if (displayMode === "original-translate") {
                return [original, translate].filter(Boolean).join("\n");
            } else if (displayMode === "translate-original") {
                return [translate, original].filter(Boolean).join("\n");
            } else if (displayMode === "original-only") {
                return original;
            } else if (displayMode === "translate-only") {
                return translate;
            }
            return "";
        };
        let content = "";
        if (format === "SRT") {
            content = merged
                .map((item, i) => {
                    var _a;
                    const index = i + 1;
                    const start = formatTimeForSRT(item.start);
                    const end = formatTimeForSRT(item.end);
                    const original = item.text.trim();
                    const translated =
                        ((_a = item.translate) == null ? void 0 : _a.trim()) ??
                        "";
                    const textBlock = buildTextBlock(original, translated);
                    return `${index}
${start} --> ${end}
${textBlock}
`;
                })
                .join("\n");
        } else if (format === "VTT") {
            content =
                "WEBVTT\n\n" +
                merged
                    .map((item) => {
                        var _a;
                        const start = formatTimeForVTT(item.start);
                        const end = formatTimeForVTT(item.end);
                        const original = item.text.trim();
                        const translated =
                            ((_a = item.translate) == null
                                ? void 0
                                : _a.trim()) ?? "";
                        const textBlock = buildTextBlock(original, translated);
                        return `${start} --> ${end}
${textBlock}
`;
                    })
                    .join("\n");
        } else if (format === "TXT") {
            content = merged
                .map((item) => {
                    var _a;
                    const original = item.text.trim();
                    const translated =
                        ((_a = item.translate) == null ? void 0 : _a.trim()) ??
                        "";
                    const textBlock = buildTextBlock(original, translated);
                    if (panelStore.isShowTime) {
                        const time = formatTimeForTXT(item.start);
                        return `${time}
${textBlock}`;
                    } else {
                        return `${textBlock}`;
                    }
                })
                .join("\n\n");
        }
        const rawTitle = videoTitle.value ?? "";
        const sanitizedTitle = sanitizeFileName(rawTitle);
        const fallbackName = `subtitles-${/* @__PURE__ */ new Date().toISOString().split("T")[0]}`;
        const baseFileName = sanitizedTitle || fallbackName;
        const fileName = `${baseFileName}.${format.toLowerCase()}`;
        const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = fileName;
        a.click();
        URL.revokeObjectURL(url);
        try {
            const actionUrl = new URL(
                "https://antonkhoteev.com/khoteev-api/ysd/actions/download",
            );
            actionUrl.searchParams.append("format", format);
            if (userStore.userId)
                actionUrl.searchParams.append("userId", userStore.userId);
            if (userStore.userUuid)
                actionUrl.searchParams.append("userUuid", userStore.userUuid);
            await fetch(actionUrl, { method: "GET" });
            if (configStore.paywall.isPaid === false) {
                await configStore.init();
            }
        } catch (e) {}
    };
    const formatTimeForSRT = (seconds) => {
        const date = new Date(seconds * 1e3);
        const hh = String(date.getUTCHours()).padStart(2, "0");
        const mm = String(date.getUTCMinutes()).padStart(2, "0");
        const ss = String(date.getUTCSeconds()).padStart(2, "0");
        const ms = String(date.getUTCMilliseconds()).padStart(3, "0");
        return `${hh}:${mm}:${ss},${ms}`;
    };
    const formatTimeForVTT = (sec) => {
        if (typeof sec !== "number" || !isFinite(sec) || sec < 0) sec = 0;
        const totalMs = Math.round(sec * 1e3);
        const hours = Math.floor(totalMs / 36e5);
        const minutes = Math.floor((totalMs % 36e5) / 6e4);
        const seconds = Math.floor((totalMs % 6e4) / 1e3);
        const ms = totalMs % 1e3;
        const hh = String(hours).padStart(2, "0");
        const mm = String(minutes).padStart(2, "0");
        const ss = String(seconds).padStart(2, "0");
        const mss = String(ms).padStart(3, "0");
        return `${hh}:${mm}:${ss}.${mss}`;
    };
    const formatTimeForTXT = (seconds) => {
        const mins = Math.floor(seconds / 60).toString();
        const secs = Math.floor(seconds % 60)
            .toString()
            .padStart(2, "0");
        return `${mins}:${secs}`;
    };
    function sanitizeFileName(name) {
        return String(name || "")
            .replace(/[/\\?%*:|"<>]/g, "")
            .trim();
    }
    return {
        subtitles,
        translations,
        subtitlesWithTranslations,
        mergedSubtitles,
        activeSubtitle,
        isDownloading,
        originalLanguages,
        translateLanguages,
        reset,
        resetTranslations,
        initYoutubeObject,
        fetchVideoTitle,
        initLanguages,
        initSubtitles,
        fetchSubtitles,
        fetchTranslatedSubtitles,
        copySubtitles,
        downloadSubtitles,
        scrollToActiveSubtitle,
    };
});
const DISPLAY_MODES = [
    "original-translate",
    "translate-original",
    "original-only",
    "translate-only",
];
const usePanelStore = /* @__PURE__ */ defineStore(
    "ysd-panel",
    () => {
        const subtitlesStore = useSubtitlesStore();
        const videoInfoStore = useVideoInfoStore();
        useUserStore();
        const isLightTheme = ref(false);
        watch(isLightTheme.value, (newValue) => {
            if (newValue) {
                document.documentElement.setAttribute("data-theme", "light");
            } else {
                document.documentElement.setAttribute("data-theme", "dark");
            }
        });
        const init = async () => {
            await initTheme();
        };
        const initTheme = async () => {
            if (isLightTheme.value) {
                document.documentElement.setAttribute("data-theme", "light");
            } else {
                document.documentElement.setAttribute("data-theme", "dark");
            }
        };
        const changeTheme = async () => {
            isLightTheme.value = !isLightTheme.value;
            await initTheme();
        };
        const isAutoScrollEnabled = ref(false);
        const toggleAutoScroll = () => {
            isAutoScrollEnabled.value = !isAutoScrollEnabled.value;
            if (isAutoScrollEnabled.value) {
                subtitlesStore.scrollToActiveSubtitle();
            }
        };
        const isShowTime = ref(false);
        const toggleShowTime = () => {
            isShowTime.value = !isShowTime.value;
        };
        const blockSize = ref(200);
        const blockSizeDiff = 25;
        const increaseBlockSize = async () => {
            blockSize.value += blockSizeDiff;
        };
        const decreaseBlockSize = async () => {
            if (blockSize.value > blockSizeDiff) {
                blockSize.value -= blockSizeDiff;
            }
        };
        const originalLanguage = ref(null);
        const translateLanguage = ref(null);
        const defaultTranslateLanguage = ref("en");
        const isDualSubtitles = ref(false);
        const toggleShowTranslate = () => {
            isDualSubtitles.value = !isDualSubtitles.value;
            if (isDualSubtitles.value) {
                displayMode.value = "original-translate";
            } else {
                displayMode.value = "original-only";
            }
        };
        watch(isDualSubtitles, async (newValue, oldValue) => {
            if (!videoInfoStore.isInitialized) return;
            if (newValue === true) {
                await subtitlesStore.fetchTranslatedSubtitles();
            }
        });
        watch(originalLanguage, async (newValue, oldValue) => {
            if (oldValue && newValue && oldValue !== newValue) {
                await subtitlesStore.fetchSubtitles();
                if (subtitlesStore.translations.length === 0) {
                    await subtitlesStore.fetchTranslatedSubtitles();
                }
            }
        });
        watch(translateLanguage, async (newValue, oldValue) => {
            if (oldValue && newValue && oldValue !== newValue) {
                defaultTranslateLanguage.value = newValue;
                await subtitlesStore.resetTranslations();
                await subtitlesStore.fetchTranslatedSubtitles();
            }
        });
        const format = ref("SRT");
        const formats = ["SRT", "VTT", "TXT"];
        const changeFormat = () => {
            const currentIndex = formats.indexOf(format.value);
            const nextIndex = (currentIndex + 1) % formats.length;
            format.value = formats[nextIndex];
        };
        const displayMode = ref("original-only");
        const showOriginal = computed(
            () => displayMode.value !== "translate-only",
        );
        const showTranslate = computed(
            () => displayMode.value !== "original-only",
        );
        const displayReversed = computed(
            () => displayMode.value === "translate-original",
        );
        const cycleDisplayMode = () => {
            const i = DISPLAY_MODES.indexOf(displayMode.value);
            displayMode.value = DISPLAY_MODES[(i + 1) % DISPLAY_MODES.length];
        };
        return {
            init,
            isLightTheme,
            initTheme,
            changeTheme,
            isAutoScrollEnabled,
            toggleAutoScroll,
            isShowTime,
            toggleShowTime,
            isDualSubtitles,
            toggleShowTranslate,
            blockSize,
            increaseBlockSize,
            decreaseBlockSize,
            originalLanguage,
            translateLanguage,
            defaultTranslateLanguage,
            format,
            changeFormat,
            displayMode,
            showOriginal,
            showTranslate,
            displayReversed,
            cycleDisplayMode,
        };
    },
    {
        persist: true,
    },
);
const _export_sfc = (sfc, props) => {
    const target = sfc.__vccOpts || sfc;
    for (const [key, val] of props) {
        target[key] = val;
    }
    return target;
};
const _hoisted_1$6 = { class: "panel" };
const _hoisted_2$5 = { class: "line line-language" };
const _hoisted_3$4 = ["disabled"];
const _hoisted_4$4 = ["value"];
const _hoisted_5$3 = {
    key: 0,
    class: "line line-language",
};
const _hoisted_6$3 = ["disabled"];
const _hoisted_7$1 = ["value"];
const _hoisted_8$1 = { class: "line line-block-settings" };
const _hoisted_9$1 = { class: "buttons" };
const _hoisted_10 = ["disabled"];
const _hoisted_11 = ["disabled"];
const _hoisted_12 = ["disabled"];
const _hoisted_13 = { class: "action-icon" };
const _hoisted_14 = {
    key: 0,
    width: "50",
    height: "28",
    viewBox: "0 0 50 28",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
};
const _hoisted_15 = {
    key: 1,
    width: "50",
    height: "30",
    viewBox: "0 0 50 30",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
};
const _hoisted_16 = {
    key: 2,
    width: "50",
    height: "20",
    viewBox: "0 0 50 20",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
};
const _hoisted_17 = {
    key: 3,
    width: "50",
    height: "18",
    viewBox: "0 0 50 18",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
};
const _hoisted_18 = ["disabled"];
const _hoisted_19 = ["disabled"];
const _hoisted_20 = ["disabled"];
const _hoisted_21 = { class: "action-icon" };
const _hoisted_22 = {
    key: 0,
    width: "32",
    height: "32",
    viewBox: "0 0 32 32",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
};
const _hoisted_23 = {
    key: 1,
    width: "32",
    height: "32",
    viewBox: "0 0 32 32",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
};
const _hoisted_24 = {
    key: 0,
    class: "action-title",
};
const _hoisted_25 = {
    key: 1,
    class: "action-title",
};
const _hoisted_26 = { class: "line line-download" };
const _hoisted_27 = { class: "buttons" };
const _hoisted_28 = ["disabled"];
const _hoisted_29 = { class: "action-icon" };
const _hoisted_30 = ["disabled"];
const _hoisted_31 = ["disabled"];
const _sfc_main$6 = {
    __name: "YsdPanel",
    setup(__props) {
        const panelStore = usePanelStore();
        const subtitlesStore = useSubtitlesStore();
        return (_ctx, _cache) => {
            return (
                openBlock(),
                createElementBlock("div", _hoisted_1$6, [
                    createBaseVNode("div", _hoisted_2$5, [
                        _cache[12] ||
                            (_cache[12] = createBaseVNode(
                                "div",
                                { class: "line-language-title" },
                                "Original",
                                -1,
                            )),
                        withDirectives(
                            createBaseVNode(
                                "select",
                                {
                                    class: "input language",
                                    disabled:
                                        unref(subtitlesStore).originalLanguages
                                            .length === 0,
                                    "onUpdate:modelValue":
                                        _cache[0] ||
                                        (_cache[0] = ($event) =>
                                            (unref(
                                                panelStore,
                                            ).originalLanguage = $event)),
                                },
                                [
                                    (openBlock(true),
                                    createElementBlock(
                                        Fragment,
                                        null,
                                        renderList(
                                            unref(subtitlesStore)
                                                .originalLanguages,
                                            (lang) => {
                                                return (
                                                    openBlock(),
                                                    createElementBlock(
                                                        "option",
                                                        {
                                                            key: lang.code,
                                                            value: lang.code,
                                                        },
                                                        toDisplayString(
                                                            lang.name,
                                                        ),
                                                        9,
                                                        _hoisted_4$4,
                                                    )
                                                );
                                            },
                                        ),
                                        128,
                                    )),
                                ],
                                8,
                                _hoisted_3$4,
                            ),
                            [
                                [
                                    vModelSelect,
                                    unref(panelStore).originalLanguage,
                                ],
                            ],
                        ),
                    ]),
                    unref(panelStore).isDualSubtitles
                        ? (openBlock(),
                          createElementBlock("div", _hoisted_5$3, [
                              _cache[13] ||
                                  (_cache[13] = createBaseVNode(
                                      "div",
                                      { class: "line-language-title" },
                                      "Translate",
                                      -1,
                                  )),
                              withDirectives(
                                  createBaseVNode(
                                      "select",
                                      {
                                          class: "input language",
                                          disabled:
                                              unref(subtitlesStore)
                                                  .translateLanguages.length ===
                                              0,
                                          "onUpdate:modelValue":
                                              _cache[1] ||
                                              (_cache[1] = ($event) =>
                                                  (unref(
                                                      panelStore,
                                                  ).translateLanguage =
                                                      $event)),
                                      },
                                      [
                                          (openBlock(true),
                                          createElementBlock(
                                              Fragment,
                                              null,
                                              renderList(
                                                  unref(subtitlesStore)
                                                      .translateLanguages,
                                                  (lang) => {
                                                      return (
                                                          openBlock(),
                                                          createElementBlock(
                                                              "option",
                                                              {
                                                                  key: lang.code,
                                                                  value: lang.code,
                                                              },
                                                              toDisplayString(
                                                                  lang.name,
                                                              ),
                                                              9,
                                                              _hoisted_7$1,
                                                          )
                                                      );
                                                  },
                                              ),
                                              128,
                                          )),
                                      ],
                                      8,
                                      _hoisted_6$3,
                                  ),
                                  [
                                      [
                                          vModelSelect,
                                          unref(panelStore).translateLanguage,
                                      ],
                                  ],
                              ),
                          ]))
                        : createCommentVNode("", true),
                    createBaseVNode("div", _hoisted_8$1, [
                        createBaseVNode("div", _hoisted_9$1, [
                            createBaseVNode(
                                "button",
                                {
                                    class: normalizeClass([
                                        "action",
                                        {
                                            "action-active":
                                                unref(panelStore)
                                                    .isAutoScrollEnabled,
                                        },
                                    ]),
                                    onClick:
                                        _cache[2] ||
                                        (_cache[2] = (...args) =>
                                            unref(panelStore)
                                                .toggleAutoScroll &&
                                            unref(panelStore).toggleAutoScroll(
                                                ...args,
                                            )),
                                    disabled:
                                        unref(subtitlesStore).subtitles
                                            .length === 0,
                                },
                                _cache[14] ||
                                    (_cache[14] = [
                                        createStaticVNode(
                                            '<span class="action-icon" data-v-f0c1c6d7><svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-f0c1c6d7><path d="M10.0505 3.35968C9.78979 3.55315 9.51173 4.02802 9.39008 4.43255C8.99036 5.9627 9.72028 7.21145 11.0411 7.21145C11.4234 7.21145 11.9448 7.10592 12.1881 6.9828C12.6573 6.75416 12.8485 6.1034 12.553 5.75164C12.4662 5.62853 12.3966 5.17124 12.414 4.71395C12.4488 4.0632 12.3619 3.79938 12.0317 3.44762C11.5103 2.8848 10.6761 2.84963 10.0505 3.35968Z" data-v-f0c1c6d7></path><path d="M6.36614 4.16873C5.81001 4.32702 4.40232 5.62853 4.21115 6.20893C3.82881 7.26421 3.96784 8.07326 4.61087 8.72402C5.27127 9.39236 5.60147 9.44512 6.66158 9.0406C7.87811 8.56572 8.01714 8.3019 8.01714 6.4024C8.01714 4.97778 7.965 4.69637 7.66956 4.39737C7.32198 4.04561 7.04392 4.01044 6.36614 4.16873Z" data-v-f0c1c6d7></path><path d="M13.9086 5.25918C12.8311 6.34964 13.5263 8.44261 14.9687 8.44261C15.3684 8.44261 15.6986 8.26673 16.1157 7.84462C16.6023 7.35215 16.7066 7.12351 16.7066 6.47275C16.6892 5.66371 16.4981 5.27677 15.8898 4.96019C15.212 4.59084 14.4647 4.71396 13.9086 5.25918Z" data-v-f0c1c6d7></path><path d="M9.99834 8.42502C9.11202 8.82954 7.77384 10.3597 7.20033 11.5909C6.80061 12.4351 6.76586 12.6813 6.87013 13.8421C6.99178 15.3547 7.16557 15.7416 8.45161 17.1487C9.33794 18.1336 9.45959 18.2039 10.2243 18.2391C10.6935 18.2743 11.4234 18.3271 11.8753 18.3974C12.5357 18.4853 12.8137 18.4326 13.283 18.1336C13.8217 17.7994 14.6559 16.7793 15.1425 15.8296C15.438 15.2667 15.8724 12.8572 15.9072 11.5733C15.9246 10.7115 15.855 10.5004 15.3858 9.90241C15.0904 9.53306 14.3605 8.97025 13.7696 8.65366C12.4662 7.98532 11.1454 7.89738 9.99834 8.42502Z" data-v-f0c1c6d7></path><path d="M19.0702 13.7014C18.3055 13.8597 17.8536 14.5984 17.8536 15.724C17.8362 16.4979 17.9231 16.7617 18.2533 17.1311C19.522 18.4853 21.0514 17.4301 21.0514 15.1788C21.0514 14.2466 20.9992 14.0532 20.669 13.8245C20.2693 13.5255 19.9217 13.5079 19.0702 13.7014Z" data-v-f0c1c6d7></path><path d="M22.5633 15.9703C21.3468 17.3245 21.9898 19.3472 23.6234 19.3472C25.1354 19.3472 25.8306 17.2542 24.6836 16.1637C24.0405 15.5657 23.0152 15.4602 22.5633 15.9703Z" data-v-f0c1c6d7></path><path d="M17.4713 18.8019C17.0021 19.013 16.5328 19.4351 16.1679 19.9803L15.577 20.8421L15.6117 23.621C15.6639 26.611 15.7508 26.9628 16.6545 27.8246C17.871 28.9854 19.7827 29.3371 21.1904 28.6512C21.9724 28.2643 22.4764 27.6311 22.8066 26.5582C22.9109 26.2241 23.189 25.6788 23.4323 25.3622C24.3534 24.1311 24.6314 22.4602 24.1101 21.2291C23.7277 20.2969 22.5459 19.2065 21.7987 19.0833C21.4337 19.013 20.7733 18.8547 20.3214 18.714C19.2266 18.3798 18.3229 18.415 17.4713 18.8019Z" data-v-f0c1c6d7></path><path d="M25.2918 19.7693C24.3534 20.719 24.4924 22.1085 25.5699 22.4954C26.265 22.7416 27.0123 22.5658 27.5685 22.0557C28.1767 21.4929 28.142 20.719 27.4642 19.8572C26.7517 18.9602 26.126 18.925 25.2918 19.7693Z" data-v-f0c1c6d7></path></svg></span><span class="action-title" data-v-f0c1c6d7> Scroll </span>',
                                            2,
                                        ),
                                    ]),
                                10,
                                _hoisted_10,
                            ),
                            createBaseVNode(
                                "button",
                                {
                                    class: normalizeClass([
                                        "action",
                                        {
                                            "action-active":
                                                unref(panelStore)
                                                    .isDualSubtitles,
                                        },
                                    ]),
                                    onClick:
                                        _cache[3] ||
                                        (_cache[3] = (...args) =>
                                            unref(panelStore)
                                                .toggleShowTranslate &&
                                            unref(
                                                panelStore,
                                            ).toggleShowTranslate(...args)),
                                    disabled:
                                        unref(subtitlesStore).subtitles
                                            .length === 0,
                                },
                                _cache[15] ||
                                    (_cache[15] = [
                                        createStaticVNode(
                                            '<span class="action-icon" data-v-f0c1c6d7><svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-f0c1c6d7><path d="M10.5953 4.77723C10.2679 5.03847 9.98736 5.53019 9.53533 6.71342C9.47298 6.88245 9.34828 7.29735 9.28593 7.63541C9.06771 8.57277 8.55333 8.78791 6.33993 8.84937C4.62533 8.89547 4.48504 8.9262 3.87714 9.3411C3.09777 9.8943 2.91072 10.1709 3.03542 10.6626C3.20688 11.2773 4.31358 11.7229 6.15288 11.8766C8.44421 12.061 10.5329 12.3376 10.6732 12.4759C10.7511 12.5373 10.6264 12.9522 10.3926 13.3979C10.0653 14.0279 9.94059 14.1508 9.76913 14.0125C9.36386 13.6745 8.53774 13.5362 8.08571 13.7206C7.75837 13.8589 7.6025 13.8589 7.46221 13.7206C7.18164 13.444 6.44904 13.5208 6.10612 13.8589C5.62291 14.3352 5.70085 14.996 6.35552 15.7029C6.66726 16.0409 6.90107 16.3483 6.85431 16.3944C6.82314 16.4251 6.51139 16.548 6.18406 16.6556C5.70085 16.8093 5.48263 16.9936 5.20206 17.5468C4.99942 17.931 4.70326 18.4381 4.51622 18.684C4.28241 19.0067 4.22006 19.2679 4.28241 19.7289C4.37593 20.4665 4.71885 20.8507 5.43587 21.0965C5.90348 21.2502 6.07495 21.2041 7.08812 20.7277C7.71161 20.4358 8.63126 19.9594 9.14564 19.6521L10.0809 19.1142L10.5173 19.483C10.7667 19.6828 11.1096 19.8518 11.2811 19.8518C11.4526 19.8518 11.8734 20.0823 12.2319 20.3743C13.666 21.5114 14.2271 21.5268 15.3026 20.4972C16.2067 19.6213 16.4561 19.0989 16.2223 18.4996C15.9729 17.8542 15.4741 17.4085 14.3362 16.84L13.2763 16.3175L13.9933 15.2726C14.383 14.704 14.8194 13.8435 14.9597 13.3364C15.2091 12.4912 15.287 12.399 16.2067 11.8151C17.4069 11.0622 17.594 10.6934 17.1731 9.86357C17.0016 9.54087 16.7834 9.21817 16.6743 9.1567C16.4093 9.00304 14.4141 8.64961 13.7127 8.64961L13.1204 8.63424V7.46638C13.1204 6.17559 13.0581 6.02193 12.2475 5.1153C11.5928 4.40844 11.1876 4.3316 10.5953 4.77723Z" data-v-f0c1c6d7></path><path d="M20.6802 14.243C20.4308 14.4735 20.2906 14.7962 20.2906 15.0882C20.2906 15.3648 20.0723 15.8873 19.745 16.379C19.4333 16.8246 18.6383 18.5303 17.9525 20.1745C17.2822 21.8187 16.5496 23.5705 16.3314 24.0776C15.7702 25.3684 15.7702 26.7668 16.3002 27.197C16.8458 27.6119 19.293 27.5812 19.6203 27.1509C19.7294 26.9819 19.8229 26.7821 19.8229 26.6746C19.8229 26.567 19.9632 26.1829 20.1191 25.7987L20.4153 25.1226L21.9584 25.0304C22.8001 24.9689 23.7042 24.8921 23.9847 24.8306C24.468 24.7384 24.4991 24.7691 25.0291 25.8141C25.6526 27.028 25.6994 27.0741 26.5878 27.2585C28.1154 27.5966 28.2089 27.5966 28.6298 27.1509C29.3624 26.3519 29.0818 25.2455 27.1178 21.2348C26.5878 20.1745 26.0423 18.8223 25.8864 18.2076C25.5435 16.8707 25.185 16.1485 24.4212 15.2726C23.9536 14.7501 23.7509 14.6118 23.408 14.6579C23.1274 14.6733 22.8157 14.5504 22.4884 14.2738C21.8493 13.7513 21.179 13.7359 20.6802 14.243ZM22.5663 21.4192C22.7066 21.8648 22.8313 22.2644 22.8157 22.3105C22.7689 22.4488 21.6934 22.4795 21.6934 22.3412C21.6934 22.1414 22.161 20.6202 22.239 20.6202C22.2701 20.6202 22.4104 20.989 22.5663 21.4192Z" data-v-f0c1c6d7></path></svg></span><span class="action-title" data-v-f0c1c6d7> Translate </span>',
                                            2,
                                        ),
                                    ]),
                                10,
                                _hoisted_11,
                            ),
                            createBaseVNode(
                                "button",
                                {
                                    class: normalizeClass([
                                        "action",
                                        {
                                            "action-active":
                                                unref(panelStore)
                                                    .isDualSubtitles,
                                        },
                                    ]),
                                    onClick:
                                        _cache[4] ||
                                        (_cache[4] = (...args) =>
                                            unref(panelStore)
                                                .cycleDisplayMode &&
                                            unref(panelStore).cycleDisplayMode(
                                                ...args,
                                            )),
                                    disabled:
                                        unref(subtitlesStore).subtitles
                                            .length === 0 ||
                                        !unref(panelStore).isDualSubtitles,
                                },
                                [
                                    createBaseVNode("span", _hoisted_13, [
                                        unref(panelStore).displayMode ===
                                        "original-translate"
                                            ? (openBlock(),
                                              createElementBlock(
                                                  "svg",
                                                  _hoisted_14,
                                                  _cache[16] ||
                                                      (_cache[16] = [
                                                          createStaticVNode(
                                                              '<path d="M8.46322 0.186638C8.16534 0.326923 7.8149 0.607494 7.70977 0.817921C7.53455 1.1511 7.55207 1.29138 7.86747 1.71224C8.37561 2.41366 8.41066 4.39519 7.90251 4.67576C7.41189 4.9388 7.35932 4.90372 7.3418 4.36012C7.3418 3.65869 6.64091 1.95774 6.0802 1.25631C5.2917 0.256781 3.81984 0.0638887 2.38302 0.747779C1.31416 1.27385 1.1039 1.85252 0.753454 5.39472C0.648321 6.60468 0.928676 7.28857 1.99753 8.34071C2.94373 9.2701 3.69718 9.42792 4.76604 8.90185C5.67719 8.46346 6.88622 7.30611 7.1841 6.58715C7.35932 6.18383 7.44693 6.11368 7.63968 6.2715C7.83242 6.42933 7.86747 6.7099 7.77986 7.30611C7.69225 8.00753 7.72729 8.20042 8.04269 8.51607C8.23543 8.70896 8.55083 8.88431 8.72605 8.88431C9.14659 8.88431 9.63721 8.34071 9.63721 7.90232C9.63721 7.72696 9.68978 7.39379 9.74234 7.16582C9.84748 6.81511 9.93509 6.78004 10.4082 6.86772C10.7061 6.93786 11.5997 7.34118 12.3882 7.76203C14.228 8.76156 15.2443 8.76156 15.2443 7.76203C15.2443 7.44639 15.2618 7.44639 15.5597 7.70943C16.541 8.60374 17.8026 7.41132 17.1542 6.20136C17.0316 6.00847 16.8914 4.90372 16.8038 3.74637C16.6461 1.53688 16.4008 0.817921 15.77 0.817921C15.0516 0.817921 14.8238 1.58949 14.8063 3.86912C14.8063 5.04401 14.8763 6.25397 14.964 6.58715L15.1041 7.18336L14.5259 6.72743C14.193 6.49947 13.4746 6.04354 12.9314 5.7279C11.9151 5.16676 11.7574 4.97387 12.1078 4.7459C12.213 4.6933 12.4583 4.27244 12.651 3.85159C13.1241 2.78191 12.9664 2.08049 12.0903 1.27385C10.8112 0.116496 9.49703 -0.269289 8.46322 0.186638ZM10.9864 2.86959C11.0215 2.9748 10.8638 3.29045 10.6185 3.55348L10.1804 4.06201L10.1629 3.11509C10.1629 2.1857 10.1629 2.1857 10.5484 2.4312C10.7586 2.57148 10.9514 2.76438 10.9864 2.86959ZM4.76604 3.39566C4.9763 3.86912 5.16905 4.58808 5.22162 5.04401C5.2917 5.78051 5.25666 5.86818 4.6609 6.39425C4.31046 6.70989 3.92497 6.95539 3.80232 6.95539C3.39931 6.93786 2.89116 6.00847 2.90868 5.34212C2.94373 4.57055 3.29417 3.11509 3.55701 2.78191C3.92497 2.30845 4.39807 2.55395 4.76604 3.39566Z" data-v-f0c1c6d7></path><path d="M19.4847 1.25631C18.521 2.11556 17.6449 4.09709 17.5572 5.57008C17.4872 6.58715 17.5397 6.7625 17.9427 7.2535C18.5385 7.95493 19.8877 8.51607 21.2895 8.65635C22.0254 8.7265 22.5686 8.88432 22.8139 9.07721C23.8127 9.95399 24.864 8.76157 24.5836 7.06061C24.5311 6.67483 24.6187 6.25397 24.864 5.76297C26.0205 3.50088 24.3559 2.51888 21.1493 3.55348C20.2031 3.86912 19.8877 4.4478 20.3958 5.00894C20.6412 5.28951 20.8689 5.32458 21.7275 5.25444L22.7613 5.14923L22.5335 5.92079C22.2532 6.86772 21.9728 6.93786 20.6236 6.42933C19.73 6.09615 19.6249 6.00847 19.6249 5.55255C19.6249 4.88619 20.2381 3.25538 20.6937 2.65917C20.9916 2.29092 21.1843 2.22077 21.745 2.25585C23.0767 2.32599 23.1118 1.55442 21.7976 0.99328C20.6762 0.502282 20.2557 0.554889 19.4847 1.25631Z" data-v-f0c1c6d7></path><path d="M26.3534 1.01082C26.0555 1.34399 26.0205 1.67717 26.0205 4.21984C26.0205 7.21843 26.1081 7.58668 26.8966 8.11275C27.3872 8.42839 27.9654 8.21796 28.1932 7.60421C28.2808 7.39379 28.2984 5.90326 28.2283 4.30751C28.1407 1.76485 28.0706 1.32646 27.7902 1.01082C27.3697 0.537353 26.7739 0.537353 26.3534 1.01082Z" data-v-f0c1c6d7></path><path d="M38.321 1.02835C38.1458 1.16864 37.9356 1.79992 37.7779 2.60656C37.6377 3.36059 37.3223 4.53548 37.077 5.20183C36.8141 5.88572 36.6214 6.7099 36.6039 7.00801C36.5863 7.55161 36.5688 7.53407 36.3235 6.78004C36.1308 6.18383 36.0957 5.46487 36.1658 3.76391C36.2534 1.53689 36.2534 1.51935 35.8329 1.23878C35.3072 0.888068 34.7816 1.04589 34.3786 1.65964C34.1332 2.02788 34.0807 2.53642 34.0807 4.46534V6.81511L33.6251 6.25397C33.3623 5.95587 32.6439 4.72837 31.9955 3.53595C31.1194 1.8876 30.7339 1.36153 30.4185 1.27385C29.9805 1.16864 29.4373 1.29139 29.4198 1.50182C29.3497 2.36106 29.4198 7.67436 29.5074 7.95493C29.5775 8.18289 29.8403 8.41086 30.0856 8.46346C30.4536 8.56868 30.6288 8.481 30.9617 8.11275C31.1895 7.84972 31.3647 7.4464 31.3647 7.2009C31.3647 6.78004 31.3823 6.78004 31.9079 7.39379C32.5738 8.14782 33.6251 8.77911 34.6764 9.05968C35.6577 9.32271 36.1483 9.18242 36.4111 8.62128C36.6039 8.20043 36.6564 8.18289 36.9017 8.42839C37.4449 8.98953 38.3736 8.67389 38.6364 7.83218C38.7241 7.53407 38.8642 7.499 39.6177 7.55161C40.3711 7.60422 40.5288 7.6919 40.8793 8.20043C41.3524 8.91939 42.2635 9.11228 42.5965 8.56868C42.7892 8.25304 42.8067 8.25304 43.1747 8.62128C43.5251 8.972 43.8055 9.00707 46.3988 9.11228C47.9583 9.18242 49.36 9.18242 49.5177 9.11228C49.9383 8.95446 50.131 8.25304 49.9032 7.76204C49.6404 7.14829 49.0096 6.9554 46.977 6.81511L45.2073 6.69236L45.1372 4.67577C45.0671 2.51888 44.8393 1.62456 44.3136 1.32646C43.8756 1.0985 43.3499 1.37907 43.2273 1.90513C43.1747 2.1331 43.0871 3.09756 43.017 4.06202C42.9644 5.02648 42.8768 6.16629 42.8243 6.60469L42.7191 7.39379L42.2986 6.30658C41.5627 4.32505 40.1258 1.71224 39.5126 1.25632C38.8818 0.765318 38.7241 0.730247 38.321 1.02835ZM39.6703 5.76298C39.5126 6.00847 39.2497 5.7279 39.2497 5.32458C39.2672 4.95634 39.2672 4.95634 39.5126 5.27198C39.6527 5.44733 39.7228 5.6753 39.6703 5.76298Z" data-v-f0c1c6d7></path><path d="M36.6214 12.3914C34.0632 12.4616 26.6688 12.5668 20.1856 12.6369C7.25419 12.7597 7.6572 12.7246 7.09649 13.8118C6.53578 14.8815 7.28923 16.0213 8.81366 16.4422C9.56712 16.6526 31.4874 16.5299 38.8467 16.2844C42.1759 16.1616 42.2285 16.1616 42.6841 15.7057C43.6828 14.7061 43.3324 13.0052 42.0182 12.4791C41.6503 12.3388 41.3349 12.2336 41.2998 12.2512C41.2823 12.2512 39.1796 12.3213 36.6214 12.3914Z" data-v-f0c1c6d7></path><path d="M8.06021 19.6161C5.46693 19.7564 1.43682 20.5104 0.630799 21.0014C0.140178 21.282 0 21.4749 0 21.8782C0 22.5797 0.648321 22.8427 1.69965 22.5797C2.69842 22.3166 3.50444 22.3342 3.52196 22.5972C3.66214 25.473 3.81984 26.6128 4.11772 26.946C4.5032 27.3669 5.02887 27.402 5.58958 27.0162C5.99259 26.7356 5.99259 26.6655 5.88746 25.0346C5.81737 24.1053 5.71224 23.0706 5.65967 22.7199C5.55454 22.001 5.58958 21.9834 7.0264 21.773L7.83242 21.6678L7.92003 23.6493C7.9726 24.7365 8.11278 25.8413 8.21791 26.1219C8.55083 26.9811 9.72482 27.0512 9.93509 26.2271C10.0402 25.8237 9.97013 25.8237 11.039 26.2446C11.5296 26.4375 12.0903 26.5953 12.2831 26.5953C12.4758 26.5953 12.8262 26.7181 13.054 26.8759C13.8776 27.4195 14.8939 26.6655 14.8939 25.5081C14.8939 24.8593 15.1041 24.719 15.8926 24.8067C16.5585 24.8768 16.6811 24.9645 17.0841 25.6484C17.5572 26.455 17.9778 26.7707 18.5385 26.7707C18.7312 26.7707 18.9765 26.8934 19.0992 27.0337C19.3796 27.3844 20.2206 27.3669 20.5711 27.0162C20.7463 26.8583 20.8514 26.42 20.8689 25.929C20.8689 25.473 20.939 24.7541 20.9916 24.3157L21.1142 23.5266L21.7801 24.6138C22.9891 26.5953 24.1281 27.2266 25.0042 26.3849C25.3546 26.0692 25.4072 26.0517 25.4072 26.2972C25.4072 26.7181 26.4235 27.2967 27.1594 27.2967C27.9129 27.2967 29.1044 26.7707 29.6826 26.192C30.1557 25.7185 30.3134 25.7536 30.3134 26.2797C30.3134 26.4726 30.5412 26.8583 30.8391 27.1389L31.3472 27.665L33.4674 27.5948C34.6764 27.5422 35.6752 27.437 35.8154 27.3143C35.938 27.2091 36.0957 26.8759 36.1483 26.5953C36.2534 26.1218 36.3235 26.0868 37.1821 26.0342C38.0056 25.9816 38.1633 26.0342 38.5839 26.455C39.4074 27.3318 40.6165 26.9811 40.4237 25.9465C40.231 24.8944 39.2322 22.492 38.7065 21.7905C38.0407 20.9313 36.9718 20.0896 36.1132 19.7564C35.5701 19.5284 35.5 19.546 35.2196 19.8967C35.0444 20.0896 34.8692 20.7384 34.7991 21.3697C34.6764 22.492 34.0982 25.1399 33.9405 25.2977C33.9055 25.3503 33.5725 25.438 33.2046 25.4906C32.346 25.6309 32.2408 25.438 32.2408 23.5792C32.2408 22.001 31.978 20.3526 31.6801 19.9668C31.575 19.8616 31.3122 19.7564 31.0669 19.7564C30.5061 19.7564 30.1382 20.6332 30.1382 21.9484C30.1382 22.4744 30.1031 22.9128 30.0506 22.9128C29.9805 22.9128 29.7001 22.7901 29.3847 22.6323C29.0868 22.4744 28.3159 22.1588 27.6851 21.9308L26.5461 21.5275H27.5624C28.1056 21.51 28.5612 21.5801 28.5612 21.6678C28.5612 21.8782 29.0343 22.0536 29.3322 21.9308C29.4723 21.8782 29.6125 21.7029 29.6651 21.5275C30.0155 20.1597 27.615 19.1953 25.3546 19.8266C24.3909 20.0896 24.2858 20.1071 24.1456 19.8616C24.058 19.7038 23.7601 19.5811 23.4797 19.5811C22.8665 19.5811 22.4284 20.2649 22.4284 21.1943V21.773L21.5348 20.7559C20.7813 19.9142 20.5535 19.7564 20.0629 19.7564C19.1868 19.7564 19.0291 20.1948 18.924 22.6498L18.8364 24.7541L18.4158 23.5266C17.8201 21.7555 17.2769 20.7384 16.6286 20.1948C16.1379 19.7915 15.9452 19.7389 15.367 19.8266C14.9815 19.8967 14.596 19.9844 14.5084 20.037C14.2806 20.1773 13.9652 21.0716 13.422 23.0005C13.1416 23.965 12.9139 24.7716 12.8788 24.8067C12.8438 24.8593 11.3719 24.3157 11.2317 24.1929C11.1792 24.1579 11.3544 23.9124 11.6172 23.6493C12.3181 22.9128 12.4933 22.2815 12.2655 21.3171C12.0377 20.3526 11.4946 19.7739 10.6535 19.5986C10.3381 19.546 9.16411 19.546 8.06021 19.6161ZM10.4783 21.7905C10.5308 22.1062 9.90004 22.8953 9.74234 22.7199C9.7073 22.6849 9.63721 22.3517 9.58464 21.9834C9.47951 21.3346 9.49703 21.3171 9.95261 21.3697C10.268 21.4048 10.4432 21.545 10.4783 21.7905ZM15.9452 22.8602C15.9452 22.983 15.8401 23.0882 15.6999 23.0882C15.5422 23.0882 15.4896 22.9479 15.5597 22.6323C15.6123 22.2991 15.6824 22.2465 15.7875 22.4218C15.8751 22.5446 15.9452 22.755 15.9452 22.8602ZM37.2347 23.4389C37.6026 24.1754 37.5676 24.3157 36.9718 24.3157C36.4812 24.3157 36.4462 24.2806 36.5513 23.8247C36.7791 22.7199 36.8492 22.6849 37.2347 23.4389ZM28.5086 24.4384C28.5437 24.5436 28.3684 24.7716 28.1231 24.947C27.6851 25.2275 27.65 25.2275 27.4047 24.8593C27.0543 24.3508 26.3709 24.3858 25.8102 24.947C25.5649 25.1925 25.3546 25.3678 25.3371 25.3327C25.2845 25.2451 24.7063 23.3337 24.7063 23.2285C24.7063 23.0356 28.4385 24.228 28.5086 24.4384Z" data-v-f0c1c6d7></path><path d="M39.9156 20.037C39.5476 20.2299 39.4249 20.4228 39.4249 20.8086C39.4249 21.3697 39.8104 21.6853 40.5288 21.6853C40.9319 21.6853 40.9319 21.7379 40.9494 23.0531C40.9669 25.929 42.2285 28.1209 43.4901 27.4546C43.8756 27.2441 43.8756 26.8233 43.4025 24.9294C43.2623 24.3508 43.0871 23.3863 43.017 22.7725L42.9119 21.6853H44.5064V24.0526C44.5064 26.7005 44.6641 27.2792 45.5577 27.7351C46.9069 28.4366 49.4126 27.6475 49.4126 26.5076C49.4126 25.8939 49.0622 25.7185 47.783 25.7185C46.7492 25.7185 46.5915 25.6835 46.6441 25.4204C46.6791 25.21 47.0121 25.0522 47.748 24.9119C48.8694 24.6839 49.4126 24.228 49.4126 23.5266C49.4126 23.2986 49.3075 23.0005 49.1673 22.8602C48.9395 22.6498 48.957 22.5797 49.3425 22.4218C50.1836 22.036 49.6579 21.0365 48.3963 20.6157C48.0283 20.4929 47.2924 20.4578 46.574 20.5104C45.8381 20.5806 45.3825 20.5455 45.3825 20.4403C45.3825 19.7915 40.9669 19.4583 39.9156 20.037ZM48.3613 22.5621C48.3613 22.6323 48.0634 22.7375 47.7129 22.7901C47.345 22.8427 46.9244 22.9304 46.7667 23.0005C46.574 23.0706 46.4513 23.0005 46.3813 22.755C46.3462 22.5621 46.3287 22.3868 46.3462 22.3517C46.4689 22.2289 48.3613 22.4218 48.3613 22.5621Z" data-v-f0c1c6d7></path>',
                                                              7,
                                                          ),
                                                      ]),
                                              ))
                                            : createCommentVNode("", true),
                                        unref(panelStore).displayMode ===
                                        "translate-original"
                                            ? (openBlock(),
                                              createElementBlock(
                                                  "svg",
                                                  _hoisted_15,
                                                  _cache[17] ||
                                                      (_cache[17] = [
                                                          createStaticVNode(
                                                              '<path d="M8.02925 0.544902C5.64225 0.687698 1.61203 1.40168 0.799071 1.84792C-0.169566 2.36556 -0.273348 3.18664 0.574209 3.56148C0.902853 3.70427 1.17961 3.70427 1.52555 3.56148C1.785 3.47223 2.33851 3.38298 2.73634 3.38298H3.48012L3.6012 4.31116C3.65309 4.82879 3.70498 5.66772 3.70498 6.18536C3.70498 7.77397 4.24119 8.5415 5.19253 8.30946C5.90171 8.11311 6.00549 7.66687 5.79793 5.29288C5.69414 4.11481 5.65955 3.07954 5.72874 3.00814C5.81522 2.93674 6.29954 2.82964 6.83575 2.7761L7.80439 2.65115L7.89087 4.77525C7.97736 7.29203 8.21952 7.89892 9.10167 7.80967C9.55139 7.77397 9.82814 7.52408 10.0357 6.98859C10.053 6.97074 10.4681 7.09569 10.9525 7.30988C11.4368 7.50623 12.0076 7.66687 12.1978 7.66687C12.3881 7.66687 12.7341 7.79182 12.9589 7.95247C13.2011 8.11311 13.5643 8.20236 13.7892 8.14881C14.2735 8.00602 14.7751 7.14924 14.7751 6.4531C14.7751 5.77482 14.8789 5.70342 15.7783 5.82837C16.401 5.91762 16.5567 6.02472 16.9372 6.703C17.4043 7.52408 17.8194 7.84537 18.3729 7.84537C18.5632 7.84537 18.8053 7.97032 18.9264 8.11311C19.0475 8.25591 19.3588 8.38086 19.6356 8.38086C20.3621 8.38086 20.6215 7.82752 20.6907 6.11396C20.7253 5.29288 20.7945 4.63245 20.8637 4.63245C20.9156 4.63245 21.2096 5.06084 21.5037 5.59633C22.1783 6.79225 23.268 7.84537 23.8561 7.84537C24.0982 7.84537 24.4442 7.68472 24.6344 7.48838C25.0496 7.05999 25.1534 7.04214 25.1534 7.39913C25.1534 7.75612 26.1566 8.38086 26.7101 8.38086C27.5404 8.38086 28.4744 7.98817 29.1317 7.38128L29.789 6.75655L29.9965 7.38128C30.1003 7.73827 30.3944 8.18451 30.6538 8.39871C31.069 8.73785 31.2592 8.7557 32.4181 8.66645C33.8019 8.5415 33.8711 8.5415 34.684 8.59505C35.2894 8.63075 35.7046 8.20236 35.7046 7.55978C35.7046 7.20279 35.8084 7.14924 36.7078 7.09569C37.6073 7.04214 37.7283 7.07784 38.1608 7.52408C38.4202 7.80967 38.8008 8.02387 39.0429 8.02387C39.4926 8.02387 40.0288 7.61333 40.0288 7.27418C40.0288 6.98859 39.0256 4.16836 38.6624 3.41868C38.2126 2.5262 36.6386 1.04469 35.8084 0.741247C34.9089 0.402105 34.5803 0.741247 34.4419 2.09781C34.39 2.65115 34.1651 3.84707 33.9749 4.7574L33.6116 6.38171L32.937 6.50665C32.5565 6.57805 32.1933 6.57805 32.1068 6.5245C32.0203 6.47095 31.9165 5.43568 31.8646 4.23976C31.7435 1.54448 31.4668 0.651999 30.7403 0.741247C30.1003 0.812645 29.8236 1.41953 29.8236 2.79395C29.8236 3.41868 29.789 3.91847 29.7371 3.91847C29.6852 3.91847 29.3565 3.77567 28.9933 3.57933C28.6474 3.40083 27.9036 3.09739 27.3501 2.91889C26.7274 2.72255 26.416 2.54405 26.5198 2.43695C26.7101 2.24061 28.2668 2.43695 28.2668 2.669C28.2668 2.91889 28.8203 3.04384 29.0625 2.82964C29.443 2.50835 29.3565 1.70512 28.8895 1.25888C28.2322 0.634149 26.5198 0.384255 25.1361 0.741247C24.1847 0.99114 23.9945 0.99114 23.7523 0.776946C23.4064 0.455654 22.8355 0.455654 22.5588 0.776946C22.455 0.919742 22.2993 1.41953 22.2474 1.86577L22.1264 2.68685L21.2961 1.70512C20.6042 0.866194 20.3794 0.705548 19.895 0.705548C18.9783 0.705548 18.8572 1.02684 18.7534 3.54363L18.667 5.79267L18.2518 4.5432C17.6637 2.7404 17.1275 1.70512 16.4875 1.15179C16.0032 0.741247 15.8129 0.687698 15.2248 0.776946C14.827 0.848344 14.3946 1.04469 14.2389 1.20534C14.0832 1.36598 13.7373 2.31201 13.4778 3.29373C12.7341 6.09611 12.8551 5.91762 11.973 5.56063C11.5579 5.41783 11.1946 5.25718 11.16 5.22149C11.1254 5.20364 11.333 4.90019 11.6443 4.5432C12.0941 4.00772 12.1805 3.75782 12.1805 3.00814C12.1805 2.09781 11.9038 1.31243 11.4368 0.901893C10.9698 0.509202 10.2087 0.437804 8.02925 0.544902ZM10.4162 2.7761C10.4681 3.13309 9.84544 3.90062 9.67247 3.70427C9.62058 3.65072 9.5168 3.31158 9.46491 2.93674C9.36112 2.29416 9.37842 2.27631 9.86274 2.34771C10.2087 2.38341 10.3817 2.50835 10.4162 2.7761ZM15.8129 3.86492C15.8129 3.98987 15.6919 4.09696 15.5535 4.09696C15.2767 4.09696 15.2248 3.93632 15.3978 3.47223C15.4843 3.24018 15.5362 3.22233 15.6573 3.41868C15.7437 3.54363 15.8129 3.75782 15.8129 3.86492ZM36.8289 4.45395C37.2094 5.20364 37.1575 5.34643 36.5521 5.34643C36.0678 5.34643 36.0159 5.29288 36.1197 4.93589C36.1716 4.7217 36.2235 4.40041 36.2235 4.22191C36.2235 3.75782 36.5348 3.86492 36.8289 4.45395ZM26.6063 4.77525C27.4539 5.04299 28.1803 5.34643 28.2149 5.47138C28.2495 5.57848 28.0766 5.82837 27.8171 6.00687C27.3674 6.31031 27.3501 6.31031 27.0906 5.91762C26.7447 5.38213 26.0182 5.39998 25.4993 5.97117L25.1015 6.41741L24.7728 5.48923C24.375 4.29331 24.375 4.02556 24.7728 4.18621C24.9285 4.25761 25.7588 4.52535 26.6063 4.77525Z" data-v-f0c1c6d7></path><path d="M39.5618 0.884043C39.0256 1.11609 38.7662 1.68727 38.991 2.13351C39.0948 2.32986 39.2505 2.50835 39.337 2.50835C39.4407 2.5262 39.5964 2.5619 39.6829 2.57975C39.7867 2.5976 39.9943 2.6333 40.1672 2.65115C40.4267 2.669 40.4613 2.88319 40.4786 4.23976C40.5132 6.20321 41.0321 7.72042 41.8969 8.30946C42.9866 9.07699 43.5574 8.36301 43.0731 6.82794C42.8137 5.98902 42.4677 3.88277 42.4504 3.06169C42.4504 2.7047 42.5369 2.669 43.2288 2.669H44.0072L43.9726 5.02514C43.9207 7.73827 44.111 8.36301 45.1142 8.86279C46.2904 9.43398 48.6774 8.6843 48.8158 7.70257C48.9195 6.98859 48.5736 6.7744 47.259 6.7744C46.2039 6.7744 46.0655 6.7387 46.1174 6.47095C46.152 6.29246 46.325 6.13181 46.5153 6.09611C48.1066 5.81052 48.8504 5.32858 48.8504 4.56105C48.8504 4.31116 48.6774 3.98987 48.4698 3.84707C48.1931 3.63287 48.1585 3.56148 48.3487 3.56148C48.5044 3.56148 48.7639 3.40083 48.9541 3.18664C49.3347 2.75825 49.179 2.4191 48.3141 1.79437C47.7779 1.41953 47.5877 1.38383 46.3077 1.47308C45.512 1.52663 44.872 1.49093 44.872 1.41953C44.872 1.34813 44.6126 1.15179 44.2839 0.991141C43.6266 0.669849 40.2537 0.59845 39.5618 0.884043ZM47.4493 3.38298C48.0547 3.38298 47.7606 3.59718 46.8093 3.84707C45.9617 4.07911 45.7542 3.97202 45.7369 3.40083C45.7369 3.22233 45.8926 3.18664 46.3942 3.27588C46.7401 3.32943 47.2244 3.38298 47.4493 3.38298Z" data-v-f0c1c6d7></path><path d="M31.6398 12.4863C28.4052 12.5755 21.8496 12.6826 17.0756 12.7183C9.62058 12.8075 8.3233 12.8611 7.87358 13.0931C7.23358 13.4501 6.99142 13.8785 6.99142 14.7174C6.99142 15.5564 7.59682 16.1454 8.87681 16.5381C9.74166 16.788 11.0389 16.8058 21.521 16.6987C27.9382 16.6452 35.0992 16.5381 37.417 16.4667L41.6375 16.3596L42.1391 15.8955C43.0904 15.003 43.0558 13.5394 42.0526 12.7718C41.4472 12.3078 40.3402 12.2899 31.6398 12.4863Z" data-v-f0c1c6d7></path><path d="M9.06707 20.108C8.68654 20.2508 8.02925 20.9112 8.02925 21.1433C8.02925 21.2682 8.18492 21.5717 8.37519 21.8216C8.84221 22.4463 8.85951 24.2491 8.40978 24.6775C7.97736 25.088 7.85628 25.0523 7.85628 24.5347C7.85628 23.8564 7.06061 21.7859 6.61089 21.2861C5.76333 20.3222 4.34497 20.0902 3.06499 20.6792C1.85419 21.2504 1.69852 21.6966 1.35258 25.3736C1.24879 26.4446 1.28339 26.641 1.68122 27.3549C2.25202 28.3545 3.16877 29.1934 3.87795 29.3541C4.98496 29.604 7.25088 27.9618 7.7179 26.5696C7.85628 26.1233 7.94276 26.0698 8.15033 26.2661C8.3406 26.4268 8.37519 26.6766 8.306 27.1586C8.15033 28.1046 8.3233 28.6401 8.84221 28.89C9.4822 29.1934 10.1049 28.7472 10.1049 27.9618C10.1049 27.6584 10.1741 27.2835 10.2606 27.1407C10.5027 26.7659 11.4541 27.0336 12.7686 27.8547C14.1524 28.7115 14.9308 28.89 15.3459 28.4616C15.5016 28.301 15.64 28.0511 15.64 27.9261C15.64 27.7298 15.7437 27.7298 16.1589 27.9797C16.6259 28.2474 16.7124 28.2653 17.1448 28.0154C17.7502 27.6584 17.8194 27.3014 17.4907 26.159C17.3351 25.6592 17.1794 24.4098 17.1275 23.3923C17.0064 21.4467 16.7989 20.8755 16.1589 20.8755C15.4843 20.8755 15.2594 21.4824 15.1556 23.5887C15.121 24.7846 15.1556 25.8913 15.2767 26.3018C15.3805 26.6945 15.4324 27.0515 15.3805 27.0872C15.3459 27.1229 15.0519 26.9622 14.7405 26.7123C14.4292 26.4803 13.7892 26.0519 13.3049 25.7842C12.8378 25.4986 12.4227 25.2487 12.3881 25.2308C12.3535 25.213 12.5438 24.856 12.8032 24.4633C13.1146 23.9457 13.2703 23.4637 13.2876 22.9282C13.3049 22.25 13.2184 22.0536 12.613 21.411C11.506 20.2508 10.0876 19.7153 9.06707 20.108ZM11.2119 22.6426C11.506 22.9818 11.506 23.0175 11.1946 23.4459C10.7449 24.0885 10.6238 24.0171 10.6238 23.1067C10.6238 22.2321 10.7622 22.125 11.2119 22.6426ZM5.03685 22.8747C5.3309 23.2495 5.78063 24.8381 5.78063 25.445C5.78063 25.8913 5.64225 26.1412 5.14064 26.5696C4.7774 26.873 4.43146 27.1229 4.36227 27.1229C4.29308 27.1229 4.03362 26.8373 3.77417 26.4803L3.30715 25.8556L3.6012 24.3919C3.77417 23.5887 3.94714 22.8747 3.99903 22.7854C4.12011 22.5712 4.86388 22.6427 5.03685 22.8747Z" data-v-f0c1c6d7></path><path d="M19.6875 21.3218C18.2691 22.8747 17.4216 26.0876 18.1307 27.2121C18.6324 28.0154 20.881 28.9078 22.3685 28.9078C22.6453 28.9078 22.9566 29.0149 23.0604 29.1577C23.4064 29.5861 23.9253 29.6218 24.3923 29.2113C24.7728 28.8721 24.8247 28.6401 24.8766 27.4799C24.9112 26.6767 25.0496 25.927 25.2225 25.6057C26.2258 23.6958 24.5826 22.6605 21.8496 23.4816C20.7253 23.8207 20.4831 24.0171 20.4831 24.5347C20.4831 25.1773 20.9156 25.3915 22.0399 25.3558L23.0604 25.3201L22.8701 25.9091C22.7664 26.2304 22.6453 26.6053 22.6107 26.7302C22.5415 27.0158 21.7977 26.8908 20.708 26.4089C20.068 26.1233 19.9642 25.9984 19.9642 25.5343C19.9642 24.8738 20.535 23.2674 20.9848 22.6784C21.2442 22.3214 21.4518 22.25 22.0918 22.2678C22.6626 22.3035 22.8874 22.2321 22.9739 22.0179C23.1123 21.6252 22.9912 21.4646 22.2129 21.054C21.1404 20.5007 20.3794 20.5721 19.6875 21.3218Z" data-v-f0c1c6d7></path><path d="M26.6063 21.0719C26.3123 21.411 26.2777 21.7502 26.2777 24.2491C26.2777 26.7302 26.3123 27.105 26.6236 27.6584C26.9004 28.1225 27.1252 28.301 27.5058 28.3367C28.4225 28.4259 28.4917 28.1582 28.4571 24.856C28.4225 21.3932 28.2495 20.6971 27.4366 20.6971C27.1425 20.6971 26.7966 20.8577 26.6063 21.0719Z" data-v-f0c1c6d7></path><path d="M38.23 21.2682C38.1089 21.5003 37.9359 22.1072 37.884 22.6248C37.8148 23.1424 37.5727 24.142 37.3305 24.8203C37.0883 25.4986 36.8289 26.4089 36.7597 26.8194L36.6213 27.5691L36.3965 26.7659C36.2408 26.2126 36.2062 25.3022 36.2754 23.785C36.3619 21.8751 36.3446 21.5895 36.0678 21.3396C35.6527 20.9469 35.0819 20.9826 34.6841 21.4289C34.2516 21.9108 34.0787 23.2495 34.1824 25.2665C34.217 26.0876 34.1997 26.7659 34.1305 26.7659C33.9403 26.7659 32.8852 25.0345 31.9857 23.2317C31.536 22.3214 31.0344 21.5003 30.8614 21.411C30.429 21.179 29.8755 21.179 29.7371 21.4289C29.6679 21.536 29.616 23.0532 29.5987 24.8024C29.5814 28.2831 29.6506 28.5509 30.5328 28.5509C31.0863 28.5509 31.5533 27.9975 31.5533 27.3371C31.5533 26.9265 31.6052 26.9444 32.2625 27.6584C33.0754 28.5152 34.5111 29.2648 35.4278 29.3005C36.0678 29.3184 36.5694 29.0328 36.5694 28.6222C36.5694 28.301 36.6559 28.301 37.1921 28.658C37.7283 29.0328 38.4029 28.7829 38.6451 28.1046C38.7835 27.7119 38.9045 27.6584 39.6656 27.6584C40.4613 27.6584 40.5651 27.7119 40.8072 28.1939C41.2569 29.0863 42.0699 29.3541 42.5715 28.7472C42.8483 28.3902 42.8656 28.3902 43.3326 28.8007C43.7477 29.1756 44.0072 29.2113 45.685 29.247C46.7055 29.2827 47.9682 29.3005 48.4871 29.3184C49.3001 29.3541 49.4558 29.3005 49.7498 28.89C50.1649 28.3367 50.0612 27.7833 49.4558 27.3728C49.2309 27.2121 48.245 27.0158 47.0861 26.9087L45.1142 26.6945L45.1834 25.6057C45.2699 24.1956 44.9412 21.9644 44.578 21.5538C44.4223 21.3753 44.1628 21.2325 43.9899 21.2325C43.4191 21.2325 43.1769 21.9465 43.0731 23.91C43.0039 24.9452 42.9175 26.1769 42.8483 26.6767L42.7445 27.5691L42.4504 26.6767C41.9834 25.2665 40.444 22.2143 39.8386 21.5181C39.2159 20.7684 38.5932 20.6792 38.23 21.2682ZM39.8559 25.7128C39.8559 25.802 39.7348 25.8734 39.5964 25.8734C39.4407 25.8734 39.337 25.7128 39.337 25.4986C39.337 25.1773 39.3716 25.1594 39.5964 25.3379C39.7348 25.4629 39.8559 25.6235 39.8559 25.7128Z" data-v-f0c1c6d7></path>',
                                                              7,
                                                          ),
                                                      ]),
                                              ))
                                            : createCommentVNode("", true),
                                        unref(panelStore).displayMode ===
                                        "original-only"
                                            ? (openBlock(),
                                              createElementBlock(
                                                  "svg",
                                                  _hoisted_16,
                                                  _cache[18] ||
                                                      (_cache[18] = [
                                                          createStaticVNode(
                                                              '<path d="M7.78339 0.663546C6.92876 1.04348 6.73291 1.53197 7.17803 2.27374C7.71217 3.14217 7.71217 5.00565 7.17803 5.27704C6.73291 5.53033 6.78632 5.60269 6.50145 4.37243C6.16316 3.01552 5.52218 1.76717 4.93463 1.33295C4.11561 0.754007 2.90488 0.663546 1.90782 1.11585C1.44489 1.31486 0.910748 1.6948 0.714895 1.94809C0.340995 2.47276 0.00270434 4.53526 0.00270434 6.38065C-0.0151004 7.48427 0.0383139 7.62901 0.679286 8.49743C1.51611 9.60105 2.35293 10.0714 3.24317 9.90862C4.25805 9.74579 5.70023 8.66026 6.26999 7.62901C6.6973 6.86914 6.82193 6.76059 6.99998 6.97769C7.12461 7.14052 7.16022 7.50237 7.08901 7.97276C6.83974 9.54677 8.26412 10.2886 8.95851 8.94974C9.06534 8.73263 9.15436 8.29842 9.15436 7.99085C9.15436 7.44809 9.18997 7.41191 9.65289 7.53855C10.1692 7.66519 11.5402 8.29842 12.5373 8.89546C13.6056 9.52868 14.6738 9.31158 14.6738 8.46125C14.6738 8.13559 14.6916 8.13559 14.9943 8.40697C15.4038 8.78691 16.1694 8.805 16.5255 8.42506C16.8638 8.09941 16.8994 7.39381 16.5968 6.85105C16.4899 6.63394 16.3475 5.53033 16.2585 4.37243C16.116 2.07473 16.027 1.73098 15.5463 1.4596C15.0834 1.2244 14.5314 1.53197 14.3712 2.16519C14.1931 2.79842 14.1931 6.67013 14.3712 7.30335L14.4958 7.79184L13.4097 7.06815C12.8221 6.67013 12.0565 6.21783 11.7004 6.07309L11.0773 5.80171L11.4334 5.40368C11.9675 4.78855 12.3592 3.90203 12.3592 3.26881C12.3592 2.81651 12.1812 2.50894 11.558 1.9119C11.1307 1.47769 10.5431 1.0073 10.2761 0.880652C9.49265 0.482625 8.42436 0.374073 7.78339 0.663546ZM10.4007 3.48592C10.4007 3.55828 10.2048 3.86585 9.95558 4.13723L9.52826 4.64381L9.51046 3.68493V2.74414L9.95558 3.03361C10.2048 3.19644 10.4007 3.39546 10.4007 3.48592ZM3.59927 3.25072C3.91976 3.46782 4.52512 5.16848 4.52512 5.91026C4.52512 6.34447 4.38268 6.65204 4.04439 6.99579C3.29659 7.68329 2.92269 7.73756 2.54879 7.24908C2.12147 6.67013 2.06806 6.12736 2.35293 4.75236C2.63781 3.21453 2.9583 2.85269 3.59927 3.25072Z" data-v-f0c1c6d7></path><path d="M19.036 1.6767C18.0924 2.52703 17.1309 4.62572 17.0419 6.12736C16.9529 7.26716 16.9885 7.4119 17.4158 7.91848C18.0033 8.64217 19.4455 9.27539 20.7987 9.40203C21.4753 9.45631 22.0628 9.63723 22.3655 9.85434C22.9175 10.2705 23.6474 10.1619 23.9323 9.60105C24.0392 9.40203 24.1638 8.69644 24.1816 8.02703C24.1994 7.33953 24.3596 6.56157 24.5199 6.23591C25.1074 5.09611 24.8404 4.17341 23.8433 3.82966C23.1667 3.61256 22.2943 3.68493 20.7809 4.11914C20.0331 4.33624 19.8194 4.48098 19.7304 4.84282C19.5345 5.63887 20.0331 5.98262 21.2438 5.87407L22.2765 5.78361L21.8848 7.48427L21.1548 7.37572C20.7453 7.32144 20.1221 7.14052 19.766 6.9596C19.2497 6.7244 19.125 6.56157 19.125 6.16355C19.125 5.49414 19.7482 3.81157 20.2289 3.19644C20.5494 2.78032 20.7097 2.72604 21.2794 2.79841C21.9382 2.88887 22.3299 2.68986 22.3299 2.25565C22.3299 1.96618 20.6919 1.11585 20.1221 1.11585C19.8728 1.11585 19.3921 1.36914 19.036 1.6767Z" data-v-f0c1c6d7></path><path d="M26.1757 1.35105C25.7306 1.6767 25.5348 2.74414 25.5348 4.82473C25.5348 6.94151 25.7662 8.0994 26.2826 8.66026C26.7455 9.14875 27.1728 9.18493 27.5289 8.75072C27.974 8.24414 27.9918 8.02704 27.8672 4.87901C27.7604 2.29184 27.6891 1.80335 27.4043 1.47769C27.0304 1.06157 26.6208 1.0073 26.1757 1.35105Z" data-v-f0c1c6d7></path><path d="M38.1227 1.51387C37.9269 1.65861 37.7488 2.20137 37.6242 2.92506C37.5352 3.57638 37.2147 4.78855 36.912 5.63888C36.6271 6.47111 36.3957 7.35763 36.3957 7.61092C36.3957 7.97276 36.3601 8.02704 36.182 7.82802C36.0218 7.68329 35.9505 6.79677 35.9505 4.77046V1.92999L35.452 1.6948C35.0247 1.47769 34.9001 1.49578 34.5262 1.73098C33.9208 2.12901 33.814 2.67177 33.814 5.1323C33.814 6.30828 33.7606 7.26717 33.6893 7.26717C33.4579 7.26717 32.7813 6.19973 31.6774 4.06486C30.805 2.3823 30.4667 1.9119 30.075 1.78526C29.1313 1.4596 29.0423 1.80335 29.0601 5.31322C29.0779 7.03197 29.0779 8.53362 29.0957 8.66026C29.0957 8.98592 29.7901 9.29348 30.2352 9.18493C30.6625 9.07638 31.0542 8.40697 31.0542 7.77375C31.0542 7.44809 31.1611 7.50236 31.6952 8.15368C32.3896 8.96783 33.1908 9.45631 34.4193 9.80006C35.4164 10.0714 36.004 9.90862 36.2176 9.32967C36.3779 8.91355 36.4135 8.89546 36.6805 9.14875C37.2147 9.7096 38.2296 9.40204 38.4254 8.62408C38.5322 8.17177 38.5857 8.17177 39.4759 8.28033C39.9744 8.35269 40.4195 8.47934 40.4552 8.55171C40.4908 8.62408 40.6688 8.89546 40.8647 9.14875C41.3098 9.7096 42.1644 9.78197 42.4671 9.29348C42.6629 8.96783 42.6986 8.96783 43.0547 9.34776C43.4107 9.7096 43.6956 9.74579 46.3307 9.85434C47.9154 9.92671 49.3397 9.92671 49.5 9.85434C49.9807 9.67342 50.1588 8.91355 49.8383 8.40697C49.4466 7.80993 48.859 7.61092 46.8471 7.48427L45.1022 7.35763L45.0488 5.25894C44.9776 2.49085 44.4612 1.33295 43.5176 1.83953C43.1259 2.05664 43.0368 2.41848 42.9122 4.46289C42.841 5.3494 42.752 6.52539 42.6986 7.06815L42.5917 8.04513L42.022 6.61585C40.7222 3.39545 39.3869 1.29677 38.6391 1.29677C38.5144 1.29677 38.283 1.40532 38.1227 1.51387ZM39.4937 6.10927C39.6539 6.5073 39.6361 6.54348 39.3335 6.54348C39.191 6.54348 39.0664 6.38065 39.0664 6.18164C39.0664 5.74743 39.3335 5.69315 39.4937 6.10927Z" data-v-f0c1c6d7></path><path d="M15.2614 10.7047C14.5314 11.157 13.6412 12.3872 13.4987 13.1471C13.4453 13.4728 13.4987 13.9793 13.659 14.3412C13.8014 14.7211 13.8726 15.3543 13.837 16.0418C13.748 17.3264 14.1219 18.1043 15.0655 18.5928C16.846 19.5336 18.5197 18.4843 19.2319 15.9876C19.8194 13.9612 19.2497 11.356 18.0746 10.6504C17.3624 10.2343 15.9914 10.2524 15.2614 10.7047ZM17.3089 14.0155C17.3624 14.9201 17.2911 15.3001 16.9529 15.9514C16.1516 17.5435 15.6531 16.6208 16.1872 14.5221C16.3475 13.907 16.5433 13.2014 16.6502 12.93C16.9172 12.1882 17.2199 12.6948 17.3089 14.0155Z" data-v-f0c1c6d7></path><path d="M36.2354 11.953C36.0574 12.1339 35.7725 12.6767 35.5945 13.1652C35.4164 13.6537 35.2384 14.0879 35.2027 14.1422C35.1671 14.1784 34.633 13.6718 34.0276 13.0024C32.8703 11.754 32.532 11.5912 32.0513 12.0797C31.4103 12.731 31.6774 13.3461 33.6003 15.8066C34.1523 16.4941 34.1523 16.6208 33.6715 17.7606C33.3511 18.5205 33.5291 19.1175 34.1523 19.407C34.8645 19.7326 35.3986 19.2261 36.1998 17.5254C37.5886 14.5221 37.9981 12.532 37.3215 11.9168C36.8942 11.5188 36.6449 11.5369 36.2354 11.953Z" data-v-f0c1c6d7></path><path d="M20.6384 11.953C20.4426 12.2968 20.3892 18.5566 20.585 18.7918C21.1192 19.4432 22.1875 18.7014 22.4189 17.5254C22.7216 16.0237 23.4872 13.9612 23.7721 13.9612C24.1638 13.9612 24.2528 14.6668 24.0035 15.879C23.6296 17.7606 23.6653 18.7557 24.146 19.0994C24.6979 19.4974 25.0718 19.4613 25.695 18.9185C26.2647 18.4481 26.4072 17.8149 26.0511 17.453C25.8908 17.2902 25.8908 17.0369 26.0511 16.4218C26.336 15.2277 26.3004 14.3593 25.8908 13.527C25.2499 12.1882 23.8611 11.6274 22.7038 12.2244C22.2587 12.4596 22.2053 12.4596 22.0094 12.1339C21.7779 11.7721 20.8343 11.6455 20.6384 11.953Z" data-v-f0c1c6d7></path><path d="M27.9562 12.0254C27.7069 12.2063 27.5823 12.731 27.4043 14.3412C27.2796 15.481 27.1194 16.856 27.0482 17.4168C26.9235 18.3214 26.9591 18.4662 27.3686 18.9366C27.8494 19.5155 28.2589 19.5698 30.342 19.3165C31.713 19.1356 32.3006 18.8099 32.3006 18.2491C32.3006 17.5254 31.5172 16.9645 30.4667 16.9284L29.5586 16.8922L29.5942 15.3724C29.6477 13.6718 29.4696 12.8214 28.8821 12.2063C28.4369 11.7178 28.3835 11.7178 27.9562 12.0254Z" data-v-f0c1c6d7></path>',
                                                              8,
                                                          ),
                                                      ]),
                                              ))
                                            : createCommentVNode("", true),
                                        unref(panelStore).displayMode ===
                                        "translate-only"
                                            ? (openBlock(),
                                              createElementBlock(
                                                  "svg",
                                                  _hoisted_17,
                                                  _cache[19] ||
                                                      (_cache[19] = [
                                                          createStaticVNode(
                                                              '<path d="M6.58525 0.617152C4.89156 0.840598 1.89232 1.40781 1.27483 1.63125C-0.0660064 2.09533 -0.418858 2.93755 0.551484 3.38445C0.904336 3.55633 1.18662 3.55633 1.68061 3.43601C2.0511 3.33288 2.63331 3.24694 2.98616 3.24694H3.62129L3.74479 5.13764C3.86829 7.23459 4.06236 7.85337 4.67985 7.99087C5.20913 8.12838 5.54433 7.99087 5.84426 7.50961C6.07361 7.18303 6.07361 6.77051 5.93247 5.06889C5.84426 3.95166 5.82662 2.97193 5.91483 2.90318C5.9854 2.83442 6.51468 2.71411 7.07924 2.64535L8.10251 2.52504L7.97901 3.62508C7.85551 4.81106 8.13779 6.51269 8.54357 7.14865C8.72 7.40648 8.96699 7.54398 9.31985 7.54398C9.6727 7.54398 9.90205 7.42366 10.0432 7.14865C10.149 6.9424 10.2725 6.75333 10.2902 6.71895C10.3078 6.70176 10.696 6.83927 11.1547 7.02834C11.6134 7.21741 12.1779 7.3721 12.4073 7.3721C12.6367 7.3721 13.0424 7.5096 13.3424 7.6643C13.6246 7.81899 13.9775 7.90493 14.1363 7.83618C14.595 7.6643 15.1419 6.66739 15.1419 6.01423C15.1419 5.49859 15.1772 5.44703 15.5477 5.55015C15.7594 5.60172 16.1475 5.65328 16.4122 5.65328C16.7297 5.65328 16.9238 5.7736 16.9944 6.01423C17.2237 6.68457 18.1411 7.54398 18.6704 7.54398C18.9351 7.54398 19.2526 7.6643 19.3761 7.81899C19.5173 7.97369 19.8172 8.05963 20.1524 8.02525C20.8934 7.9565 21.1404 7.40648 21.1404 5.7736C21.1404 4.53605 21.3168 4.08916 21.5638 4.72512C21.6167 4.86263 21.9696 5.42984 22.3224 5.94548C23.3104 7.40648 24.4572 7.92212 25.1629 7.23459C25.4452 6.9424 25.4804 6.95958 26.0097 7.49242C26.4155 7.92212 26.7154 8.05963 27.1565 8.05963C28.1621 8.05963 29.0619 7.71586 29.7852 7.09709L30.4557 6.4955L30.5792 7.01115C30.6321 7.30335 30.932 7.73305 31.2319 7.97369C31.7436 8.40339 31.8141 8.40339 33.8783 8.33464C36.1542 8.23151 36.4718 8.094 36.4894 7.25178C36.4894 6.92521 36.5953 6.87364 37.5127 6.82208C38.4301 6.77051 38.5536 6.80489 38.9241 7.23459C39.4004 7.78462 40.1767 7.87056 40.6178 7.44085C40.9883 7.09709 40.9706 6.99396 40.4943 5.75641C40.2649 5.17201 39.9297 4.34698 39.7709 3.90009C39.1887 2.35316 36.7188 0.290576 35.7837 0.582775C35.4309 0.685904 35.078 1.57969 35.078 2.35316C35.078 2.67973 34.39 6.03142 34.3194 6.11736C34.3017 6.11736 33.9136 6.18612 33.4725 6.25487L32.661 6.37519L32.5375 4.22667C32.3963 1.54531 32.1493 0.771845 31.426 0.703092C30.7732 0.63434 30.5086 1.11561 30.3674 2.67973C30.3145 3.26413 30.2087 3.76259 30.1557 3.76259C30.1028 3.76259 29.9087 3.64227 29.7147 3.50476C29.5382 3.36726 28.7973 3.09225 28.0563 2.88599C26.9095 2.54223 26.8036 2.47347 27.1565 2.33597C27.6858 2.1469 28.515 2.30159 28.9208 2.66254C29.1677 2.8688 29.3089 2.88599 29.5912 2.7313C30.2616 2.38753 29.9793 1.37343 29.0619 0.926538C28.268 0.514023 26.5037 0.428082 25.4628 0.737469C24.7042 0.960915 24.563 0.978103 24.316 0.754657C23.5927 0.118695 22.7282 0.737469 22.7282 1.90626C22.7282 2.26722 22.6753 2.55941 22.6047 2.54223C22.5165 2.54223 22.1284 2.11252 21.7049 1.59688C21.0522 0.806221 20.8581 0.668716 20.3465 0.668716C19.3761 0.668716 19.1997 1.08123 19.1997 3.48757C19.1997 4.67356 19.1291 5.4814 19.0409 5.39546C18.9527 5.29233 18.7586 4.79388 18.5822 4.27823C18.1059 2.85161 17.3296 1.44218 16.7827 1.01248C16.3945 0.720281 16.1299 0.651528 15.6182 0.720281C14.7538 0.840598 14.3656 1.18436 14.101 2.09533C13.9775 2.49066 13.6952 3.4532 13.4482 4.22667L13.0248 5.6361L12.5308 5.46421C12.2662 5.36108 11.878 5.20639 11.6487 5.12045L11.2429 4.96576L11.7722 4.43292C12.4073 3.81415 12.5661 3.31569 12.4426 2.38753C12.3367 1.63125 11.878 0.943727 11.2958 0.685904C10.9253 0.514023 7.74966 0.462458 6.58525 0.617152ZM10.5548 2.47347C10.7313 2.67973 10.7136 2.81724 10.4843 3.161C10.0608 3.79696 9.74327 3.69383 9.70798 2.90318C9.6727 2.31878 9.70798 2.21565 9.99026 2.21565C10.1843 2.21565 10.4313 2.33597 10.5548 2.47347ZM16.1828 3.79696C16.2005 3.8829 16.077 3.93447 15.9358 3.93447C15.6712 3.93447 15.5653 3.40163 15.7947 3.17819C15.9182 3.07506 16.1475 3.47039 16.1828 3.79696ZM37.6009 4.36417C37.989 5.15483 37.989 5.13764 37.3715 5.13764C36.807 5.13764 36.7893 5.10326 36.9481 4.29542C37.0893 3.60789 37.2304 3.62508 37.6009 4.36417ZM26.786 4.48449C27.5093 4.67356 28.2856 4.93138 28.515 5.03451L28.9031 5.24077L28.5503 5.61891C28.1092 6.08299 27.9151 6.10018 27.6858 5.67047C27.3682 5.12045 26.8213 5.12045 26.1862 5.67047L25.5863 6.16893L25.3217 5.3439C25.1629 4.897 24.9865 4.36417 24.9159 4.19229C24.81 3.93447 24.8453 3.90009 25.1276 4.00322C25.304 4.07197 26.0627 4.29542 26.786 4.48449Z" data-v-f0c1c6d7></path><path d="M40.1414 1.01248C39.8768 1.21873 39.6651 1.52812 39.6651 1.7C39.6651 2.11252 40.3179 2.55941 40.9001 2.55941C41.3411 2.55941 41.3411 2.5766 41.3411 4.07197C41.3588 5.7736 41.7293 7.11427 42.4173 7.76742C42.9995 8.35182 43.4759 8.43776 43.9346 8.05962C44.3227 7.75024 44.3227 7.75024 44.0228 6.80489C43.864 6.28924 43.617 5.12045 43.4759 4.20947L43.2465 2.55941H44.8696L44.8167 4.29542C44.7285 6.59863 44.8696 7.44085 45.4695 8.094C46.281 8.98778 48.3805 8.93622 49.4391 7.97368C50.3741 7.13146 49.8625 6.51269 48.2041 6.51269C47.2161 6.51269 47.075 6.47831 47.075 6.18611C47.075 5.92829 47.2514 5.84235 47.9571 5.75641C48.9274 5.63609 49.8978 4.96575 49.8978 4.43292C49.8978 4.26104 49.7566 3.96884 49.5802 3.79696C49.2626 3.48757 49.2626 3.47038 49.6155 3.31569C50.1801 3.07506 50.1095 2.25002 49.492 1.80313C49.0686 1.51093 48.7334 1.44218 47.4278 1.42499C46.1223 1.42499 45.7871 1.35624 45.4695 1.08123C45.1519 0.806219 44.7814 0.754654 42.8584 0.70309C40.7942 0.651525 40.6001 0.668713 40.1414 1.01248ZM48.2394 3.24694C48.9804 3.24694 48.6981 3.52195 47.7807 3.69383C46.8103 3.90009 46.7221 3.86571 46.7221 3.36725C46.7221 3.07506 46.8103 3.04068 47.269 3.14381C47.569 3.19537 48.01 3.24694 48.2394 3.24694Z" data-v-f0c1c6d7></path><path d="M17.3296 8.98778C16.6062 9.31436 15.53 10.5691 15.3889 11.2738C15.336 11.5832 15.336 12.0988 15.4065 12.4082C15.4771 12.7004 15.5477 13.5255 15.583 14.213C15.6359 15.6052 15.9005 16.1381 16.7827 16.6709C17.2237 16.9459 17.5589 16.9975 18.3176 16.9459C19.1821 16.8772 19.3408 16.8084 19.923 16.1552C20.7699 15.2271 21.158 14.0755 21.1757 12.477C21.1757 11.0504 20.7875 9.96751 20.0465 9.29717C19.482 8.79871 18.1059 8.64402 17.3296 8.98778ZM19.0056 12.4942C19.0233 13.0786 18.8998 13.8348 18.7586 14.1614C18.5116 14.7458 18.0706 15.0896 17.8412 14.8661C17.5413 14.5911 18.0176 12.0129 18.5469 11.0676C18.7233 10.741 18.7233 10.741 18.8645 11.0676C18.9351 11.2566 19.0056 11.8926 19.0056 12.4942Z" data-v-f0c1c6d7></path><path d="M22.5518 10.2941C22.3401 10.4144 22.2871 10.8441 22.2871 12.2192C22.2871 13.1989 22.2166 14.5396 22.1284 15.2099C21.9872 16.3443 22.0049 16.4646 22.3577 16.8084C23.134 17.5647 23.7691 16.9287 24.316 14.9005C24.7747 13.1817 25.1982 12.3223 25.551 12.391C25.8862 12.4598 25.8862 13.1645 25.551 14.9865C25.3393 16.1724 25.3393 16.3959 25.5687 16.7912C25.9215 17.41 26.8389 17.5131 27.3859 17.0147C27.7563 16.6709 27.7916 16.5162 27.774 14.2474L27.7563 11.8582L27.2271 11.3254C26.2391 10.2941 25.3746 10.0706 24.4925 10.5691C24.0338 10.8441 23.9985 10.8441 23.628 10.4832C23.2222 10.0878 22.9576 10.0363 22.5518 10.2941Z" data-v-f0c1c6d7></path><path d="M37.6538 10.5003C37.495 10.7066 37.248 11.2738 37.0893 11.7379L36.7893 12.5973L35.7131 11.4457C34.5487 10.191 33.8607 9.95032 33.4902 10.655C33.1903 11.2051 33.4373 11.8754 34.337 12.9754C35.8543 14.8146 35.819 14.7114 35.4132 15.4677C35.2368 15.8287 35.078 16.3099 35.078 16.5334C35.078 17.3756 36.313 17.8397 36.8776 17.2037C37.2833 16.774 38.1478 15.038 38.6771 13.5942C39.1711 12.2535 39.2946 10.6894 38.9241 10.3285C38.5889 10.0019 37.9538 10.0878 37.6538 10.5003Z" data-v-f0c1c6d7></path><path d="M29.3442 10.8785C29.203 11.2051 29.0795 11.8582 29.0795 12.3051C29.0795 12.752 28.956 13.8177 28.8325 14.6427C28.4268 17.0147 28.8678 17.6678 30.7027 17.4444C31.2143 17.3756 32.0435 17.2897 32.5198 17.2209C33.596 17.1006 33.843 16.9287 33.843 16.3099C33.843 15.588 33.1197 15.1068 32.0788 15.1068H31.2319L31.1614 13.2333C31.1261 11.652 31.0555 11.2738 30.7379 10.8613C30.1734 10.1394 29.6617 10.1394 29.3442 10.8785Z" data-v-f0c1c6d7></path>',
                                                              6,
                                                          ),
                                                      ]),
                                              ))
                                            : createCommentVNode("", true),
                                    ]),
                                    _cache[20] ||
                                        (_cache[20] = createBaseVNode(
                                            "span",
                                            { class: "action-title" },
                                            "Display",
                                            -1,
                                        )),
                                ],
                                10,
                                _hoisted_12,
                            ),
                            createBaseVNode(
                                "button",
                                {
                                    class: normalizeClass([
                                        "action action-time",
                                        {
                                            "action-active":
                                                unref(panelStore).isShowTime,
                                        },
                                    ]),
                                    onClick:
                                        _cache[5] ||
                                        (_cache[5] = (...args) =>
                                            unref(panelStore).toggleShowTime &&
                                            unref(panelStore).toggleShowTime(
                                                ...args,
                                            )),
                                    disabled:
                                        unref(subtitlesStore).subtitles
                                            .length === 0,
                                },
                                _cache[21] ||
                                    (_cache[21] = [
                                        createStaticVNode(
                                            '<span class="action-icon" data-v-f0c1c6d7><svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-f0c1c6d7><path d="M14.5314 5.54259C14.4108 5.56465 13.3361 5.95071 12.1409 6.40294C9.57488 7.35154 8.76341 7.8479 7.73263 9.06122C6.98696 9.93261 6.06584 11.6092 5.76977 12.6019C5.375 13.9476 5.0241 16.6169 5.00217 18.3045C4.9912 19.8487 5.01313 20.0142 5.27631 20.6981C5.70397 21.8121 6.23033 22.6284 7.01986 23.4336C7.87519 24.2939 8.52217 24.6359 9.98061 24.9778C10.5508 25.1102 11.7132 25.3969 12.5576 25.6065C15.3319 26.3124 15.8363 26.4117 17.218 26.4779C19.4221 26.5992 20.727 26.2352 22.5364 25.0329C23.5781 24.338 25.0695 22.8159 25.8042 21.7018C27.2626 19.4848 28.2276 16.0433 27.9534 13.9586C27.8219 12.8887 27.449 11.1239 27.1858 10.3407C26.8898 9.43625 26.2976 8.78547 25.1791 8.12365C24.6747 7.82584 23.94 7.32948 23.5343 7.0096C22.2513 6.02792 21.7578 5.8404 19.9594 5.66392C18.6326 5.53156 14.9042 5.44332 14.5314 5.54259ZM20.2994 8.36632C21.1657 8.75237 21.2863 8.84062 21.7249 9.45831C21.9881 9.83333 22.2842 10.2635 22.3719 10.4179C22.4596 10.5834 22.6789 10.8812 22.8434 11.1018C23.0079 11.3224 23.293 11.7967 23.4685 12.1717C23.7426 12.7453 23.7974 12.9769 23.7974 13.7049C23.7974 14.819 23.9729 15.8779 24.258 16.4625C24.4773 16.9147 24.4773 16.9588 24.3019 17.4221C24.0058 18.2052 22.9531 19.8157 22.4267 20.312C22.0977 20.6209 21.5385 20.9407 20.7051 21.3047L19.466 21.8342H18.0953C15.4415 21.8232 12.5137 21.029 11.0004 19.9149C10.2438 19.3634 9.54198 17.6427 9.54198 16.3632C9.54198 15.0727 10.7043 12.0725 11.7571 10.6385C12.744 9.30388 13.2594 8.95092 15.2442 8.25602C16.264 7.89202 16.3298 7.88099 17.8211 7.91408C19.3234 7.94717 19.3782 7.9582 20.2994 8.36632Z" data-v-f0c1c6d7></path><path d="M16.3517 8.74135C15.7157 9.42522 15.3648 9.97673 15.288 10.4069C15.2551 10.6275 15.0577 11.3996 14.8494 12.1276C14.641 12.8556 14.4108 13.8814 14.345 14.4219C14.2353 15.1609 14.1695 15.3926 14.016 15.4477C13.709 15.5359 13.38 16.0433 13.38 16.4073C13.38 16.5838 13.4567 16.9809 13.5554 17.3008C14.027 18.7568 14.1695 18.8671 15.8034 19.0435C17.0864 19.1759 17.3496 19.0766 17.5579 18.3707C17.6786 17.9626 17.7334 17.9185 18.1939 17.8192C19.5866 17.5214 22.5473 16.2419 22.8434 15.8117C22.9531 15.6683 23.0298 15.3705 23.0298 15.1499C23.0298 14.3778 21.9881 13.8814 20.9902 14.1572C20.7599 14.2234 20.3432 14.2785 20.0691 14.2785C19.7949 14.2785 19.2138 14.3778 18.7751 14.4991C17.5799 14.83 17.6566 14.8962 17.6676 13.5285C17.6676 12.8777 17.7334 11.9953 17.8101 11.5761C17.8979 11.0687 17.9088 10.6827 17.843 10.429C17.7772 10.1753 17.7882 9.9657 17.865 9.78922C18.0843 9.30389 18.0075 8.91783 17.6457 8.60898C17.1741 8.20087 16.8342 8.23396 16.3517 8.74135Z" data-v-f0c1c6d7></path></svg></span><span class="action-title" data-v-f0c1c6d7> Time </span>',
                                            2,
                                        ),
                                    ]),
                                10,
                                _hoisted_18,
                            ),
                            createBaseVNode(
                                "button",
                                {
                                    class: "action action-active",
                                    onClick:
                                        _cache[6] ||
                                        (_cache[6] = (...args) =>
                                            unref(panelStore)
                                                .decreaseBlockSize &&
                                            unref(panelStore).decreaseBlockSize(
                                                ...args,
                                            )),
                                    disabled:
                                        unref(subtitlesStore).subtitles
                                            .length === 0,
                                },
                                _cache[22] ||
                                    (_cache[22] = [
                                        createStaticVNode(
                                            '<span class="action-icon" data-v-f0c1c6d7><svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-f0c1c6d7><path d="M6.30588 7.11118C4.94431 7.23115 4.38005 7.54308 4.07339 8.33489C3.79126 9.04272 4.35552 10.0145 5.2019 10.3264C5.60669 10.4824 10.3415 10.9383 11.5191 10.9383C11.973 10.9383 12.7212 10.9983 13.1874 11.0582C14.6839 11.2742 18.2166 11.2382 19.6272 10.9983C21.0011 10.7583 21.4795 10.5184 21.9333 9.87053C22.4976 9.05472 22.1541 7.855 21.2096 7.33912C20.6699 7.05119 20.2651 7.05119 17.9222 7.33912C16.7569 7.48309 14.7207 7.42311 9.61782 7.08718C7.72879 6.96721 7.76559 6.96721 6.30588 7.11118Z" data-v-f0c1c6d7></path><path d="M23.9696 7.93898C22.8288 8.44286 22.7552 9.9665 23.8346 10.7223C24.2026 10.9743 24.3621 10.9983 25.7114 10.9983C27.3796 10.9983 27.7354 10.8903 28.1892 10.2304C28.7044 9.48662 28.4836 8.81478 27.5268 8.16693C26.9626 7.78302 26.889 7.77102 25.6869 7.74703C24.7301 7.73503 24.3253 7.78302 23.9696 7.93898Z" data-v-f0c1c6d7></path><path d="M7.55706 11.91C6.04829 12.018 5.43496 12.294 4.93204 13.0978C4.41685 13.9376 4.74804 14.9693 5.68029 15.4132C6.10962 15.6172 6.77201 15.6292 16.6588 15.6532L27.1834 15.6772L27.7967 15.3772C29.3668 14.6094 29.33 12.8698 27.7476 12.102L27.1834 11.8381H17.9222C12.8316 11.8381 8.15811 11.8741 7.55706 11.91Z" data-v-f0c1c6d7></path><path d="M5.55763 16.6609C4.38005 17.2248 4.25739 18.8324 5.33683 19.6362C5.86429 20.0201 6.48988 20.1281 9.27436 20.3081C11.5559 20.464 11.9607 20.464 14.3649 20.3801C16.6588 20.2961 16.4012 20.3801 16.7446 19.6602C17.0513 19.0364 17.0513 19.0244 16.8428 18.3885C16.4748 17.2368 15.518 16.8169 13.2487 16.8169C12.4514 16.8169 11.3965 16.7689 10.9058 16.7089C10.4151 16.6489 9.10263 16.565 7.97412 16.529C6.29362 16.481 5.87656 16.505 5.55763 16.6609Z" data-v-f0c1c6d7></path><path d="M22.2645 16.7329C21.8843 16.9489 19.8848 19.1083 18.9403 20.3201C18.4987 20.9079 18.0939 21.3758 18.0449 21.3758C17.9835 21.3758 17.775 21.5318 17.5665 21.7237C17.0635 22.1916 17.039 22.8755 17.5051 23.3433C18.1553 23.9672 19.0875 23.6433 20.8293 22.1676C21.9333 21.2438 22.0437 21.1719 22.1173 21.4118C22.24 21.8317 22.2277 23.7513 22.0805 24.879C21.9579 25.8987 21.9579 25.9227 22.2768 26.4026C22.6448 26.9305 22.9269 27.0745 23.393 26.9665C24.0554 26.7985 24.4847 24.831 24.4111 22.2876L24.3621 20.8839L24.6074 21.1599C24.7546 21.3158 25.1349 21.6757 25.4661 21.9757C25.8095 22.2636 26.1653 22.6475 26.2756 22.8275C26.5332 23.2234 27.49 23.7752 27.9439 23.7752C28.4345 23.7752 28.8148 23.4753 28.9497 22.9714C29.1092 22.4436 28.8884 21.8677 28.2996 21.2558C28.0788 21.0279 27.5882 20.428 27.1956 19.9242C26.4351 18.9044 25.1226 17.6447 24.5093 17.3448C24.3008 17.2368 23.9573 17.0208 23.7733 16.8649C23.3808 16.541 22.6938 16.481 22.2645 16.7329Z" data-v-f0c1c6d7></path></svg></span><span class="action-title" data-v-f0c1c6d7> Shorten </span>',
                                            2,
                                        ),
                                    ]),
                                8,
                                _hoisted_19,
                            ),
                            createBaseVNode(
                                "button",
                                {
                                    class: "action action-active",
                                    onClick:
                                        _cache[7] ||
                                        (_cache[7] = (...args) =>
                                            unref(panelStore)
                                                .increaseBlockSize &&
                                            unref(panelStore).increaseBlockSize(
                                                ...args,
                                            )),
                                    disabled:
                                        unref(subtitlesStore).subtitles
                                            .length === 0,
                                },
                                _cache[23] ||
                                    (_cache[23] = [
                                        createStaticVNode(
                                            '<span class="action-icon" data-v-f0c1c6d7><svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-f0c1c6d7><path d="M4.84594 5.62146C3.73216 5.73077 3.24952 5.90081 2.86589 6.31377C2.14812 7.09109 2.53175 8.39069 3.62078 8.84008C4.06629 9.03441 8.74417 9.49595 10.2045 9.49595C10.7366 9.49595 11.4544 9.55668 11.8256 9.61741C12.1845 9.69028 13.521 9.75101 14.7833 9.76316C18.3227 9.78745 20.0923 9.37449 20.5997 8.39069C21.0824 7.46761 20.8225 6.49595 19.9315 5.9251C19.3622 5.54858 19.1023 5.54858 16.454 5.86437C15.2165 6.01012 13.1374 5.93725 8.0264 5.60931C7.06112 5.53644 6.19485 5.5 6.10822 5.5C6.00922 5.51215 5.45233 5.57287 4.84594 5.62146Z" data-v-f0c1c6d7></path><path d="M22.7407 6.39879C21.3794 6.95749 21.3794 8.76721 22.7407 9.3745C23.3471 9.65385 24.9682 9.70243 25.8593 9.48381C26.5523 9.31377 27.0349 8.81579 27.1092 8.20851C27.1834 7.58907 26.9854 7.23685 26.2305 6.71458C25.6241 6.28948 25.587 6.27733 24.3618 6.26519C23.6069 6.25304 22.9634 6.31377 22.7407 6.39879Z" data-v-f0c1c6d7></path><path d="M6.18248 10.4798C4.79644 10.5769 4.3633 10.6984 3.85591 11.1721C2.82876 12.1316 2.96489 13.4555 4.1653 14.0263C4.59843 14.2328 5.2667 14.2449 15.2412 14.2692L25.8593 14.2935L26.478 13.9899C27.3195 13.5769 27.6908 13.0182 27.6166 12.2773C27.5547 11.5486 27.1834 11.0506 26.4409 10.6862L25.8593 10.4069H16.6396C11.5657 10.4069 6.86312 10.4433 6.18248 10.4798Z" data-v-f0c1c6d7></path><path d="M4.02917 15.3381C3.08864 15.751 2.80401 16.8927 3.39803 17.8522C3.83116 18.5445 4.47468 18.751 6.55374 18.8603C7.58089 18.9211 8.63279 18.9939 8.90505 19.0304C9.17731 19.0668 10.2045 19.1518 11.1945 19.2126C12.1845 19.2733 13.6696 19.3826 14.4987 19.4433C15.464 19.5162 16.1817 19.5162 16.454 19.4433C17.8277 19.0668 18.4341 17.33 17.543 16.2976C16.9366 15.5931 16.7634 15.5567 13.5087 15.5081C11.8628 15.4717 10.0188 15.3988 9.40006 15.3381C8.79367 15.2652 7.44476 15.1923 6.41761 15.1559C4.78406 15.1073 4.48706 15.1316 4.02917 15.3381Z" data-v-f0c1c6d7></path><path d="M23.9906 15.6053C23.6812 15.8725 23.6441 15.9939 23.5203 17.3421C23.4461 18.1316 23.3842 19.5283 23.3842 20.4393V22.0911L22.5179 21.3138C22.0476 20.8765 21.6021 20.4271 21.5279 20.3057C21.3299 19.9534 20.3275 19.334 19.9438 19.334C19.7211 19.334 19.4612 19.4676 19.2261 19.6862C18.7063 20.2085 18.7311 20.8401 19.3003 21.5445C19.5355 21.836 20.0676 22.4919 20.476 23.002C21.5031 24.2895 22.7407 25.4676 23.3966 25.7713C23.6936 25.917 23.9411 26.0749 23.9411 26.1235C23.9411 26.2814 24.5475 26.5 24.9682 26.5C25.3024 26.5 25.5251 26.3178 26.5646 25.249C27.2329 24.5688 28.1239 23.5729 28.5323 23.0385C28.9531 22.504 29.5595 21.8117 29.8936 21.5081C30.3762 21.0709 30.5 20.8765 30.5 20.5607C30.5 20.0992 29.9307 19.4555 29.5224 19.4555C28.9655 19.4555 28.1611 19.917 26.9978 20.8765C26.3295 21.4352 25.7231 21.8603 25.6612 21.8239C25.5004 21.7267 25.5251 19.3583 25.686 17.8765C25.8098 16.8198 25.8098 16.6012 25.6241 16.1397C25.3147 15.3259 24.597 15.0951 23.9906 15.6053Z" data-v-f0c1c6d7></path><path d="M5.53896 19.6984C4.4128 19.7955 3.81879 20.1113 3.4599 20.7915C3.05152 21.581 3.34853 22.6619 4.1158 23.1721C4.40043 23.3785 4.80882 23.415 7.23438 23.4757C8.76892 23.5243 10.5757 23.6215 11.2564 23.7065C11.937 23.7794 13.3354 23.8644 14.3502 23.8644C16.0704 23.8887 16.256 23.8644 16.949 23.585C17.4564 23.3785 17.7658 23.1478 17.9638 22.8684C18.4588 22.1397 18.2732 21.0709 17.5802 20.6215C16.9243 20.2085 15.0803 19.9534 12.2464 19.8806C11.4296 19.8563 10.2045 19.7834 9.52382 19.7105C8.16253 19.5648 7.0735 19.5648 5.53896 19.6984Z" data-v-f0c1c6d7></path></svg></span><span class="action-title" data-v-f0c1c6d7> Extend </span>',
                                            2,
                                        ),
                                    ]),
                                8,
                                _hoisted_20,
                            ),
                            createBaseVNode(
                                "button",
                                {
                                    class: "action action-active",
                                    onClick:
                                        _cache[8] ||
                                        (_cache[8] = (...args) =>
                                            unref(panelStore).changeTheme &&
                                            unref(panelStore).changeTheme(
                                                ...args,
                                            )),
                                },
                                [
                                    createBaseVNode("span", _hoisted_21, [
                                        unref(panelStore).isLightTheme
                                            ? (openBlock(),
                                              createElementBlock(
                                                  "svg",
                                                  _hoisted_22,
                                                  _cache[24] ||
                                                      (_cache[24] = [
                                                          createBaseVNode(
                                                              "path",
                                                              {
                                                                  d: "M16.711 7.58759C16.6508 7.63018 16.4253 7.70117 16.2149 7.71537C15.5234 7.78636 15.4182 8.04192 15.9142 8.41106C16.3502 8.73761 16.7711 8.96478 17.2221 9.09256C17.3423 9.13515 17.7031 9.64627 18.0038 10.2284C18.5449 11.2648 18.5449 11.3216 18.3946 12.1025C18.3044 12.5568 18.2743 13.0679 18.3194 13.2383C18.4998 13.9198 17.7783 15.0414 16.4704 16.1063L15.6437 16.7878L14.0502 16.8161C12.3816 16.8303 11.8555 16.7168 11.1039 16.1914C10.8483 16.0069 10.5777 15.8649 10.5026 15.8649C10.4274 15.8649 10.2019 15.7371 9.99146 15.5809C9.781 15.4248 9.49539 15.297 9.3601 15.297C9.02938 15.297 9.01435 15.0698 9.315 14.7859C9.60061 14.5161 9.46532 14.2038 8.99932 14.1044C8.50325 13.9766 8.03724 14.2464 8.03724 14.6297C8.03724 14.8001 7.93201 15.084 7.81175 15.2402C7.69149 15.4106 7.46601 16.0211 7.30065 16.6032L7 17.668L7.67646 18.96C8.42808 20.394 9.11958 21.1323 10.9235 22.4101C12.3816 23.4323 13.3738 23.8724 15.0574 24.2558C17.8534 24.8805 19.7325 24.341 22.0776 22.2397C22.7841 21.6008 23.6109 20.6921 23.9265 20.2236C24.2422 19.7409 24.618 19.244 24.7834 19.1162C25.0389 18.9174 25.054 18.818 24.9037 18.0088C24.7834 17.4125 24.7834 17.0149 24.8886 16.7594C24.9938 16.5038 24.9788 16.1631 24.8736 15.6945C24.7984 15.3112 24.7233 14.6439 24.7233 14.2038C24.7233 13.7636 24.603 13.0111 24.4677 12.5426C24.2422 11.7617 24.0618 11.5346 22.6638 10.1716C21.2959 8.85119 20.9652 8.59563 19.7926 8.07032C18.7253 7.60179 18.3796 7.5024 18.094 7.60179C17.8985 7.67278 17.5979 7.68698 17.4325 7.61599C17.0417 7.47401 16.8312 7.45981 16.711 7.58759Z",
                                                              },
                                                              null,
                                                              -1,
                                                          ),
                                                      ]),
                                              ))
                                            : (openBlock(),
                                              createElementBlock(
                                                  "svg",
                                                  _hoisted_23,
                                                  _cache[25] ||
                                                      (_cache[25] = [
                                                          createStaticVNode(
                                                              '<path d="M17.5172 5.12157C16.951 5.36015 15.8336 6.71707 15.6995 7.31352C15.5207 8.14854 15.5952 9.66948 15.8336 10.1616C16.1763 10.8773 17.3682 11.2352 17.845 10.758C17.9642 10.6387 18.1281 10.087 18.1877 9.52037C18.2473 8.95375 18.441 7.9547 18.6198 7.28369C18.9923 5.89695 18.9029 5.37506 18.2622 5.13648C18.0387 5.04702 17.8599 4.98737 17.845 5.00228C17.8301 5.00228 17.6811 5.06193 17.5172 5.12157Z" data-v-f0c1c6d7></path><path d="M23.045 7.89505C22.3447 8.14854 21.4954 8.80463 21.0634 9.46072C20.8101 9.81859 20.7207 10.1765 20.7207 10.7133C20.7207 12.0553 21.406 12.5324 22.5533 12.0254C23.4771 11.6079 24.833 10.6984 25.1012 10.3256C25.429 9.86333 25.3992 9.20723 25.0416 8.90901C24.8777 8.7599 24.7436 8.56605 24.7436 8.47659C24.7436 8.25292 24.0284 7.67138 23.79 7.67138C23.7006 7.68629 23.3728 7.77576 23.045 7.89505Z" data-v-f0c1c6d7></path><path d="M9.4416 8.38712C9.02441 8.52132 7.90693 9.80368 7.90693 10.1616C7.90693 10.6238 8.10063 10.7878 9.11381 11.1904C9.6353 11.3992 10.2164 11.7123 10.3803 11.8763C10.872 12.3237 11.9596 12.607 12.3917 12.3833C12.8089 12.1746 13.0473 11.5781 12.9281 11.0711C12.7642 10.415 11.7511 9.05813 11.1998 8.74499C10.5591 8.38712 9.88859 8.25292 9.4416 8.38712Z" data-v-f0c1c6d7></path><path d="M14.5373 11.9956C13.4049 12.3833 12.5854 12.9499 12.0043 13.7701C11.5872 14.3516 11.5574 14.5156 11.5574 15.619C11.5574 16.5734 11.6319 16.976 11.8851 17.4382C12.7195 19.0039 14.2542 20.0924 15.9528 20.3161C17.5321 20.5397 18.9774 20.1073 20.1098 19.0635C21.2869 18.0197 21.555 17.0058 21.1826 15.0524C20.8101 13.0991 20.7207 12.9798 19.0817 12.2789C17.5917 11.6527 15.8634 11.5483 14.5373 11.9956Z" data-v-f0c1c6d7></path><path d="M23.6261 14.1876C22.3298 14.4709 21.9871 14.9779 22.3 16.1708C22.5831 17.304 22.9407 17.5724 23.9837 17.468C24.4605 17.4084 24.9671 17.2444 25.2055 17.0803C25.4439 16.9014 25.7568 16.7672 25.9058 16.7672C26.5315 16.7672 27.1126 16.4392 27.3361 15.9471C27.6341 15.3357 27.5596 15.1419 26.8295 14.5454C26.2931 14.113 26.1739 14.0832 25.0863 14.0981C24.4456 14.113 23.79 14.1428 23.6261 14.1876Z" data-v-f0c1c6d7></path><path d="M6.26797 15.0822C5.92527 15.2164 5.37399 15.7532 5.37399 15.9471C5.37399 16.0366 5.18029 16.305 4.927 16.5435C4.37571 17.0654 4.36081 17.5575 4.8674 18.0645L5.25479 18.4373L7.35564 18.3478C9.6949 18.2285 10.5144 18.0794 10.6485 17.7215C10.7826 17.3786 10.7528 16.9461 10.5889 16.6479C10.5144 16.5137 10.3803 16.2155 10.2909 15.9918C10.0525 15.291 9.5012 15.0673 7.92183 15.0226C7.13215 15.0077 6.38716 15.0226 6.26797 15.0822Z" data-v-f0c1c6d7></path><path d="M21.6593 19.5258C21.4805 19.6451 21.2273 20.0328 21.0932 20.3906C20.7356 21.33 20.9442 21.7475 22.0169 22.2396C22.4937 22.4633 23.1195 22.7913 23.4324 22.9852C24.2072 23.5071 25.2651 23.522 25.6525 23.0448C26.0101 22.6124 26.0101 22.1203 25.6823 21.7923C25.2204 21.3598 23.6559 20.1222 23.0301 19.7047C22.3596 19.2425 22.1063 19.2126 21.6593 19.5258Z" data-v-f0c1c6d7></path><path d="M11.5127 20.5994C10.4399 21.7028 9.6949 22.672 9.6055 23.0597C9.4565 23.7755 9.68 24.8192 10.0823 25.2218C10.3803 25.5201 10.5293 25.5648 10.9912 25.4753C11.3041 25.4306 11.6915 25.2964 11.8553 25.192C12.0192 25.0876 12.5556 24.2228 13.0324 23.2685C14.0456 21.2704 14.0307 21.0318 12.9579 20.495C12.1384 20.1073 11.9894 20.1222 11.5127 20.5994Z" data-v-f0c1c6d7></path><path d="M17.0553 21.3449C16.8765 21.3748 16.6084 21.5388 16.4594 21.7177C16.221 21.9712 16.1763 22.2694 16.1763 23.9097C16.1763 26.0718 16.2657 26.5191 16.7573 26.8322C17.0851 27.0559 17.1894 27.0559 17.9493 26.8322C18.4708 26.6831 18.8731 26.4595 19.0072 26.2507C19.335 25.7586 19.6032 22.7168 19.3797 22.0607C19.1562 21.3598 18.292 21.1064 17.0553 21.3449Z" data-v-f0c1c6d7></path>',
                                                              9,
                                                          ),
                                                      ]),
                                              )),
                                    ]),
                                    unref(panelStore).isLightTheme
                                        ? (openBlock(),
                                          createElementBlock(
                                              "span",
                                              _hoisted_24,
                                              " Dark ",
                                          ))
                                        : (openBlock(),
                                          createElementBlock(
                                              "span",
                                              _hoisted_25,
                                              " Light ",
                                          )),
                                ],
                            ),
                        ]),
                    ]),
                    createBaseVNode("div", _hoisted_26, [
                        createBaseVNode("div", _hoisted_27, [
                            createBaseVNode(
                                "button",
                                {
                                    class: "action action-active",
                                    onClick:
                                        _cache[9] ||
                                        (_cache[9] = (...args) =>
                                            unref(panelStore).changeFormat &&
                                            unref(panelStore).changeFormat(
                                                ...args,
                                            )),
                                    disabled:
                                        unref(subtitlesStore).subtitles
                                            .length === 0,
                                },
                                [
                                    createBaseVNode(
                                        "span",
                                        _hoisted_29,
                                        toDisplayString(
                                            unref(panelStore).format,
                                        ),
                                        1,
                                    ),
                                    _cache[26] ||
                                        (_cache[26] = createBaseVNode(
                                            "span",
                                            { class: "action-title" },
                                            " Format ",
                                            -1,
                                        )),
                                ],
                                8,
                                _hoisted_28,
                            ),
                            createBaseVNode(
                                "button",
                                {
                                    class: "action action-download",
                                    onClick:
                                        _cache[10] ||
                                        (_cache[10] = (...args) =>
                                            unref(subtitlesStore)
                                                .downloadSubtitles &&
                                            unref(
                                                subtitlesStore,
                                            ).downloadSubtitles(...args)),
                                    disabled:
                                        unref(subtitlesStore).subtitles
                                            .length === 0,
                                },
                                _cache[27] ||
                                    (_cache[27] = [
                                        createStaticVNode(
                                            '<span class="action-icon" data-v-f0c1c6d7><svg width="24" height="28" viewBox="0 0 24 28" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-f0c1c6d7><path d="M10.6734 0.102379C8.2132 0.204643 7.43519 0.306907 6.67821 0.654604C5.22733 1.30909 5.10117 1.55453 5.10117 3.68162V5.54282L4.47035 5.66554C4.13392 5.74735 3.39796 5.80871 2.85125 5.82916C2.05222 5.84962 1.73681 5.97233 1.12702 6.52456C0.391068 7.21996 0.306959 7.77218 0.853668 8.44712C0.958804 8.59029 1.00086 8.83573 0.937777 8.99935C0.68545 9.63339 3.22974 13.8467 4.86987 15.5647C5.41658 16.1169 6.11048 17.0168 6.42588 17.5282C7.20389 18.8576 10.5262 22.2119 11.0519 22.2119C11.2832 22.2119 11.5776 22.3346 11.7037 22.4982C12.2084 23.0709 13.5121 22.5596 15.1312 21.1483C16.3718 20.0643 16.8554 19.4507 17.6965 17.9168C18.2432 16.8737 19.0212 15.6056 19.4207 15.1147C20.9767 13.1513 23.5 8.46758 23.5 7.56765C23.5 7.26086 23.2477 6.8109 22.9112 6.48365C22.3856 5.97233 22.1332 5.89052 20.3669 5.76781L18.3904 5.60418L18.5165 3.80434C18.7899 0.0410214 18.2852 -0.224866 10.6734 0.102379Z" data-v-f0c1c6d7></path><path d="M5.31144 23.1322C4.84884 23.2754 4.17597 23.4186 3.83954 23.4186C3.01947 23.439 2.26249 23.9503 2.26249 24.5026C2.26249 25.0548 3.88159 26.916 4.38624 26.916C4.59652 26.916 5.31144 27.1614 5.98431 27.4478L7.18287 28L14.0167 27.8364C18.0119 27.7546 21.0398 27.6114 21.3342 27.4682C21.6076 27.366 21.8178 27.1001 21.8178 26.8955C21.8178 26.691 21.923 26.466 22.0281 26.4047C22.3856 26.1797 22.2594 25.4434 21.7758 24.9525C21.5024 24.6866 21.145 24.298 20.9347 24.0731C20.4931 23.5822 18.3273 23.3572 15.1522 23.4799C13.7854 23.5413 12.2925 23.4799 11.4093 23.3163C8.97018 22.8868 6.25767 22.805 5.31144 23.1322Z" data-v-f0c1c6d7></path></svg></span><span class="action-title" data-v-f0c1c6d7> Download </span>',
                                            2,
                                        ),
                                    ]),
                                8,
                                _hoisted_30,
                            ),
                            createBaseVNode(
                                "button",
                                {
                                    class: "action",
                                    onClick:
                                        _cache[11] ||
                                        (_cache[11] = (...args) =>
                                            unref(subtitlesStore)
                                                .copySubtitles &&
                                            unref(subtitlesStore).copySubtitles(
                                                ...args,
                                            )),
                                    disabled:
                                        unref(subtitlesStore).subtitles
                                            .length === 0,
                                },
                                _cache[28] ||
                                    (_cache[28] = [
                                        createBaseVNode(
                                            "span",
                                            { class: "action-icon" },
                                            [
                                                createBaseVNode(
                                                    "svg",
                                                    {
                                                        width: "32",
                                                        height: "32",
                                                        viewBox: "0 0 32 32",
                                                        fill: "none",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                    },
                                                    [
                                                        createBaseVNode(
                                                            "path",
                                                            {
                                                                d: "M12.699 5.55005C11.9373 5.61264 11.2066 5.72218 11.0978 5.78477C10.989 5.863 10.2273 5.97253 9.41888 6.03512C8.11304 6.12901 7.91095 6.1916 7.53785 6.56713L7.11812 6.97396L7.07148 10.698C6.96266 18.0366 6.96266 18.1462 7.1803 18.6782C7.28912 18.9442 7.63112 19.3197 7.92649 19.5075C8.36177 19.7891 8.59495 19.8204 9.26342 19.7422C9.71424 19.6796 10.5693 19.6014 11.16 19.5544L12.2482 19.4606L12.1549 20.7593C12.0927 21.4791 12.0305 22.7621 12.0305 23.6071C12.015 25.5004 12.186 25.9229 13.1654 26.2984C13.8028 26.5488 14.1292 26.5488 16.7098 26.3923C21.9331 26.0481 22.2441 26.0011 23.4566 25.3909C24.3116 24.9528 24.607 24.7181 24.778 24.3112C25.12 23.5132 25.0578 20.1334 24.6536 17.6924C24.4671 16.5658 24.2339 14.8759 24.1406 13.937C24.0318 12.9825 23.8608 11.9968 23.752 11.7308C23.4255 10.9014 22.1508 10.5259 21.1714 10.9484C20.8139 11.1049 20.7206 10.6511 20.7206 8.56999C20.7206 6.72361 20.534 6.03512 19.9744 5.75347C19.6168 5.55006 14.4401 5.42488 12.699 5.55005ZM15.6838 8.16316L18.0467 8.2414L18.1245 9.68096C18.2488 11.8716 18.5286 14.6099 18.7152 15.7052C18.8085 16.2528 18.8706 16.7223 18.8396 16.7536C18.8085 16.7849 16.6787 16.8318 14.1292 16.8631L9.48106 16.91L9.62097 14.9541C9.6987 13.8744 9.74534 11.9655 9.72979 10.6824L9.6987 8.38223L10.2739 8.36658C10.5848 8.36658 11.1289 8.25705 11.4709 8.14752C11.8129 8.02234 12.3726 7.97539 12.7146 8.02234C13.0566 8.06928 14.3935 8.13187 15.6838 8.16316Z",
                                                            },
                                                        ),
                                                    ],
                                                ),
                                            ],
                                            -1,
                                        ),
                                        createBaseVNode(
                                            "span",
                                            { class: "action-title" },
                                            " Copy ",
                                            -1,
                                        ),
                                    ]),
                                8,
                                _hoisted_31,
                            ),
                        ]),
                    ]),
                ])
            );
        };
    },
};
const YsdPanel = /* @__PURE__ */ _export_sfc(_sfc_main$6, [
    ["__scopeId", "data-v-f0c1c6d7"],
]);
const _hoisted_1$5 = {
    key: 0,
    class: "error-message",
};
const _hoisted_2$4 = ["onClick"];
const _hoisted_3$3 = {
    key: 0,
    class: "time",
};
const _hoisted_4$3 = {
    key: 0,
    class: "time",
};
const _hoisted_5$2 = { key: 1 };
const _hoisted_6$2 = { key: 0 };
const _hoisted_7 = {
    key: 0,
    class: "time",
};
const _hoisted_8 = { key: 1 };
const _hoisted_9 = {
    key: 0,
    class: "time",
};
const _sfc_main$5 = {
    __name: "YsdSubtitles",
    setup(__props) {
        const panelStore = usePanelStore();
        const videoInfoStore = useVideoInfoStore();
        const subtitlesStore = useSubtitlesStore();
        const subtitlesScrollContainer = ref(null);
        watch(
            () => videoInfoStore.currentTime,
            () => {
                if (
                    panelStore.isAutoScrollEnabled &&
                    subtitlesScrollContainer.value &&
                    subtitlesStore.activeSubtitle
                ) {
                    nextTick(() => {
                        subtitlesStore.scrollToActiveSubtitle();
                    });
                }
            },
        );
        return (_ctx, _cache) => {
            return (
                openBlock(),
                createElementBlock(
                    "div",
                    {
                        class: "subtitles",
                        ref_key: "subtitlesScrollContainer",
                        ref: subtitlesScrollContainer,
                    },
                    [
                        unref(subtitlesStore).subtitles.length === 0
                            ? (openBlock(),
                              createElementBlock(
                                  "div",
                                  _hoisted_1$5,
                                  " There are no subtitles in the video ",
                              ))
                            : createCommentVNode("", true),
                        (openBlock(true),
                        createElementBlock(
                            Fragment,
                            null,
                            renderList(
                                unref(subtitlesStore).mergedSubtitles,
                                (sub, index) => {
                                    return (
                                        openBlock(),
                                        createElementBlock(
                                            "div",
                                            {
                                                class: "subtitle",
                                                key: index,
                                                onClick: ($event) =>
                                                    unref(
                                                        videoInfoStore,
                                                    ).jumpToTime(sub.start),
                                            },
                                            [
                                                unref(panelStore)
                                                    .showOriginal &&
                                                unref(panelStore).showTranslate
                                                    ? (openBlock(),
                                                      createElementBlock(
                                                          "div",
                                                          {
                                                              key: 0,
                                                              class: normalizeClass(
                                                                  [
                                                                      "text",
                                                                      {
                                                                          "text-reverse":
                                                                              unref(
                                                                                  panelStore,
                                                                              )
                                                                                  .displayReversed,
                                                                      },
                                                                  ],
                                                              ),
                                                          },
                                                          [
                                                              createBaseVNode(
                                                                  "div",
                                                                  {
                                                                      class: normalizeClass(
                                                                          {
                                                                              "text-secondary":
                                                                                  unref(
                                                                                      panelStore,
                                                                                  )
                                                                                      .displayReversed,
                                                                          },
                                                                      ),
                                                                  },
                                                                  [
                                                                      unref(
                                                                          panelStore,
                                                                      )
                                                                          .isShowTime &&
                                                                      !unref(
                                                                          panelStore,
                                                                      )
                                                                          .displayReversed
                                                                          ? (openBlock(),
                                                                            createElementBlock(
                                                                                "span",
                                                                                _hoisted_3$3,
                                                                                toDisplayString(
                                                                                    sub.startInFormat,
                                                                                ),
                                                                                1,
                                                                            ))
                                                                          : createCommentVNode(
                                                                                "",
                                                                                true,
                                                                            ),
                                                                      (openBlock(
                                                                          true,
                                                                      ),
                                                                      createElementBlock(
                                                                          Fragment,
                                                                          null,
                                                                          renderList(
                                                                              sub.textSegments,
                                                                              (
                                                                                  segment,
                                                                                  TimesIndex,
                                                                              ) => {
                                                                                  return (
                                                                                      openBlock(),
                                                                                      createElementBlock(
                                                                                          "span",
                                                                                          {
                                                                                              key: _ctx.sIndex,
                                                                                              class: normalizeClass(
                                                                                                  {
                                                                                                      "highlighted-text":
                                                                                                          segment.start <=
                                                                                                              unref(
                                                                                                                  videoInfoStore,
                                                                                                              )
                                                                                                                  .currentTime &&
                                                                                                          unref(
                                                                                                              videoInfoStore,
                                                                                                          )
                                                                                                              .currentTime <=
                                                                                                              segment.end,
                                                                                                  },
                                                                                              ),
                                                                                          },
                                                                                          toDisplayString(
                                                                                              segment.text,
                                                                                          ) +
                                                                                              "  ",
                                                                                          3,
                                                                                      )
                                                                                  );
                                                                              },
                                                                          ),
                                                                          128,
                                                                      )),
                                                                  ],
                                                                  2,
                                                              ),
                                                              createBaseVNode(
                                                                  "div",
                                                                  {
                                                                      class: normalizeClass(
                                                                          {
                                                                              "text-secondary":
                                                                                  !unref(
                                                                                      panelStore,
                                                                                  )
                                                                                      .displayReversed,
                                                                          },
                                                                      ),
                                                                  },
                                                                  [
                                                                      unref(
                                                                          panelStore,
                                                                      )
                                                                          .isShowTime &&
                                                                      unref(
                                                                          panelStore,
                                                                      )
                                                                          .displayReversed
                                                                          ? (openBlock(),
                                                                            createElementBlock(
                                                                                "span",
                                                                                _hoisted_4$3,
                                                                                toDisplayString(
                                                                                    sub.startInFormat,
                                                                                ),
                                                                                1,
                                                                            ))
                                                                          : createCommentVNode(
                                                                                "",
                                                                                true,
                                                                            ),
                                                                      (openBlock(
                                                                          true,
                                                                      ),
                                                                      createElementBlock(
                                                                          Fragment,
                                                                          null,
                                                                          renderList(
                                                                              sub.translateSegments,
                                                                              (
                                                                                  segment,
                                                                                  tIndex,
                                                                              ) => {
                                                                                  return (
                                                                                      openBlock(),
                                                                                      createElementBlock(
                                                                                          "span",
                                                                                          {
                                                                                              key: tIndex,
                                                                                              class: normalizeClass(
                                                                                                  {
                                                                                                      "highlighted-translate":
                                                                                                          segment.start <=
                                                                                                              unref(
                                                                                                                  videoInfoStore,
                                                                                                              )
                                                                                                                  .currentTime &&
                                                                                                          unref(
                                                                                                              videoInfoStore,
                                                                                                          )
                                                                                                              .currentTime <=
                                                                                                              segment.end,
                                                                                                  },
                                                                                              ),
                                                                                          },
                                                                                          toDisplayString(
                                                                                              segment.text,
                                                                                          ) +
                                                                                              "  ",
                                                                                          3,
                                                                                      )
                                                                                  );
                                                                              },
                                                                          ),
                                                                          128,
                                                                      )),
                                                                  ],
                                                                  2,
                                                              ),
                                                          ],
                                                          2,
                                                      ))
                                                    : (openBlock(),
                                                      createElementBlock(
                                                          "div",
                                                          _hoisted_5$2,
                                                          [
                                                              unref(panelStore)
                                                                  .showOriginal
                                                                  ? (openBlock(),
                                                                    createElementBlock(
                                                                        "div",
                                                                        _hoisted_6$2,
                                                                        [
                                                                            unref(
                                                                                panelStore,
                                                                            )
                                                                                .isShowTime
                                                                                ? (openBlock(),
                                                                                  createElementBlock(
                                                                                      "span",
                                                                                      _hoisted_7,
                                                                                      toDisplayString(
                                                                                          sub.startInFormat,
                                                                                      ),
                                                                                      1,
                                                                                  ))
                                                                                : createCommentVNode(
                                                                                      "",
                                                                                      true,
                                                                                  ),
                                                                            (openBlock(
                                                                                true,
                                                                            ),
                                                                            createElementBlock(
                                                                                Fragment,
                                                                                null,
                                                                                renderList(
                                                                                    sub.textSegments,
                                                                                    (
                                                                                        segment,
                                                                                        TimesIndex,
                                                                                    ) => {
                                                                                        return (
                                                                                            openBlock(),
                                                                                            createElementBlock(
                                                                                                "span",
                                                                                                {
                                                                                                    key: _ctx.sIndex,
                                                                                                    class: normalizeClass(
                                                                                                        {
                                                                                                            "highlighted-text":
                                                                                                                segment.start <=
                                                                                                                    unref(
                                                                                                                        videoInfoStore,
                                                                                                                    )
                                                                                                                        .currentTime &&
                                                                                                                unref(
                                                                                                                    videoInfoStore,
                                                                                                                )
                                                                                                                    .currentTime <=
                                                                                                                    segment.end,
                                                                                                        },
                                                                                                    ),
                                                                                                },
                                                                                                toDisplayString(
                                                                                                    segment.text,
                                                                                                ) +
                                                                                                    "  ",
                                                                                                3,
                                                                                            )
                                                                                        );
                                                                                    },
                                                                                ),
                                                                                128,
                                                                            )),
                                                                        ],
                                                                    ))
                                                                  : createCommentVNode(
                                                                        "",
                                                                        true,
                                                                    ),
                                                              unref(panelStore)
                                                                  .showTranslate
                                                                  ? (openBlock(),
                                                                    createElementBlock(
                                                                        "div",
                                                                        _hoisted_8,
                                                                        [
                                                                            unref(
                                                                                panelStore,
                                                                            )
                                                                                .isShowTime
                                                                                ? (openBlock(),
                                                                                  createElementBlock(
                                                                                      "span",
                                                                                      _hoisted_9,
                                                                                      toDisplayString(
                                                                                          sub.startInFormat,
                                                                                      ),
                                                                                      1,
                                                                                  ))
                                                                                : createCommentVNode(
                                                                                      "",
                                                                                      true,
                                                                                  ),
                                                                            (openBlock(
                                                                                true,
                                                                            ),
                                                                            createElementBlock(
                                                                                Fragment,
                                                                                null,
                                                                                renderList(
                                                                                    sub.translateSegments,
                                                                                    (
                                                                                        segment,
                                                                                        tIndex,
                                                                                    ) => {
                                                                                        return (
                                                                                            openBlock(),
                                                                                            createElementBlock(
                                                                                                "span",
                                                                                                {
                                                                                                    key: tIndex,
                                                                                                    class: normalizeClass(
                                                                                                        {
                                                                                                            "highlighted-translate":
                                                                                                                segment.start <=
                                                                                                                    unref(
                                                                                                                        videoInfoStore,
                                                                                                                    )
                                                                                                                        .currentTime &&
                                                                                                                unref(
                                                                                                                    videoInfoStore,
                                                                                                                )
                                                                                                                    .currentTime <=
                                                                                                                    segment.end,
                                                                                                        },
                                                                                                    ),
                                                                                                },
                                                                                                toDisplayString(
                                                                                                    segment.text,
                                                                                                ) +
                                                                                                    "  ",
                                                                                                3,
                                                                                            )
                                                                                        );
                                                                                    },
                                                                                ),
                                                                                128,
                                                                            )),
                                                                        ],
                                                                    ))
                                                                  : createCommentVNode(
                                                                        "",
                                                                        true,
                                                                    ),
                                                          ],
                                                      )),
                                            ],
                                            8,
                                            _hoisted_2$4,
                                        )
                                    );
                                },
                            ),
                            128,
                        )),
                    ],
                    512,
                )
            );
        };
    },
};
const YsdSubtitles = /* @__PURE__ */ _export_sfc(_sfc_main$5, [
    ["__scopeId", "data-v-4b703e0a"],
]);
const _hoisted_1$4 = { class: "ysd-rating" };
const _hoisted_2$3 = { class: "ysd-rating-form" };
const _hoisted_3$2 = { class: "ysd-rating-title" };
const _hoisted_4$2 = {
    key: 0,
    class: "ysd-rating-stars",
};
const _hoisted_5$1 = {
    key: 1,
    class: "thumbs",
};
const _hoisted_6$1 = {
    key: 2,
    class: "ysd-write-review",
};
const _sfc_main$4 = {
    __name: "YsdModalRating",
    setup(__props) {
        const userStore = useUserStore();
        const configStore = useConfigStore();
        const rate = async (stars) => {
            configStore.rating.show = false;
            try {
                const ratingUrl = new URL(
                    `https://antonkhoteev.com/khoteev-api/ysd/rating/${stars}`,
                );
                if (userStore.userId)
                    ratingUrl.searchParams.append("userId", userStore.userId);
                if (stars === 5) {
                    window.open(ratingUrl.toString(), "_blank");
                } else {
                    await fetch(ratingUrl, { method: "GET" });
                }
            } catch (e) {}
        };
        return (_ctx, _cache) => {
            return (
                openBlock(),
                createElementBlock("div", _hoisted_1$4, [
                    createBaseVNode("div", _hoisted_2$3, [
                        createBaseVNode(
                            "div",
                            _hoisted_3$2,
                            toDisplayString(unref(configStore).rating.title),
                            1,
                        ),
                        unref(configStore).rating.type === "stars"
                            ? (openBlock(),
                              createElementBlock("div", _hoisted_4$2, [
                                  createBaseVNode(
                                      "a",
                                      {
                                          onClick:
                                              _cache[0] ||
                                              (_cache[0] = ($event) => rate(5)),
                                      },
                                      _cache[9] ||
                                          (_cache[9] = [
                                              createBaseVNode(
                                                  "svg",
                                                  {
                                                      width: "18",
                                                      height: "17",
                                                      viewBox: "0 0 24 22",
                                                      fill: "none",
                                                      xmlns: "http://www.w3.org/2000/svg",
                                                  },
                                                  [
                                                      createBaseVNode("path", {
                                                          d: "M10.2455 1.20652C11.0042 -0.180108 12.9958 -0.180108 13.7545 1.20652L15.9155 5.15589C16.203 5.68124 16.7107 6.05014 17.2992 6.16118L21.723 6.99598C23.2763 7.28908 23.8917 9.1832 22.8074 10.3333L19.7191 13.6089C19.3083 14.0447 19.1143 14.6415 19.1906 15.2355L19.7637 19.7008C19.9649 21.2686 18.3537 22.4392 16.9248 21.7634L12.8551 19.8385C12.3138 19.5824 11.6862 19.5824 11.1449 19.8385L7.07519 21.7634C5.64633 22.4392 4.0351 21.2686 4.23631 19.7008L4.80942 15.2355C4.88566 14.6415 4.69172 14.0447 4.28091 13.6089L1.19262 10.3333C0.108311 9.1832 0.723747 7.28908 2.27697 6.99598L6.70083 6.16118C7.28929 6.05014 7.79703 5.68124 8.08449 5.15589L10.2455 1.20652Z",
                                                      }),
                                                  ],
                                                  -1,
                                              ),
                                          ]),
                                  ),
                                  createBaseVNode(
                                      "a",
                                      {
                                          onClick:
                                              _cache[1] ||
                                              (_cache[1] = ($event) => rate(4)),
                                      },
                                      _cache[10] ||
                                          (_cache[10] = [
                                              createBaseVNode(
                                                  "svg",
                                                  {
                                                      width: "18",
                                                      height: "17",
                                                      viewBox: "0 0 24 22",
                                                      fill: "none",
                                                      xmlns: "http://www.w3.org/2000/svg",
                                                  },
                                                  [
                                                      createBaseVNode("path", {
                                                          d: "M10.2455 1.20652C11.0042 -0.180108 12.9958 -0.180108 13.7545 1.20652L15.9155 5.15589C16.203 5.68124 16.7107 6.05014 17.2992 6.16118L21.723 6.99598C23.2763 7.28908 23.8917 9.1832 22.8074 10.3333L19.7191 13.6089C19.3083 14.0447 19.1143 14.6415 19.1906 15.2355L19.7637 19.7008C19.9649 21.2686 18.3537 22.4392 16.9248 21.7634L12.8551 19.8385C12.3138 19.5824 11.6862 19.5824 11.1449 19.8385L7.07519 21.7634C5.64633 22.4392 4.0351 21.2686 4.23631 19.7008L4.80942 15.2355C4.88566 14.6415 4.69172 14.0447 4.28091 13.6089L1.19262 10.3333C0.108311 9.1832 0.723747 7.28908 2.27697 6.99598L6.70083 6.16118C7.28929 6.05014 7.79703 5.68124 8.08449 5.15589L10.2455 1.20652Z",
                                                      }),
                                                  ],
                                                  -1,
                                              ),
                                          ]),
                                  ),
                                  createBaseVNode(
                                      "a",
                                      {
                                          onClick:
                                              _cache[2] ||
                                              (_cache[2] = ($event) => rate(3)),
                                      },
                                      _cache[11] ||
                                          (_cache[11] = [
                                              createBaseVNode(
                                                  "svg",
                                                  {
                                                      width: "18",
                                                      height: "17",
                                                      viewBox: "0 0 24 22",
                                                      fill: "none",
                                                      xmlns: "http://www.w3.org/2000/svg",
                                                  },
                                                  [
                                                      createBaseVNode("path", {
                                                          d: "M10.2455 1.20652C11.0042 -0.180108 12.9958 -0.180108 13.7545 1.20652L15.9155 5.15589C16.203 5.68124 16.7107 6.05014 17.2992 6.16118L21.723 6.99598C23.2763 7.28908 23.8917 9.1832 22.8074 10.3333L19.7191 13.6089C19.3083 14.0447 19.1143 14.6415 19.1906 15.2355L19.7637 19.7008C19.9649 21.2686 18.3537 22.4392 16.9248 21.7634L12.8551 19.8385C12.3138 19.5824 11.6862 19.5824 11.1449 19.8385L7.07519 21.7634C5.64633 22.4392 4.0351 21.2686 4.23631 19.7008L4.80942 15.2355C4.88566 14.6415 4.69172 14.0447 4.28091 13.6089L1.19262 10.3333C0.108311 9.1832 0.723747 7.28908 2.27697 6.99598L6.70083 6.16118C7.28929 6.05014 7.79703 5.68124 8.08449 5.15589L10.2455 1.20652Z",
                                                      }),
                                                  ],
                                                  -1,
                                              ),
                                          ]),
                                  ),
                                  createBaseVNode(
                                      "a",
                                      {
                                          onClick:
                                              _cache[3] ||
                                              (_cache[3] = ($event) => rate(2)),
                                      },
                                      _cache[12] ||
                                          (_cache[12] = [
                                              createBaseVNode(
                                                  "svg",
                                                  {
                                                      width: "18",
                                                      height: "17",
                                                      viewBox: "0 0 24 22",
                                                      fill: "none",
                                                      xmlns: "http://www.w3.org/2000/svg",
                                                  },
                                                  [
                                                      createBaseVNode("path", {
                                                          d: "M10.2455 1.20652C11.0042 -0.180108 12.9958 -0.180108 13.7545 1.20652L15.9155 5.15589C16.203 5.68124 16.7107 6.05014 17.2992 6.16118L21.723 6.99598C23.2763 7.28908 23.8917 9.1832 22.8074 10.3333L19.7191 13.6089C19.3083 14.0447 19.1143 14.6415 19.1906 15.2355L19.7637 19.7008C19.9649 21.2686 18.3537 22.4392 16.9248 21.7634L12.8551 19.8385C12.3138 19.5824 11.6862 19.5824 11.1449 19.8385L7.07519 21.7634C5.64633 22.4392 4.0351 21.2686 4.23631 19.7008L4.80942 15.2355C4.88566 14.6415 4.69172 14.0447 4.28091 13.6089L1.19262 10.3333C0.108311 9.1832 0.723747 7.28908 2.27697 6.99598L6.70083 6.16118C7.28929 6.05014 7.79703 5.68124 8.08449 5.15589L10.2455 1.20652Z",
                                                      }),
                                                  ],
                                                  -1,
                                              ),
                                          ]),
                                  ),
                                  createBaseVNode(
                                      "a",
                                      {
                                          onClick:
                                              _cache[4] ||
                                              (_cache[4] = ($event) => rate(1)),
                                      },
                                      _cache[13] ||
                                          (_cache[13] = [
                                              createBaseVNode(
                                                  "svg",
                                                  {
                                                      width: "18",
                                                      height: "17",
                                                      viewBox: "0 0 24 22",
                                                      fill: "none",
                                                      xmlns: "http://www.w3.org/2000/svg",
                                                  },
                                                  [
                                                      createBaseVNode("path", {
                                                          d: "M10.2455 1.20652C11.0042 -0.180108 12.9958 -0.180108 13.7545 1.20652L15.9155 5.15589C16.203 5.68124 16.7107 6.05014 17.2992 6.16118L21.723 6.99598C23.2763 7.28908 23.8917 9.1832 22.8074 10.3333L19.7191 13.6089C19.3083 14.0447 19.1143 14.6415 19.1906 15.2355L19.7637 19.7008C19.9649 21.2686 18.3537 22.4392 16.9248 21.7634L12.8551 19.8385C12.3138 19.5824 11.6862 19.5824 11.1449 19.8385L7.07519 21.7634C5.64633 22.4392 4.0351 21.2686 4.23631 19.7008L4.80942 15.2355C4.88566 14.6415 4.69172 14.0447 4.28091 13.6089L1.19262 10.3333C0.108311 9.1832 0.723747 7.28908 2.27697 6.99598L6.70083 6.16118C7.28929 6.05014 7.79703 5.68124 8.08449 5.15589L10.2455 1.20652Z",
                                                      }),
                                                  ],
                                                  -1,
                                              ),
                                          ]),
                                  ),
                              ]))
                            : createCommentVNode("", true),
                        unref(configStore).rating.type === "thumbs"
                            ? (openBlock(),
                              createElementBlock("div", _hoisted_5$1, [
                                  createBaseVNode(
                                      "a",
                                      {
                                          class: "thumb-up",
                                          onClick:
                                              _cache[5] ||
                                              (_cache[5] = ($event) => rate(5)),
                                      },
                                      _cache[14] ||
                                          (_cache[14] = [
                                              createBaseVNode(
                                                  "svg",
                                                  {
                                                      viewBox: "0 0 24 24",
                                                      fill: "none",
                                                      xmlns: "http://www.w3.org/2000/svg",
                                                  },
                                                  [
                                                      createBaseVNode("path", {
                                                          d: "M2.25 10.625V18.875C2.25 19.6344 2.86561 20.25 3.625 20.25C4.38439 20.25 5 19.6344 5 18.875V10.625C5 9.86561 4.38439 9.25 3.625 9.25C2.86561 9.25 2.25 9.86561 2.25 10.625Z",
                                                          stroke: "#0D0E16",
                                                          "stroke-linecap":
                                                              "round",
                                                          "stroke-linejoin":
                                                              "round",
                                                      }),
                                                      createBaseVNode("path", {
                                                          d: "M16.2494 8.25681C16.627 6.93685 16.6261 5.80164 16.2466 4.61039C16.0231 3.90895 15.3391 3.5 14.6178 3.5C14.1127 3.5 13.6322 3.71626 13.4283 4.18885C13.0289 5.11465 12.3546 7.01836 11.3717 8.0236C9.91091 9.51762 8.83793 10.386 7 11.0217V18.1244L7.74938 18.8306C8.30255 19.3518 8.57914 19.6125 8.91804 19.7975C9.02624 19.8565 9.15107 19.9147 9.26593 19.9594C9.62567 20.0997 9.98516 20.1415 10.7041 20.225H10.7041C11.7568 20.3474 13.0779 20.4796 14 20.4976C14.6935 20.5112 15.51 20.4655 16.2986 20.3972C17.5835 20.2859 18.226 20.2303 18.8253 19.8665C19.0096 19.7547 19.2141 19.5959 19.3681 19.445C19.8689 18.9544 20.101 18.291 20.565 16.9644L21.7594 13.5502C22.3845 11.7632 21.1405 9.87067 19.2522 9.73572L17.268 9.59391C16.5951 9.54582 16.1171 8.91828 16.2494 8.25681Z",
                                                          stroke: "#0D0E16",
                                                          "stroke-linecap":
                                                              "round",
                                                          "stroke-linejoin":
                                                              "round",
                                                      }),
                                                  ],
                                                  -1,
                                              ),
                                          ]),
                                  ),
                                  createBaseVNode(
                                      "a",
                                      {
                                          class: "thumb-down",
                                          onClick:
                                              _cache[6] ||
                                              (_cache[6] = ($event) => rate(1)),
                                      },
                                      _cache[15] ||
                                          (_cache[15] = [
                                              createBaseVNode(
                                                  "svg",
                                                  {
                                                      viewBox: "0 0 24 24",
                                                      fill: "none",
                                                      xmlns: "http://www.w3.org/2000/svg",
                                                  },
                                                  [
                                                      createBaseVNode("path", {
                                                          d: "M2.25 13.375V5.125C2.25 4.36561 2.86561 3.75 3.625 3.75C4.38439 3.75 5 4.36561 5 5.125V13.375C5 14.1344 4.38439 14.75 3.625 14.75C2.86561 14.75 2.25 14.1344 2.25 13.375Z",
                                                          stroke: "#0D0E16",
                                                          "stroke-linecap":
                                                              "round",
                                                          "stroke-linejoin":
                                                              "round",
                                                      }),
                                                      createBaseVNode("path", {
                                                          d: "M16.2494 15.7432C16.627 17.0631 16.6261 18.1984 16.2466 19.3896C16.0231 20.0911 15.3391 20.5 14.6178 20.5C14.1127 20.5 13.6322 20.2837 13.4283 19.8111C13.0289 18.8853 12.3546 16.9816 11.3717 15.9764C9.91091 14.4824 8.83793 13.614 7 12.9783V5.87559L7.74938 5.16943C8.30255 4.64817 8.57914 4.38754 8.91804 4.20252C9.02624 4.14345 9.15107 4.08533 9.26593 4.04056C9.62567 3.90032 9.98516 3.85854 10.7041 3.77498H10.7041C11.7568 3.65264 13.0779 3.52041 14 3.50238C14.6935 3.48882 15.51 3.53455 16.2986 3.60281C17.5835 3.71405 18.226 3.76967 18.8253 4.13346C19.0096 4.24533 19.2141 4.40413 19.3681 4.555C19.8689 5.04565 20.101 5.70897 20.565 7.0356L21.7594 10.4498C22.3845 12.2368 21.1405 14.1293 19.2522 14.2643L17.268 14.4061C16.5951 14.4542 16.1171 15.0817 16.2494 15.7432Z",
                                                          stroke: "#0D0E16",
                                                          "stroke-linecap":
                                                              "round",
                                                          "stroke-linejoin":
                                                              "round",
                                                      }),
                                                  ],
                                                  -1,
                                              ),
                                          ]),
                                  ),
                              ]))
                            : createCommentVNode("", true),
                        unref(configStore).rating.type === "review"
                            ? (openBlock(),
                              createElementBlock("div", _hoisted_6$1, [
                                  createBaseVNode(
                                      "a",
                                      {
                                          class: "ysd-write-review-accept",
                                          onClick:
                                              _cache[7] ||
                                              (_cache[7] = ($event) => rate(5)),
                                      },
                                      toDisplayString(
                                          unref(configStore).rating.accept,
                                      ),
                                      1,
                                  ),
                                  createBaseVNode(
                                      "div",
                                      {
                                          class: "ysd-write-review-reject",
                                          onClick:
                                              _cache[8] ||
                                              (_cache[8] = ($event) => rate(1)),
                                      },
                                      [
                                          createBaseVNode(
                                              "span",
                                              null,
                                              toDisplayString(
                                                  unref(configStore).rating
                                                      .reject,
                                              ),
                                              1,
                                          ),
                                      ],
                                  ),
                              ]))
                            : createCommentVNode("", true),
                    ]),
                ])
            );
        };
    },
};
const YsdModalRating = /* @__PURE__ */ _export_sfc(_sfc_main$4, [
    ["__scopeId", "data-v-c6108d26"],
]);
const _hoisted_1$3 = { class: "footer" };
const _hoisted_2$2 = { class: "support" };
const _sfc_main$3 = {
    __name: "YsdFooter",
    setup(__props) {
        const configStore = useConfigStore();
        const openModalContact = () => {
            configStore.isModalContactShow = !configStore.isModalContactShow;
        };
        const contactText = ref("Contact Developer");
        const options = ["Contact Developer", "Request Feature"];
        onMounted(() => {
            contactText.value =
                options[Math.floor(Math.random() * options.length)];
        });
        return (_ctx, _cache) => {
            return (
                openBlock(),
                createElementBlock("div", _hoisted_1$3, [
                    createBaseVNode("div", _hoisted_2$2, [
                        createBaseVNode(
                            "div",
                            {
                                class: "contact",
                                onClick: openModalContact,
                            },
                            [
                                _cache[0] ||
                                    (_cache[0] = createBaseVNode(
                                        "svg",
                                        {
                                            width: "24",
                                            height: "24",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                        },
                                        [
                                            createBaseVNode("path", {
                                                d: "M10.5248 2.32994C10.1025 2.51222 9.19496 3.02435 8.49408 3.4844C7.79319 3.93577 6.90361 4.48262 6.51722 4.68227C6.13084 4.89059 5.24125 5.39404 4.54935 5.81069C3.41715 6.47906 3.17454 6.66135 2.14118 7.68561L1 8.82271V9.57789C1 10.3504 1.41334 13.5881 1.71886 15.1419C1.80871 15.6193 1.91654 16.1835 1.9435 16.4005C2.07828 17.2685 2.56351 18.8136 2.99483 19.725C3.24643 20.2632 3.54295 20.9663 3.65078 21.3048C3.8305 21.8777 3.85745 21.9124 4.17195 21.9819C4.69312 22.1034 9.57236 21.5913 12.4568 21.1225C13.2026 21.001 14.6133 20.81 15.6018 20.6972C20.1126 20.1851 21.7749 19.9767 22.386 19.8465L22.8802 19.7424L22.9341 19.1782C23.0419 18.1018 23.015 15.654 22.8712 14.0135C22.7903 13.102 22.7184 11.4181 22.7095 10.2636L22.7005 8.15434L22.0715 7.45124C20.9662 6.2013 18.9355 4.76907 17.6146 4.30902C17.2911 4.19618 16.8598 3.97917 16.6621 3.82293C16.4644 3.66668 16.087 3.45836 15.8174 3.34552C15.5479 3.24135 15.1165 3.05039 14.856 2.92019C14.2629 2.62506 12.0255 1.99141 11.6031 2.00009C11.4324 2.00009 10.9472 2.15633 10.5248 2.32994ZM19.2949 5.4548C19.5016 5.5416 19.7352 5.70653 19.8161 5.81937C19.9688 6.03637 20.0048 6.55718 19.879 6.75683C19.8251 6.83495 19.843 6.94779 19.9149 7.06064C19.9958 7.18216 20.0497 7.59013 20.0677 8.2151C20.0946 9.0918 20.0767 9.20464 19.9059 9.43033C19.7981 9.56921 19.5645 9.71677 19.3668 9.76885C19.0882 9.83829 18.8366 10.0466 18.1537 10.7931C17.6775 11.3052 17.0844 11.8521 16.8328 12.017C16.5812 12.1733 16.0151 12.668 15.5748 13.1194C15.1345 13.5621 14.5415 14.0829 14.2629 14.2652L13.7597 14.6037L13.1487 14.3346C12.8162 14.1871 12.3849 14.0395 12.1872 14.0135C11.9895 13.9787 11.6481 13.8572 11.4234 13.7357C11.1988 13.6142 10.5338 13.3538 9.94078 13.1454C9.34772 12.9458 8.63785 12.6941 8.36828 12.5986C8.09871 12.5031 7.58652 12.3816 7.23608 12.3382C6.88564 12.2948 6.44534 12.1733 6.24765 12.0778C6.05895 11.991 5.73547 11.8608 5.53778 11.8C5.3401 11.7393 5.03458 11.6004 4.85487 11.4875C4.63921 11.3573 4.49544 11.3226 4.40558 11.3747C4.19891 11.4962 3.84847 11.4615 3.55194 11.2879C3.24643 11.1143 3.06671 10.6542 3.06671 10.09C3.06671 9.87302 2.97686 9.57789 2.83308 9.33484C2.54554 8.84007 2.58148 8.54495 2.97686 8.06754C3.35425 7.60749 3.68673 7.48596 4.91777 7.3384C5.50184 7.26028 6.35548 7.13008 6.79578 7.0346C7.24506 6.94779 8.13465 6.80023 8.77263 6.72211C9.41961 6.64399 10.4889 6.48774 11.1538 6.36622C11.8188 6.25338 13.0948 6.06241 13.9843 5.94089C14.8739 5.81937 15.8264 5.65445 16.096 5.585C17.1653 5.2812 18.7558 5.22044 19.2949 5.4548Z",
                                            }),
                                            createBaseVNode("path", {
                                                d: "M15.8264 8.55363C13.8406 8.84007 12.0704 9.03104 10.8393 9.10916C9.90483 9.16124 9.31178 9.23936 8.90742 9.36956C8.55698 9.48241 7.78421 9.60393 7.00245 9.67337C5.2772 9.82093 4.91777 10.0032 5.07951 10.6369C5.1514 10.9146 5.4659 10.9754 5.97808 10.8105C6.21171 10.7324 6.58012 10.6716 6.81375 10.6716C7.03839 10.6716 7.71232 10.5761 8.31436 10.4633C8.90742 10.3417 9.90483 10.2289 10.5248 10.1942C11.675 10.1421 15.0267 9.78621 15.9163 9.62997C16.1858 9.58657 16.7789 9.50845 17.2192 9.45636C18.0549 9.36956 18.2526 9.2654 18.2526 8.91819C18.2526 8.52758 17.1833 8.36266 15.8264 8.55363Z",
                                            }),
                                            createBaseVNode("path", {
                                                d: "M14.9728 10.498C14.5774 10.5935 14.0293 10.6716 13.7507 10.6716C13.4811 10.6716 13.0229 10.715 12.7353 10.7671C12.4568 10.8105 11.7289 10.906 11.1269 10.9667C10.5248 11.0362 9.9228 11.123 9.78802 11.175C9.42859 11.3139 9.21293 11.6698 9.32076 11.9563C9.49149 12.425 9.78802 12.4423 12.3669 12.1125C12.915 12.0344 13.6609 11.9563 14.0383 11.9302C14.9907 11.8608 16.4374 11.5136 16.6531 11.2966C16.8688 11.0882 16.8957 10.7063 16.698 10.524C16.4914 10.3157 15.7815 10.307 14.9728 10.498Z",
                                            }),
                                        ],
                                        -1,
                                    )),
                                createBaseVNode(
                                    "span",
                                    null,
                                    toDisplayString(contactText.value),
                                    1,
                                ),
                            ],
                        ),
                    ]),
                ])
            );
        };
    },
};
const YsdFooter = /* @__PURE__ */ _export_sfc(_sfc_main$3, [
    ["__scopeId", "data-v-aafd0476"],
]);
const _hoisted_1$2 = { class: "ysd-modal" };
const _sfc_main$2 = {
    __name: "YsdModalContact",
    setup(__props) {
        const configStore = useConfigStore();
        const userStore = useUserStore();
        const closeModalContact = (e) => {
            if (e.target === e.currentTarget) {
                configStore.isModalContactShow =
                    !configStore.isModalContactShow;
            }
        };
        const text = ref(null);
        const textarea = ref(null);
        const autoResize = () => {
            const el = textarea.value;
            if (el) {
                el.style.height = "auto";
                el.style.height = el.scrollHeight + "px";
            }
        };
        const isSendingRequest = ref(false);
        const sendMessage = async () => {
            if (!text.value.trim()) {
                return;
            }
            try {
                isSendingRequest.value = true;
                const url = new URL(
                    `https://antonkhoteev.com/khoteev-api/ysd/message`,
                );
                if (userStore.userId)
                    url.searchParams.append("userId", userStore.userId);
                const res = await fetch(url.toString(), {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        message: text.value.trim(),
                    }),
                });
                if (res.ok) {
                    text.value = null;
                }
            } catch (e) {
            } finally {
                isSendingRequest.value = false;
            }
        };
        return (_ctx, _cache) => {
            return unref(configStore).isModalContactShow
                ? (openBlock(),
                  createElementBlock(
                      "div",
                      {
                          key: 0,
                          class: "ysd-modal-background",
                          onClick: closeModalContact,
                      },
                      [
                          createBaseVNode("div", _hoisted_1$2, [
                              _cache[1] ||
                                  (_cache[1] = createBaseVNode(
                                      "div",
                                      { class: "header" },
                                      "Contact Developer",
                                      -1,
                                  )),
                              withDirectives(
                                  createBaseVNode(
                                      "textarea",
                                      {
                                          placeholder:
                                              "Please type your message here...",
                                          "onUpdate:modelValue":
                                              _cache[0] ||
                                              (_cache[0] = ($event) =>
                                                  (text.value = $event)),
                                          onInput: autoResize,
                                          ref_key: "textarea",
                                          ref: textarea,
                                      },
                                      null,
                                      544,
                                  ),
                                  [[vModelText, text.value]],
                              ),
                              _cache[2] ||
                                  (_cache[2] = createBaseVNode(
                                      "span",
                                      { style: { "font-style": "italic" } },
                                      "Please add your Email or Telegram if you’d like me to reply.",
                                      -1,
                                  )),
                              createBaseVNode(
                                  "button",
                                  {
                                      class: "message-form-button",
                                      onClick: sendMessage,
                                  },
                                  " Send Message ",
                              ),
                          ]),
                      ],
                  ))
                : createCommentVNode("", true);
        };
    },
};
const YsdModalContact = /* @__PURE__ */ _export_sfc(_sfc_main$2, [
    ["__scopeId", "data-v-67f54efb"],
]);
const _hoisted_1$1 = { class: "ysd-modal" };
const _hoisted_2$1 = { class: "benefits" };
const _hoisted_3$1 = { class: "benefit" };
const _hoisted_4$1 = {
    key: 0,
    class: "payment-successful",
};
const _hoisted_5 = { key: 1 };
const _hoisted_6 = {
    key: 1,
    class: "processing",
    disabled: "",
};
const _sfc_main$1 = {
    __name: "YsdModalPaywall",
    setup(__props) {
        const configStore = useConfigStore();
        const userStore = useUserStore();
        const isProcessingPayment = ref(false);
        const isPaymentSuccessful = ref(false);
        const closeModalPaywall = (e) => {
            if (e.target === e.currentTarget) {
                configStore.isModalPaywallShow =
                    !configStore.isModalPaywallShow;
                isProcessingPayment.value = false;
            }
        };
        const pay = async () => {
            isProcessingPayment.value = true;
            const url = new URL(
                `https://antonkhoteev.com/khoteev-api/ysd/payment`,
            );
            if (userStore.userId)
                url.searchParams.append("userId", userStore.userId);
            window.open(url.toString(), "_blank");
            try {
                const hookUrl = new URL(
                    "https://antonkhoteev.com/khoteev-api/ysd/actions/pay",
                );
                if (userStore.userId)
                    hookUrl.searchParams.append("userId", userStore.userId);
                await fetch(hookUrl, { method: "GET" });
            } catch (e) {}
            for (let i = 0; i < 20; i++) {
                await sleep(5e3);
                if (await checkPaidOnce()) {
                    await configStore.init();
                    isProcessingPayment.value = false;
                    isPaymentSuccessful.value = true;
                    return;
                }
            }
            isProcessingPayment.value = false;
        };
        const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
        async function checkPaidOnce() {
            const url = new URL(
                "https://antonkhoteev.com/khoteev-api/ysd/payment/status",
            );
            if (userStore.userId)
                url.searchParams.append("userId", userStore.userId);
            if (userStore.userUuid)
                url.searchParams.append("userUuid", userStore.userUuid);
            try {
                const result = await fetch(url, {
                    method: "GET",
                    cache: "no-store",
                });
                if (!result.ok) {
                    return false;
                }
                const { paid } = await result.json();
                return !!paid;
            } catch {
                return false;
            }
        }
        return (_ctx, _cache) => {
            return unref(configStore).isModalPaywallShow
                ? (openBlock(),
                  createElementBlock(
                      "div",
                      {
                          key: 0,
                          class: "ysd-modal-background",
                          onClick: closeModalPaywall,
                      },
                      [
                          createBaseVNode("div", _hoisted_1$1, [
                              createBaseVNode("div", _hoisted_2$1, [
                                  (openBlock(true),
                                  createElementBlock(
                                      Fragment,
                                      null,
                                      renderList(
                                          unref(configStore).paywall.benefits,
                                          (benefit) => {
                                              return (
                                                  openBlock(),
                                                  createElementBlock(
                                                      "div",
                                                      _hoisted_3$1,
                                                      [
                                                          _cache[0] ||
                                                              (_cache[0] =
                                                                  createBaseVNode(
                                                                      "svg",
                                                                      {
                                                                          width: "22",
                                                                          height: "23",
                                                                          viewBox:
                                                                              "0 0 22 23",
                                                                          fill: "none",
                                                                          xmlns: "http://www.w3.org/2000/svg",
                                                                      },
                                                                      [
                                                                          createBaseVNode(
                                                                              "path",
                                                                              {
                                                                                  d: "M5.17606 0.889585C4.67888 0.966661 3.78996 1.07457 3.20237 1.12082C2.1176 1.21331 2.1176 1.21331 1.45468 2.01491C0.14391 3.55645 -0.112218 4.54303 0.0384456 7.41029C0.189109 10.0772 0.234308 10.6013 0.415104 11.9732C0.490436 12.6053 0.626033 14.1006 0.71643 15.2876C0.852027 17.1991 0.927359 17.6153 1.42455 18.9102C2.28333 21.1917 2.62985 21.5616 4.21182 21.762C4.87474 21.8391 5.59792 21.762 7.51135 21.3766L9.98222 20.8679L14.4268 20.945C18.1783 21.0067 19.007 20.9913 19.6397 20.7909C20.0616 20.6521 20.4383 20.5596 20.5136 20.575C20.5739 20.5905 20.6191 20.5288 20.6191 20.4363C20.6191 20.3438 20.7547 20.1588 20.9204 20.0201C21.508 19.5268 22.1709 15.7963 21.96 14.2393C21.8997 13.8077 21.8394 12.3278 21.8394 10.9712C21.8244 7.79568 21.297 2.72402 20.9053 1.907C20.7396 1.59869 20.5287 1.32122 20.4232 1.3058C20.3328 1.29039 20.0013 1.27497 19.7151 1.24414C19.4288 1.22872 18.9166 1.13623 18.5851 1.04374C17.8167 0.812508 6.4567 0.689186 5.17606 0.889585ZM17.2894 5.915C17.5003 6.16165 17.5757 6.43912 17.5154 6.63952C16.8675 8.98266 16.0389 11.2179 15.1801 13.0215C14.3213 14.7943 13.9447 15.4109 13.1612 16.2279L12.212 17.2453L10.9615 17.1374C10.2685 17.0757 9.51517 16.937 9.30424 16.8137C8.71665 16.5054 6.26084 13.6689 5.19113 12.0657C4.73914 11.372 4.66381 10.3855 5.0254 9.86134C5.26646 9.50679 6.5019 9.04432 7.16482 9.04432C7.58668 9.04432 8.64132 10.1234 9.43984 11.3875C9.74116 11.8808 10.0274 12.2816 10.0726 12.2816C10.148 12.2661 10.2082 12.1891 12.3024 9.09057C13.8241 6.82451 14.6679 5.96125 15.376 5.96125C15.6472 5.96125 16.0088 5.85334 16.1594 5.73002C16.5963 5.39088 16.9429 5.45254 17.2894 5.915Z",
                                                                              },
                                                                          ),
                                                                      ],
                                                                      -1,
                                                                  )),
                                                          createBaseVNode(
                                                              "span",
                                                              null,
                                                              toDisplayString(
                                                                  benefit,
                                                              ),
                                                              1,
                                                          ),
                                                      ],
                                                  )
                                              );
                                          },
                                      ),
                                      256,
                                  )),
                              ]),
                              isPaymentSuccessful.value
                                  ? (openBlock(),
                                    createElementBlock(
                                        "div",
                                        _hoisted_4$1,
                                        " Payment Successful ",
                                    ))
                                  : (openBlock(),
                                    createElementBlock("div", _hoisted_5, [
                                        !isProcessingPayment.value
                                            ? (openBlock(),
                                              createElementBlock(
                                                  "button",
                                                  {
                                                      key: 0,
                                                      class: "pay-button",
                                                      onClick: pay,
                                                  },
                                                  toDisplayString(
                                                      unref(configStore).paywall
                                                          .buttonText,
                                                  ),
                                                  1,
                                              ))
                                            : (openBlock(),
                                              createElementBlock(
                                                  "button",
                                                  _hoisted_6,
                                                  _cache[1] ||
                                                      (_cache[1] = [
                                                          createBaseVNode(
                                                              "span",
                                                              {
                                                                  class: "text-shine-2",
                                                              },
                                                              "Processing...",
                                                              -1,
                                                          ),
                                                      ]),
                                              )),
                                    ])),
                              _cache[2] ||
                                  (_cache[2] = createStaticVNode(
                                      '<div class="secure" data-v-c3002b2c><span data-v-c3002b2c>Payment secured by</span><svg width="64" height="22" viewBox="0 0 64 22" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-c3002b2c><path d="M0 11.7712V11.2435C0.646562 11.2435 1.27843 10.9943 1.73396 10.5252C2.18949 10.0708 2.454 9.45517 2.454 8.81021H2.93892C2.93892 9.45517 3.20342 10.0708 3.65895 10.5252C4.11448 10.9796 4.74635 11.2435 5.39291 11.2435V11.7712C4.74635 11.7712 4.11448 12.0204 3.65895 12.4894C3.20342 12.9439 2.93892 13.5595 2.93892 14.2045H2.454C2.454 13.5595 2.18949 12.9439 1.73396 12.4894C1.26373 12.035 0.646562 11.7712 0 11.7712ZM2.454 7.90139H6.67134C8.72859 7.90139 10.198 9.35257 10.198 11.4927C10.198 13.6328 8.72859 15.084 6.67134 15.084H2.454V21.2111H4.21735V16.6377H6.67134C9.63965 16.6377 11.9761 14.3217 11.9761 11.4927C11.9761 8.64897 9.63965 6.34761 6.67134 6.34761H2.454V7.90139ZM18.3095 6.33295C19.8524 6.33295 21.2337 7.10984 22.1007 8.34114V6.65544H23.864V16.3739H22.1007V14.6735C21.219 15.9048 19.8377 16.6817 18.3095 16.6817C15.3999 16.6817 12.9459 14.4097 12.9459 11.5073C12.9459 8.60499 15.3999 6.33295 18.3095 6.33295ZM18.3095 15.1133C20.5871 15.1133 22.1007 13.5595 22.1007 11.4927C22.1007 9.4112 20.6165 7.87208 18.3095 7.87208C16.2669 7.87208 14.724 9.32325 14.724 11.4927C14.7093 13.6621 16.2669 15.1133 18.3095 15.1133ZM30.3884 6.33295C31.946 6.33295 33.3126 7.10984 34.1796 8.34114V1.78888H35.943V16.3592H34.1796V14.6735C33.3126 15.9048 31.946 16.6817 30.3884 16.6817C27.4789 16.6817 25.0249 14.4097 25.0249 11.5073C25.0396 8.60499 27.4789 6.33295 30.3884 6.33295ZM30.3884 15.1133C32.6808 15.1133 34.1796 13.5742 34.1796 11.4927C34.1796 9.4112 32.6808 7.87208 30.3884 7.87208C28.3459 7.87208 26.8029 9.32325 26.8029 11.4927C26.8029 13.6621 28.3459 15.1133 30.3884 15.1133ZM42.6731 6.33295C44.2307 6.33295 45.5973 7.10984 46.4643 8.34114V1.78888H48.2276V16.3592H46.4643V14.6735C45.5973 15.9048 44.2307 16.6817 42.6731 16.6817C39.7636 16.6817 37.3096 14.4097 37.3096 11.5073C37.3242 8.60499 39.7636 6.33295 42.6731 6.33295ZM42.6731 15.1133C44.9654 15.1133 46.4643 13.5742 46.4643 11.4927C46.4643 9.4112 44.9654 7.87208 42.6731 7.87208C40.6305 7.87208 39.0876 9.32325 39.0876 11.4927C39.0876 13.6621 40.6305 15.1133 42.6731 15.1133ZM49.991 16.3592V1.78888H51.7543V16.3592H49.991ZM58.2934 6.34761C61.6879 6.34761 63.319 8.97145 63.319 12.1816H54.8402C55.1194 14.0725 56.5301 15.2892 58.2934 15.2892C59.5131 15.2892 60.4535 14.7468 61.1589 13.6768H63.0692C62.4079 15.1719 60.6593 16.6524 58.3081 16.6524C55.3398 16.6524 53.0475 14.3071 53.0475 11.5073C53.0328 8.7076 55.3251 6.34761 58.2934 6.34761ZM61.5556 10.8184C61.5556 9.22064 60.189 7.71083 58.2934 7.71083C56.5301 7.71083 55.1194 8.94213 54.8402 10.8184H61.5556Z" data-v-c3002b2c></path></svg></div><div class="no-risk" data-v-c3002b2c><span style="font-weight:bold;" data-v-c3002b2c>No risk!</span><span data-v-c3002b2c>Full refund within 30 days</span><span data-v-c3002b2c>If you don’t like it</span></div><div class="ask-me" data-v-c3002b2c> If for any reason you are unable to purchase this, please contact me and we’ll figure something out. </div>',
                                      3,
                                  )),
                          ]),
                      ],
                  ))
                : createCommentVNode("", true);
        };
    },
};
const YsdModalPaywall = /* @__PURE__ */ _export_sfc(_sfc_main$1, [
    ["__scopeId", "data-v-c3002b2c"],
]);
const _hoisted_1 = { class: "app" };
const _hoisted_2 = { class: "header" };
const _hoisted_3 = { class: "main" };
const _hoisted_4 = {
    key: 0,
    class: "app-loader",
};
const _sfc_main = {
    __name: "AppSidePanel",
    setup(__props) {
        const userStore = useUserStore();
        const configStore = useConfigStore();
        const panelStore = usePanelStore();
        const videoInfoStore = useVideoInfoStore();
        const subtitlesStore = useSubtitlesStore();
        const isAppLoading = ref(true);
        onMounted(async () => {
            try {
                await panelStore.init();
                await userStore.init();
                await configStore.init();
                await videoInfoStore.init();
                isAppLoading.value = false;
            } catch (e) {}
        });
        return (_ctx, _cache) => {
            return (
                openBlock(),
                createElementBlock("div", _hoisted_1, [
                    createBaseVNode("div", _hoisted_2, [
                        createVNode(YsdPanel),
                        createBaseVNode(
                            "div",
                            {
                                class: normalizeClass([
                                    "loader",
                                    {
                                        "loader-active":
                                            unref(subtitlesStore).isDownloading,
                                    },
                                ]),
                            },
                            null,
                            2,
                        ),
                    ]),
                    createBaseVNode("div", _hoisted_3, [
                        createVNode(YsdSubtitles),
                    ]),
                    createVNode(YsdFooter),
                    _cache[1] ||
                        (_cache[1] = createBaseVNode(
                            "div",
                            { class: "noise" },
                            null,
                            -1,
                        )),
                    isAppLoading.value
                        ? (openBlock(),
                          createElementBlock(
                              "div",
                              _hoisted_4,
                              _cache[0] ||
                                  (_cache[0] = [
                                      createBaseVNode(
                                          "div",
                                          { class: "text-shine" },
                                          "Initializing...",
                                          -1,
                                      ),
                                  ]),
                          ))
                        : createCommentVNode("", true),
                    unref(configStore).rating.show
                        ? (openBlock(), createBlock(YsdModalRating, { key: 1 }))
                        : createCommentVNode("", true),
                    createVNode(YsdModalContact),
                    createVNode(YsdModalPaywall),
                ])
            );
        };
    },
};
const mountNode = document.getElementById("app");
const pinia = createPinia();
pinia.use(src_default);
createApp(_sfc_main).use(pinia).mount(mountNode);
