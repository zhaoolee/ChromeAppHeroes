Chrome Better History
==========

Replace the default Chrome history with this better history plugin.