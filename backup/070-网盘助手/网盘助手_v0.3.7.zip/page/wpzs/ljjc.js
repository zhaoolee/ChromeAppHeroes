siteUi.initMenu("wpzs_ljjc");

siteUi.addonReady(function () {
    layui.use(["element", "form"]);
});