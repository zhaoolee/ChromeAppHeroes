siteUi.initMenu("addon_info");

siteUi.addonReady(function () {
    layui.use(["element"]);
});