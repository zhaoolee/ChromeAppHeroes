siteUi.initMenu("wpzs_option");

siteUi.addonReady(function () {
    layui.use(["element", "form"]);
});