var injectConfig = {
    template_list: [
        "/js/gm_template.js"
    ],
    lib_list: [
        "/lib/vue.min.js",
        "/lib/snap.svg.min.js",
        "/lib/jquery.min.js"
    ],
    gm_list: [
        "/gm/wpzs.js"
    ]
};