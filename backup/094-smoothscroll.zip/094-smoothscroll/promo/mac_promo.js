window.addEventListener('DOMContentLoaded', function () {
    document.documentElement.classList.add('hasChromeExt');
});
localStorage.hasChromeExt = 'true';
