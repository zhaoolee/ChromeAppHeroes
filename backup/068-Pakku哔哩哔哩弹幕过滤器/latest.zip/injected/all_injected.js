// (C) 2017-2019 @xmcp. THIS PROJECT IS LICENSED UNDER GPL VERSION 3. SEE `LICENSE.txt`.
var DETAILS_MAX_TIMEDELTA = 10;

var GRAPH_MAX_TIMEDELTA = 5;

var GRAPH_DENSITY_POWER = .8;

function fluctlight_cleanup(root_elem) {
    var old_elems = [].slice.call(root_elem.querySelectorAll(".pakku-fluctlight"));
    if (old_elems.length) {
        console.log("pakku fluctlight: cleanup elems", old_elems);
        old_elems.forEach(function(e) {
            e.parentNode.removeChild(e);
        });
    }
    if (window.graph_observer) window.graph_observer.disconnect();
    if (window.details_observer) window.details_observer.disconnect();
}

function inject_fluctlight_graph(bar_elem, _version, new_elem) {
    var HEIGHT = 600;
    var SEEKBAR_PADDING = _version == 1 ? 6 : 0;
    var WIDTH = bar_elem.clientWidth - SEEKBAR_PADDING;
    bar_elem.dataset["pakku_cache_width"] = -1;
    var canvas_elem = document.createElement("canvas");
    canvas_elem.className = "pakku-fluctlight pakku-fluctlight-graph";
    var ctx = canvas_elem.getContext("2d");
    var progress_elem = _version == 1 ? bar_elem.querySelector(".bilibili-player-video-progress-detail") : bar_elem;
    if (!progress_elem) {
        console.log("! fluctlight cannot find progress_elem");
        return;
    }
    var DURATION = 0;
    function getduration() {
        if (!DURATION) {
            var video_elem = root_elem.querySelector("video");
            var total_time_elem = root_elem.querySelector(".bilibili-player-video-time-total");
            DURATION = (total_time_elem ? parse_time(total_time_elem.textContent) : 0) || (video_elem ? video_elem.duration : 0);
        }
    }
    getduration();
    function drawline(w, h, len, color, alpha) {
        ctx.fillStyle = color;
        ctx.globalAlpha = alpha;
        ctx.fillRect(w, HEIGHT - h, len, h);
    }
    var den_bef = [], den_aft = [];
    function block(time) {
        return Math.round(time * WIDTH / DURATION);
    }
    function recalc() {
        if (bar_elem.dataset["pakku_cache_width"] == WIDTH) return true;
        bar_elem.dataset["pakku_cache_width"] = WIDTH;
        console.log("pakku fluctlight: recalc dispval graph with WIDTH =", WIDTH);
        function dispval(str) {
            return Math.max(Math.sqrt(str.length), 10);
        }
        function apply_dispval(arr) {
            return function(p) {
                var dispv = dispval(p.orig_str);
                arr[Math.max(0, block(p.time))] += dispv;
                arr[block(p.time + GRAPH_MAX_TIMEDELTA) + 1] -= dispv;
            };
        }
        den_bef = zero_array(WIDTH);
        den_aft = zero_array(WIDTH);
        getduration();
        if (!DURATION) {
            console.log("pakku fluctlight: failed to get video duration");
            return;
        }
        D.forEach(function(d) {
            if (!d.peers.length || d.peers[0].mode == "8") return;
            apply_dispval(den_aft)(d.peers[0]);
            d.peers.forEach(apply_dispval(den_bef));
        });
        for (var w = 1; w < WIDTH; w++) {
            den_bef[w] += den_bef[w - 1];
            den_aft[w] += den_aft[w - 1];
        }
        for (var w = WIDTH; w > 0; w--) den_bef[w] = Math.max(den_bef[w], den_bef[w - 1]);
        return true;
    }
    function redraw(hltime) {
        ctx.clearRect(0, 0, WIDTH, HEIGHT);
        canvas_elem.width = WIDTH;
        if (!recalc()) return;
        ctx.beginPath();
        ctx.moveTo(0, HEIGHT);
        for (var w = 0; w < WIDTH; w++) ctx.lineTo(w, HEIGHT - Math.pow(den_bef[w], GRAPH_DENSITY_POWER) / 2);
        ctx.lineTo(WIDTH - 1, HEIGHT);
        ctx.closePath();
        ctx.globalCompositeOperation = "source-over";
        ctx.globalAlpha = .8;
        ctx.fillStyle = "#ff4444";
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(0, HEIGHT);
        for (var w = 0; w < WIDTH; w++) ctx.lineTo(w, HEIGHT - Math.pow(den_aft[w], GRAPH_DENSITY_POWER) / 2);
        ctx.lineTo(WIDTH - 1, HEIGHT);
        ctx.closePath();
        ctx.globalCompositeOperation = "destination-out";
        ctx.globalAlpha = 1;
        ctx.fill();
        ctx.globalCompositeOperation = "source-over";
        ctx.fillStyle = "#7744ff";
        ctx.globalAlpha = .8;
        ctx.fill();
        var hlblock = hltime === undefined ? undefined : block(hltime);
        if (hlblock !== undefined) {
            var GRALENGTH = 100;
            var gra = ctx.createLinearGradient(hlblock - GRALENGTH, 0, hlblock + GRALENGTH, 0);
            gra.addColorStop(0, "rgba(255,255,255,0)");
            gra.addColorStop(.1, "rgba(255,255,255,1)");
            gra.addColorStop(.9, "rgba(255,255,255,1)");
            gra.addColorStop(1, "rgba(255,255,255,0)");
            ctx.globalCompositeOperation = "destination-out";
            ctx.globalAlpha = .5;
            ctx.fillStyle = gra;
            ctx.fillRect(hlblock - GRALENGTH, 0, GRALENGTH * 2, HEIGHT);
            ctx.globalCompositeOperation = "source-over";
            drawline(hlblock, Math.pow(den_bef[hlblock], GRAPH_DENSITY_POWER) / 2, 2, "#cc0000", 1);
            drawline(hlblock, Math.pow(den_aft[hlblock], GRAPH_DENSITY_POWER) / 2, 2, "#0000cc", 1);
        }
    }
    redraw();
    window._pakku_fluctlight_highlight = redraw;
    canvas_elem.height = HEIGHT;
    canvas_elem.style.display = "none";
    if (_version == 1) {
        canvas_elem.style.position = "relative";
        canvas_elem.style.bottom = HEIGHT + 120 + "px";
        bar_elem.appendChild(canvas_elem);
    } else {
        canvas_elem.style.position = "absolute";
        canvas_elem.style.bottom = HEIGHT + 114 + "px";
        canvas_elem.style.marginBottom = -HEIGHT + "px";
        new_elem.insertBefore(canvas_elem, new_elem.firstChild);
    }
    window.graph_observer = new MutationObserver(function(muts) {
        var bar_opened = _version == 1 ? progress_elem.style.display != "none" : progress_elem.classList.contains("bilibili-player-show");
        if (bar_opened && canvas_elem.style.display == "none") {
            canvas_elem.style.display = "initial";
            var width = bar_elem.clientWidth - SEEKBAR_PADDING;
            if (width && width !== WIDTH) {
                WIDTH = width;
                redraw();
            }
        } else if (!bar_opened && canvas_elem.style.display != "none") {
            canvas_elem.style.display = "none";
            canvas_elem.width = 0;
        }
    });
    window.graph_observer.observe(progress_elem, {
        attributes: true,
        attributeFilter: _version == 1 ? [ "style" ] : [ "class" ]
    });
}

function inject_fluctlight_details(bar_elem, _version) {
    var MAX_FLUCT = 15;
    var fluct = document.createElement("div");
    fluct.className = "pakku-fluctlight pakku-fluctlight-fluct";
    var time_elem = bar_elem.querySelector(".bilibili-player-video-progress-detail-time");
    var detail_elem = bar_elem.querySelector(".bilibili-player-video-progress-detail");
    if (!time_elem) {
        console.log("! fluctlight cannot find time_elem");
        return;
    }
    if (!detail_elem) {
        console.log("! fluctlight cannot find detail_elem");
    }
    if (_version == 2) {
        detail_elem = detail_elem.querySelector(".bilibili-player-video-progress-detail-container") || detail_elem;
    }
    function to_dom(danmu) {
        var p = make_p(danmu.text);
        if (danmu.peers.length > 1) p.style.fontWeight = "bold";
        return p;
    }
    function mode_prio(mode) {
        switch (parseInt(mode)) {
          case 4:
            return 1;

          case 5:
            return 2;

          case 7:
            return 3;

          case 1:
            return 4;

          default:
            return 999;
        }
    }
    window.details_observer = new MutationObserver(function(muts) {
        muts.forEach(function(mut) {
            if (mut.addedNodes) {
                var time_str = mut.addedNodes[0].textContent;
                if (time_str === fluct.dataset["current_time"]) return;
                fluct.dataset["current_time"] = time_str;
                fluct.style.height = 0;
                fluct.textContent = "";
                var time = parse_time(time_str);
                var danmus = [];
                for (var i = 0; i < D.length; i++) {
                    var d = D[i];
                    if (d.peers.length && time - d.peers[0].time >= 0 && time - d.peers[0].time <= DETAILS_MAX_TIMEDELTA && d.peers[0].mode != "8") danmus.push(d);
                }
                danmus = danmus.sort(function(a, b) {
                    return a.peers.length - b.peers.length || mode_prio(b.peers[0].mode) - mode_prio(a.peers[0].mode) || time - b - (time - a) || 0;
                }).slice(-MAX_FLUCT);
                danmus.forEach(function(danmu) {
                    fluct.appendChild(to_dom(danmu));
                });
                fluct.style.height = 14 * danmus.length + "px";
                if (_version == 1) {
                    fluct.style.bottom = 72 + 14 * danmus.length + "px";
                } else {
                    fluct.style.bottom = 0;
                }
                if (window._pakku_fluctlight_highlight) window._pakku_fluctlight_highlight(time);
            }
        });
    });
    window.details_observer.observe(time_elem, {
        childList: true
    });
    fluct.dataset["current_time"] = "";
    detail_elem.insertBefore(fluct, detail_elem.firstChild);
}

function make_panel_dom() {
    var dom = make_elem("div", "pakku-panel");
    var dom_title = make_elem("p", "pakku-panel-title");
    var dom_close = make_elem("button", "pakku-panel-close");
    var dom_selectbar = make_elem("div", "pakku-panel-selectbar");
    dom_close.type = "button";
    dom_close.textContent = "×";
    dom_title.appendChild(dom_close);
    dom_title.appendChild(make_elem("span", "pakku-panel-text"));
    dom_selectbar.appendChild(make_elem("span", "pakku-panel-selectbar-left"));
    dom_selectbar.appendChild(make_elem("span", "pakku-panel-selectbar-right"));
    dom_selectbar.appendChild(make_elem("span", "pakku-panel-selectbar-content"));
    dom.appendChild(dom_title);
    dom.appendChild(dom_selectbar);
    dom.appendChild(make_elem("hr", ""));
    dom.appendChild(make_elem("div", "pakku-panel-desc"));
    dom.appendChild(make_elem("hr", "pakku-for-desc"));
    dom.appendChild(make_elem("div", "pakku-panel-peers"));
    dom.appendChild(make_elem("hr", "pakku-for-footer"));
    dom.appendChild(make_elem("div", "pakku-panel-footer text-fix"));
    return dom;
}

var _mem_info = {};

function _load_info(uid, logger, callback) {
    if (_mem_info[uid]) {
        callback(_mem_info[uid]);
        return;
    }
    chrome.runtime.sendMessage(null, {
        type: "xhr_proxy",
        method: "get",
        url: "https://api.bilibili.com/x/web-interface/card?type=json&mid=" + uid
    }, function(res) {
        try {
            if (res.status != 200) throw 1;
            res = JSON.parse(res.responseText);
        } catch (e) {
            logger.innerHTML = "";
            logger.appendChild(make_a(uid + " 个人信息加载失败", "//space.bilibili.com/" + uid));
            throw e;
        }
        callback(_mem_info[uid] = res);
    });
}

function query_uid(uidhash, logger_container) {
    if (logger_container.dataset["_current_hash"] === uidhash) return;
    logger_container.dataset["_current_hash"] = uidhash;
    logger_container.textContent = "";
    var logger = document.createElement("div");
    logger_container.appendChild(logger);
    logger.textContent = uidhash + " 正在获取 UID...";
    chrome.runtime.sendMessage(null, {
        type: "crack_uidhash",
        hash: uidhash
    }, function(uids) {
        if (uids.length) {
            logger.textContent = "";
            uids.forEach(function(uid) {
                var subitem = document.createElement("p");
                subitem.textContent = uid + " 正在加载个人信息...";
                logger.appendChild(subitem);
                _load_info(uid, subitem, function(res) {
                    var nickname, lv, exp, fans, sex;
                    if (!res.data || !res.data.card || !res.data.card.mid || !res.data.card.level_info.current_level) {
                        subitem.parentNode.removeChild(subitem);
                        return;
                    }
                    try {
                        nickname = res.data.card.name;
                        lv = res.data.card.level_info.current_level;
                        exp = res.data.card.level_info.current_exp;
                        fans = res.data.card.fans;
                        sex = {
                            "男": "♂",
                            "女": "♀"
                        }[res.data.card.sex] || "〼";
                    } catch (e) {
                        subitem.textContent = "";
                        subitem.appendChild(make_a(uid + " 个人信息加载失败", "//space.bilibili.com/" + uid));
                        throw e;
                    }
                    subitem.textContent = "";
                    subitem.appendChild(make_a(uid + " Lv" + lv + (exp ? "(" + exp + ") " : " ") + sex + " " + (fans ? +fans + "★ " : "") + nickname, "//space.bilibili.com/" + uid));
                });
            });
        } else {
            logger.textContent = uidhash + " UID 不存在";
        }
    });
}

function inject_panel(list_elem, player_elem) {
    var panel_obj = document.createElement("div");
    panel_obj.style.display = "none";
    panel_obj.appendChild(make_panel_dom());
    panel_obj.querySelector(".pakku-panel-close").addEventListener("click", function() {
        panel_obj.style.display = "none";
    });
    panel_obj.addEventListener("mousewheel", function(e) {
        e.stopPropagation();
    });
    document.addEventListener("click", function(e) {
        if (!panel_obj.contains(e.target) && !list_elem.contains(e.target)) panel_obj.style.display = "none";
    });
    player_elem.appendChild(panel_obj);
    function show_panel(dminfo, floating) {
        var dm_ultralong = dminfo.str.length > 498;
        var dm_str = dminfo.str.replace(/([\r\n\t]|\/n)/g, "").trim();
        var text_container = panel_obj.querySelector(".pakku-panel-text"), selectbar = {
            bar: panel_obj.querySelector(".pakku-panel-selectbar"),
            content: panel_obj.querySelector(".pakku-panel-selectbar-content"),
            left: panel_obj.querySelector(".pakku-panel-selectbar-left"),
            right: panel_obj.querySelector(".pakku-panel-selectbar-right")
        }, desc_container = panel_obj.querySelector(".pakku-panel-desc"), peers_container = panel_obj.querySelector(".pakku-panel-peers"), footer_container = panel_obj.querySelector(".pakku-panel-footer");
        panel_obj.style.display = "block";
        text_container.textContent = "";
        desc_container.innerHTML = "";
        peers_container.innerHTML = "";
        footer_container.textContent = "";
        footer_container.dataset["_current_hash"] = "";
        var infos = [];
        if (typeof dminfo.index == "number" && D[dminfo.index] && (dm_ultralong ? D[dminfo.index].trimmed_text.indexOf(dm_str) === 0 : D[dminfo.index].trimmed_text === dm_str)) {
            infos = [ D[dminfo.index] ];
        } else {
            for (var i = 0; i < D.length; i++) if (dm_ultralong ? D[i].trimmed_text.indexOf(dm_str) === 0 : D[i].trimmed_text === dm_str) infos.push(D[i]);
        }
        console.log("pakku panel: show panel", infos);
        function redraw_ui(idx) {
            if (idx < 0) idx += infos.length; else if (idx >= infos.length) idx -= infos.length;
            var info = infos[idx];
            text_container.textContent = info.text;
            selectbar.bar.style.display = infos.length > 1 ? "block" : "none";
            selectbar.content.textContent = idx + 1 + "/" + infos.length + " [" + format_duration((info.peers[0] || {
                time: 0
            }).time) + "]";
            selectbar.left.onclick = function() {
                redraw_ui(idx - 1);
            };
            selectbar.right.onclick = function() {
                redraw_ui(idx + 1);
            };
            desc_container.textContent = "";
            info.desc.forEach(function(d) {
                desc_container.appendChild(make_p(d));
            });
            peers_container.textContent = "";
            info.peers.forEach(function(p) {
                var self = document.createElement("div");
                var color = proc_rgb(parseInt(p.attr[3]));
                self.style.color = "rgb(" + color[0] + "," + color[1] + "," + color[2] + ")";
                self.classList.add(get_L(color[0], color[1], color[2]) > .5 ? "black" : "white");
                self.appendChild(make_p(proc_mode(p.mode) + " " + p.orig_str));
                self.appendChild(make_p(p.reason + " " + p.attr[6] + " " + p.time.toFixed(2) + "s " + parseInt(p.attr[2]) + "px " + format_datetime(new Date(parseInt(p.attr[4]) * 1e3))));
                (function(self, uidhash, container) {
                    self.addEventListener("mouseover", function() {
                        query_uid(uidhash, container);
                    });
                })(self, p.attr[6], footer_container);
                peers_container.appendChild(self);
            });
            if (info.peers[0]) query_uid(info.peers[0].attr[6], footer_container);
        }
        if (infos.length) {
            redraw_ui(0);
        } else {
            desc_container.appendChild(make_p("找不到弹幕详情"));
        }
        peers_container.scrollTo(0, 0);
        if (floating) panel_obj.classList.add("pakku-floating"); else panel_obj.classList.remove("pakku-floating");
    }
    if (window._panel_listener) {
        list_elem.removeEventListener("click", window._panel_listener);
        console.log("pakku panel: removing previous hook listener");
    }
    list_elem.addEventListener("click", window._panel_listener = function(e) {
        var dm_obj = e.target.parentElement;
        if (dm_obj && dm_obj.classList.contains("danmaku-info-row") && dm_obj.getAttribute("dmno")) show_panel({
            str: dm_obj.querySelector(".danmaku-info-danmaku").title,
            index: parseInt(dm_obj.getAttribute("dmno"))
        });
    });
    var danmaku_stage = player_elem.querySelector(".bilibili-player-video-danmaku");
    if (danmaku_stage) {
        var hover_counter = 0;
        danmaku_stage.addEventListener("mouseover", function(e) {
            hover_counter++;
            if (e.target.className == "bilibili-danmaku") {
                show_panel({
                    str: e.target.textContent
                }, true);
            }
        });
        danmaku_stage.addEventListener("mouseout", function(e) {
            if (--hover_counter < 0) hover_counter = 0;
            if (hover_counter == 0 && panel_obj.classList.contains("pakku-floating")) panel_obj.style.display = "none";
        });
        danmaku_stage.addEventListener("click", function(e) {
            if (e.target.className == "bilibili-danmaku") {
                show_panel({
                    str: e.target.textContent
                });
                e.stopPropagation();
            }
            player_elem.classList.remove("__pakku_pointer_event");
        });
        document.addEventListener("keydown", function(e) {
            if (e.key == "Control" && !e.repeat) {
                hover_counter = 0;
                player_elem.classList.add("__pakku_pointer_event");
            } else if (e.ctrlKey === false) {
                player_elem.classList.remove("__pakku_pointer_event");
                if (panel_obj.classList.contains("pakku-floating")) panel_obj.style.display = "none";
            }
        });
        document.addEventListener("keyup", function(e) {
            if (e.key == "Control") {
                player_elem.classList.remove("__pakku_pointer_event");
                if (panel_obj.classList.contains("pakku-floating")) panel_obj.style.display = "none";
            }
        });
        document.defaultView.addEventListener("blur", function() {
            player_elem.classList.remove("__pakku_pointer_event");
        });
    }
}

if (typeof root_elem == "undefined" || !root_elem || !root_elem.closest("html")) {
    var root_elem = null;
    var isstardust = false;
}

function make_p(s) {
    var elem = document.createElement("p");
    elem.textContent = s;
    return elem;
}

function make_a(s, u) {
    var elem = document.createElement("a");
    elem.href = u;
    elem.target = "_blank";
    elem.textContent = s;
    return elem;
}

function make_elem(tagname, classname) {
    var elem = document.createElement(tagname);
    elem.className = classname;
    return elem;
}

function proc_mode(mode) {
    switch (parseInt(mode)) {
      case 1:
        return "|←";

      case 4:
        return "↓↓";

      case 5:
        return "↑↑";

      case 6:
        return "R→";

      case 7:
        return "**";

      case 8:
        return "[CODE]";

      case 9:
        return "[BAS]";

      default:
        return "[MODE" + mode + "]";
    }
}

function proc_rgb(x) {
    return [ Math.floor(x / 256 / 256), Math.floor(x / 256) % 256, x % 256 ];
}

function get_L(r, g, b) {
    return Math.sqrt(r * r * .241 + g * g * .691 + b * b * .068) / 256;
}

function _fix2(a) {
    return a < 10 ? "0" + a : "" + a;
}

function format_date(x) {
    return _fix2(x.getFullYear() % 100) + "/" + (x.getMonth() + 1) + "/" + x.getDate();
}

function format_datetime(x) {
    return format_date(x) + " " + x.getHours() + ":" + _fix2(x.getMinutes());
}

function format_duration(d) {
    d = d | 0;
    return d < 3600 ? Math.floor(d / 60) + ":" + _fix2(d % 60) : Math.floor(d / 3600) + ":" + _fix2(Math.floor(d % 3600 / 60)) + ":" + _fix2(d % 60);
}

function zero_array(len) {
    var x = new Array(len);
    for (var i = 0; i < len; i++) x[i] = 0;
    return x;
}

function parse_time(time) {
    var res = /(\d+)\:(\d{2})/.exec(time);
    return parseInt(res[1]) * 60 + parseInt(res[2]);
}

function trigger_mouse_event(node, eventType) {
    var clickEvent = document.createEvent("MouseEvents");
    clickEvent.initEvent(eventType, true, true);
    node.dispatchEvent(clickEvent);
}

function reload_danmaku_magic() {
    if (!root_elem) {
        console.log("pakku magic reload: root_elem not found");
        return;
    }
    var date_picker = root_elem.querySelector(".player-auxiliary-danmaku-date-picker-day-content, .bilibili-player-danmaku-date-picker-day-content");
    if (!date_picker) {
        var history_btn = root_elem.querySelector(".player-auxiliary-danmaku-btn-history, .bilibili-player-danmaku-btn-history");
        console.log("pakku magic reload: activating date picker with", history_btn);
        history_btn.click();
        history_btn.click();
        date_picker = root_elem.querySelector(".player-auxiliary-danmaku-date-picker-day-content, .bilibili-player-danmaku-date-picker-day-content");
    }
    var elem = document.createElement("span");
    elem.className = "js-action __pakku_injected";
    elem.dataset["action"] = "changeDay";
    elem.dataset["timestamp"] = 0;
    elem.style.display = "none";
    date_picker.appendChild(elem);
    console.log("pakku magic reload: proceed");
    trigger_mouse_event(elem, "mousedown");
    trigger_mouse_event(elem, "mouseup");
    trigger_mouse_event(elem, "click");
    date_picker.removeChild(elem);
}

console.log("pakku panel: script injected, D.length = " + D.length);

for (var i = 0; i < D.length; i++) {
    D[i].text = D[i].text.replace(/([\r\n\t]|\/n)/g, "");
    D[i].trimmed_text = D[i].text.trim();
}

var try_left = 50;

function try_inject() {
    try {
        root_elem.querySelector("#_okay_i_admit_that_firefox_did_the_right_thing_to_prevent_memory_leak");
    } catch (e) {
        root_elem = null;
    }
    if (!root_elem) root_elem = document.querySelector("div.bilibili-player");
    var pakku_tag_elem = root_elem;
    if (root_elem && !root_elem.querySelector(".bilibili-player-auxiliary-area")) {
        root_elem = root_elem.closest("body");
        isstardust = true;
        console.log("pakku injector: stardust detected");
    }
    if (root_elem) {
        try_left = Math.min(try_left, 15);
        var list_elem = root_elem.querySelector(".bilibili-player-danmaku, .player-auxiliary-danmaku-wrap");
    }
    if (!root_elem || !list_elem) {
        if (--try_left > 0) {
            root_elem = null;
            setTimeout(try_inject, 200);
            return;
        } else if (!root_elem) {
            console.log("pakku injector: root_elem not found");
            return;
        }
    }
    window.postMessage({
        type: "pakku_event_danmaku_loaded",
        pakku_version: chrome.runtime.getManifest().version
    }, "*");
    if (pakku_tag_elem.classList.contains(".__pakku_injected")) {
        console.log("pakku injector: already injected");
        return;
    } else {
        console.log("pakku injector: root_elem", root_elem);
        pakku_tag_elem.classList.add("__pakku_injected");
    }
    if (OPT["TOOLTIP"]) {
        var player_elem = root_elem.querySelector(".bilibili-player-area");
        console.log("pakku injector: list_elem", list_elem, "player_elem", player_elem);
        if (player_elem) inject_panel(list_elem || document.createElement("div"), player_elem);
    }
    if (OPT["AUTO_DISABLE_DANMU"]) {
        var danmu_switch = root_elem.querySelector(".bilibili-player-video-danmaku-switch input[type=checkbox]");
        if (danmu_switch) {
            console.log("pakku injector: danmu_switch", danmu_switch);
            if (danmu_switch.checked) danmu_switch.click();
        } else {
            var disable_elem = root_elem.querySelector(".bilibili-player-video-btn-danmaku");
            console.log("pakku injector: disable_elem LEGACY", disable_elem);
            if (disable_elem && !disable_elem.classList.contains("video-state-danmaku-off")) disable_elem.click();
        }
    }
    if (OPT["AUTO_DANMU_LIST"]) {
        var list_switch_elem = isstardust ? root_elem.querySelector(".danmaku-wrap .bui-collapse-wrap-folded .bui-collapse-header") : root_elem.querySelector(".bilibili-player-filter-btn-list");
        console.log("pakku injector: list_switch_elem", list_switch_elem);
        if (list_switch_elem) {
            list_switch_elem.click();
        }
    }
    if (OPT["FLUCTLIGHT"]) {
        fluctlight_cleanup(root_elem);
        var seekbar_new_elem = root_elem.querySelector(".bilibili-player-video-control-top");
        var seekbar_elem = root_elem.querySelector(".bilibili-player-video-progress");
        if (seekbar_new_elem) {
            console.log("pakku injector: seekbar_new_elem", seekbar_new_elem, "seekbar_elem", seekbar_elem);
            if (seekbar_elem) {
                inject_fluctlight_graph(seekbar_elem, 2, seekbar_new_elem);
                inject_fluctlight_details(seekbar_elem, 2);
            }
        } else {
            console.log("pakku injector: seekbar_elem LEGACY", seekbar_elem);
            if (seekbar_elem) {
                inject_fluctlight_graph(seekbar_elem, 1);
                inject_fluctlight_details(seekbar_elem, 1);
            }
        }
    }
    window.addEventListener("message", function(event) {
        if (event.source != window) return;
        if (event.data.type && event.data.type == "pakku_get_danmaku") return window.postMessage({
            type: "pakku_return_danmaku",
            flag: null,
            resp: D
        }, "*"); else if (event.data.type && event.data.type == "pakku_set_xml_bounce") return chrome.runtime.sendMessage({
            type: "set_xml_bounce",
            result: event.data.xml.toString(),
            cid: OPT.CID
        }, {}, function(resp) {
            if (resp.error === null) reload_danmaku_magic();
        }); else if (event.data.type && event.data.type == "pakku_get_danmaku_with_uid") return chrome.runtime.sendMessage({
            type: "crack_uidhash_batch",
            dinfo: D
        }, function(D) {
            return window.postMessage({
                type: "pakku_return_danmaku",
                flag: "uid",
                resp: D
            }, "*");
        }); else if (event.data.type && event.data.type == "pakku_get_danmaku_with_info") return chrome.runtime.sendMessage({
            type: "load_userinfo_batch",
            dinfo: D,
            silence: !!event.data.silence
        }, function(D) {
            return window.postMessage({
                type: "pakku_return_danmaku",
                flag: "info",
                resp: D
            }, "*");
        });
    }, false);
}

try_inject();