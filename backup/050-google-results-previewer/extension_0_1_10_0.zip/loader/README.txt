A Pen created at CodePen.io. You can find this one at https://codepen.io/jessetrowe/pen/pGqNBR.

 Original shot https://dribbble.com/shots/3369043-loader by Parveen rawat