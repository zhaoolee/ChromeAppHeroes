"use strict";
var frame;
var iframeLoadingTimer;
var WAITING_FOR_IFRAME_TIMEOUT = 1000;
var SHARE_LINK_1 = 'https://www.linkedin.com/shareArticle?mini=true&url=www.jesserowe.me&title=Title&summary=Summary&source=www.jesserowe.me';
var SHARE_LINK_2 = 'https://www.buymeacoffee.com/urlpreview';
var Preloader_IMG = 'https://cdn.dribbble.com/users/421466/screenshots/2390664/orbit-400px.gif'
var Delay_To_Hide = 2000

var HOVER_TIMEOUT = 500; // user hover on link and upon 500 ms the preview should be displayed
var LOADING_MESSAGE = ''; // 'Spinning that up for you...';
var viewportData = {
  previewFrame: {}
};



var AdsList;

var AdsCounter = 0;

function randomIntFromInterval(min, max) // min and max included
{
  return Math.floor(Math.random() * (max - min + 1) + min);
}



chrome.runtime.sendMessage({
  type: "_trackPageview",
  url: window.location.href
})






chrome.runtime.sendMessage({
  type: "getAds"
}, function (Rsp) {


  if (Rsp.message != "good") {
    alert("Something went wrong!!")
  } else {


    AdsList = Rsp.fullobj || [];

    AdsCounter = randomIntFromInterval(0, AdsList.length - 1)
  }


});





setInterval(function () {

  if (frame.querySelector("#AdsBanner") == null)
    return;

  if (AdsList == null) {
    return;
  }

  var old = AdsCounter;
  AdsCounter++;
  if (AdsCounter == AdsList.length)
    AdsCounter = 0;

  if (AdsCounter == old) {
    return;
  }



  $('#AdsBanner').animate({
    'opacity': 0
  }, 400, function () {

    this.querySelectorAll("a")[0].innerText = AdsList[AdsCounter].text

    this.querySelectorAll("a")[1].innerText = AdsList[AdsCounter].urlText

    this.querySelectorAll("a")[1].href = AdsList[AdsCounter].url

    $(this).animate({
      'opacity': 1
    }, 400);

  });



}, 15000)
var font = new FontFace('google-sans', 'url("' + chrome.extension.getURL('public/fonts/google-sans-regular.ttf') + '")', {});
document.fonts.add(font);
const copyToClipboard = str => {
  const el = document.createElement('textarea');
  el.value = str;
  el.setAttribute('readonly', '');
  el.style.position = 'absolute';
  el.style.left = '-9999px';
  document.body.appendChild(el);
  el.select();
  document.execCommand('copy');
  document.body.removeChild(el);
};

function magicSize(e) {
  var t = document.getElementById("center_col"),
    r = t.offsetLeft + t.offsetWidth,
    i = document.getElementById("searchform"),
    R = i.offsetTop + i.offsetHeight,
    n = document.getElementById("top_nav").offsetHeight;
  if (viewportData.previewFrame.leftElementsPx = r, viewportData.previewFrame.topElementsPx = n + R, viewportData.previewFrame.left = Math.round(viewportData.previewFrame.leftElementsPx / window.innerWidth * 100), viewportData.previewFrame.top = Math.round(viewportData.previewFrame.topElementsPx / window.innerHeight * 100), viewportData.previewFrame.left <= 63) {
    viewportData.previewFrame.width = window.innerWidth - viewportData.previewFrame.leftElementsPx + 70, viewportData.previewFrame.height = window.innerHeight - viewportData.previewFrame.topElementsPx + 100, viewportData.previewFrame.left = Math.round(viewportData.previewFrame.leftElementsPx / window.innerWidth * 100) + 2, viewportData.previewFrame.top = Math.round(viewportData.previewFrame.topElementsPx / window.innerHeight * 100) + 4, viewportData.previewFrame.left += "%", viewportData.previewFrame.top += "%";
    var E = .2,
      o = .15
  } else if (viewportData.previewFrame.left >= 85) console.error("No space for display image");
  else {
    viewportData.previewFrame.width = (window.innerWidth - viewportData.previewFrame.leftElementsPx) / 1.15, viewportData.previewFrame.height = (window.innerHeight - viewportData.previewFrame.topElementsPx) / 1.8, viewportData.previewFrame.left = Math.round(viewportData.previewFrame.leftElementsPx / window.innerWidth * 100) + 2, viewportData.previewFrame.top = Math.round(viewportData.previewFrame.topElementsPx / window.innerHeight * 100) + 10;
    E = 0, o = 0;
    viewportData.previewFrame.left += "%", viewportData.previewFrame.top += "%"
  }
  return e.width = viewportData.previewFrame.width - Math.round(viewportData.previewFrame.width * o), e.height = viewportData.previewFrame.height - Math.round(viewportData.previewFrame.height * E), e

}

function flicker() {
  console.log('flicker');
  frame.querySelector('iframe').style.opacity = '0.3';
  frame.querySelector('iframe').style.transition = 'all 0.0s linear';
  setTimeout(function () {
    frame.querySelector('iframe').style.opacity = '0.3';
    frame.querySelector('iframe').style.transition = 'all 0.1s linear';
    setTimeout(function () {
      frame.querySelector('iframe').style.opacity = '1';
    }, 100);
  }, 50)
}

function createFrame() {
  frame = document.createElement('div');
  frame.style = 'transition: width 0.1s linear; background-color:white; position: fixed; box-shadow: 0px 10px 20px 0 rgba(0,0,0,0.16), 0 0 0 1px rgba(0,0,0,0.08); z-index: 9000;';
  frame.setAttribute('id', 'search-preview');
  setSize();
  frame.style.display = 'none';


  var frameContainer = document.createElement('div');
  frameContainer.classList.add('frame-container')
  frameContainer.appendChild(frame);
  document.body.appendChild(frameContainer);
  var initial = {
    frameWidth: '',
    frameTop: '',
    page: ''
  };


  var frameContainer = document.createElement('div');

  function scale() {
    if (frame.getAttribute('scaled')) {

      return
    }
    initial.frameWidth = frame.style.width;
    initial.frameTop = frame.style.top;
    initial.page = document.getElementById('center_col').style.marginLeft;
    frame.style.width = '70%'; //(parseInt(frame.style.width, 10) + 10) + '%';
    frame.style.top = '10%';
    frame.setAttribute('scaled', 'true');
    frameContainer.classList.add('scaled');
    flicker(true);
  }


  frame.addEventListener('mouseenter', function () {


    var btnAction = frame.querySelectorAll(".btnAction")
    btnAction.forEach(e => {

      e.style.padding = "6px"
    })

    chrome.runtime.sendMessage({
      type: "_trackHoverEvent"
    })

    frame.style.right = '0px';
    scale();
  });

  frame.addEventListener('mouseleave', function (e) {
    if (e.toElement != null && e.toElement.className != "AdsBanner" & e.toElement.className != "btnAction" && e.toElement != frame.querySelector("iframe")) {
      frame.style.width = "50%";
      frame.style.top = '9%';
      frame.setAttribute('scaled', '');

      frame.style.right = '-20px';
      frameContainer.classList.remove('scaled');
      var btnAction = frame.querySelectorAll(".btnAction")
      btnAction.forEach(e => {

        e.style.padding = "0px"
      })
      // frame.querySelector("iframe").setAttribute("src",frame.querySelector("iframe").src)
      //flicker(true);
    }
    var a = frame.getAttribute("frame")
    setTimeout(function(){
      if(frame.getAttribute("scaled")!="true" && frame.getAttribute("loaded")=="true" && a==frame.getAttribute("frame") ){
        hideFrame()
      }
    },Delay_To_Hide)
  });
}

function setSize() {
  var size = {};
  magicSize(size);
  frame.style.top = "9%";
  frame.style.right = '-20px';
  frame.style.bottom = '0';
  frame.style.width = "50%";
}

function createLoader() {
  var loader = document.createElement('div');
  loader.classList.add('lds-loading-element');
  var spinning = document.createElement('div');
  spinning.classList.add('container');
    var item = document.createElement('img');
    item.src=Preloader_IMG
    spinning.appendChild(item);
  var loadingMessage = document.createElement('div');
  loadingMessage.classList.add('lds-loading-message');
  loadingMessage.innerHTML = '<a target="_blank" href="' + SHARE_LINK_1 + '">Help your friend\'s</a> search game out... or <a target="_blank" href="' + SHARE_LINK_2 + '">help us out</a>.';
  loader.appendChild(loadingMessage);
  loader.appendChild(spinning);
  return loader;
}



function showFrame(url) {
  setSize();
  url = url.replace(/^http:/, "https:"); // google goes on https and won't show pages from http

  if (frame.getAttribute('frame') === url) {
    return;
  }

  var btnAction = frame.querySelectorAll(".btnAction")
  btnAction.forEach(e => e.remove())

  iframeLoadingTimer = function () {
    if (frame.getAttribute('loaded') !== 'true') {

     frameOnLoad();





    }
  }

  function frameOnLoad() {


    frame.setAttribute('loaded', 'true');






    try {

      frame.removeChild(loader);
      var btnAction = frame.querySelectorAll(".btnAction")

      if (btnAction.length == 0) {


        frame.appendChild(buttonOpenUrl);
        frame.appendChild(buttonCopyUrl);


        frame.appendChild(buttonInfo);
      }
      btnAction = frame.querySelectorAll(".btnAction")
      if (btnAction.length != 0) {

        btnAction[0].style.display = 'block'
        btnAction[1].style.display = 'block'
        btnAction[2].style.display = 'block'

      }


      if (frame.querySelector("iframe").src.indexOf("error/Error.html") != -1) {
        btnAction = frame.querySelectorAll(".btnAction")

        if (btnAction.length == 0) {


          frame.appendChild(buttonOpenUrl);
          frame.appendChild(buttonCopyUrl);


          frame.appendChild(buttonInfo);
        }
        btnAction = frame.querySelectorAll(".btnAction")
        if (btnAction.length != 0) {

          btnAction[0].style.display = 'none'
          btnAction[1].style.display = 'none'
          btnAction[2].style.display = 'block'

        }
      }
    } catch (e) {

    }



  }
  frame.setAttribute('loaded', '');
  frame.style.display = 'block';
  frame.setAttribute('frame', url);
  var loader = frame.querySelector('.lds-loading-element') || createLoader();
  frame.appendChild(loader);





  var buttonOpenUrl = document.createElement('div');
  buttonOpenUrl.setAttribute("class", "btnAction")
  buttonOpenUrl.setAttribute("style", "     border: 5px solid rgb(45, 140, 255);   opacity: 0.75;  cursor:pointer;  position: absolute;  bottom: 5px;  right: 140px;  background-color: rgb(45, 140, 255);  width: 30px;  height: 30px;  border-radius: 8px;  padding: 0px;  z-index: 9999;  background-size: cover;")
  buttonOpenUrl.setAttribute("title", "Open Link")
  buttonOpenUrl.style.backgroundImage = "url('" + chrome.extension.getURL('assets/click.png') + "')"
  buttonOpenUrl.addEventListener("click", function () {
    buttonOpenUrl.style.backgroundColor = '#3cba54'
    buttonOpenUrl.style.borderColor = '#3cba54'
    setTimeout(function () {

      buttonOpenUrl.style.backgroundColor = 'rgb(45, 140, 255)'
      buttonOpenUrl.style.borderColor = 'rgb(45, 140, 255)'

      window.location.href = frame.querySelector("iframe").src;
    }, 300)

  })

  buttonOpenUrl.addEventListener("mouseenter", function () {
    buttonOpenUrl.style.opacity = 1

  })

  buttonOpenUrl.addEventListener("mouseleave", function () {
    buttonOpenUrl.style.opacity = 0.75

  })
  buttonOpenUrl.style.display = "none"

  var buttonCopyUrl = document.createElement('div');
  buttonCopyUrl.setAttribute("class", "btnAction")

  buttonCopyUrl.setAttribute("style", "      border: 5px solid rgb(45, 140, 255);  opacity: 0.75;  cursor:pointer;  position: absolute;  bottom: 5px;  right: 80px;  background-color: rgb(45, 140, 255);  width: 30px;  height: 30px;  border-radius: 8px;  padding: 0px;  z-index: 9999;  background-size: cover;")
  buttonCopyUrl.setAttribute("title", "Copy Link")
  buttonCopyUrl.style.backgroundImage = "url('" + chrome.extension.getURL('assets/copy.png') + "')"
  buttonCopyUrl.addEventListener("click", function () {
    buttonCopyUrl.style.backgroundColor = '#3cba54'
    buttonCopyUrl.style.borderColor = '#3cba54'

    setTimeout(function () {

      buttonCopyUrl.style.backgroundColor = 'rgb(45, 140, 255)'
      buttonCopyUrl.style.borderColor = 'rgb(45, 140, 255)'

      buttonCopyUrl.style.backgroundImage = "url('" + chrome.extension.getURL('assets/success.png') + "')"
      buttonCopyUrl.style.backgroundSize = "cover"
      copyToClipboard(frame.querySelector("iframe").src)

    }, 300)

  })


  buttonCopyUrl.addEventListener("mouseenter", function () {
    buttonCopyUrl.style.opacity = 1

  })

  buttonCopyUrl.addEventListener("mouseleave", function () {
    buttonCopyUrl.style.opacity = 0.75

  })
  buttonCopyUrl.style.display = "none"


  var buttonInfo = document.createElement('div');
  buttonInfo.setAttribute("class", "btnAction")

  buttonInfo.setAttribute("style", "     border: 5px solid rgb(45, 140, 255);  opacity: 0.75;  cursor:pointer;  position: absolute;  bottom: 5px;  right: 20px;  background-color: rgb(45, 140, 255);  width: 30px;  height: 30px;  border-radius: 8px;  padding: 0px;  z-index: 9999;  background-size: cover;")
  buttonInfo.style.backgroundImage = "url('" + chrome.extension.getURL('assets/information.png') + "')"
  buttonInfo.setAttribute("title", "About Us")
  buttonInfo.addEventListener("click", function () {
    buttonInfo.style.backgroundColor = '#3cba54'
    buttonInfo.style.borderColor = '#3cba54'

    setTimeout(function () {

      buttonInfo.style.backgroundColor = 'rgb(45, 140, 255)'
      buttonInfo.style.borderColor = 'rgb(45, 140, 255)'

      window.open("https://resultspreviewer.com/#about", '_blank');

    }, 300)
  })


  buttonInfo.addEventListener("mouseenter", function () {
    buttonInfo.style.opacity = 1

  })

  buttonInfo.addEventListener("mouseleave", function () {
    buttonInfo.style.opacity = 0.75

  })
  buttonInfo.style.display = "none"








  var iframe = frame.querySelector('iframe') || document.createElement('iframe');
  iframe.sandbox = 'allow-scripts allow-forms allow-same-origin';

  iframe.onload = iframeLoadingTimer;


  function iframeOnError() {

    iframe.src = chrome.extension.getURL('error/Error.html');
    var btnAction = frame.querySelectorAll(".btnAction")

    if (btnAction.length == 0) {


      frame.appendChild(buttonOpenUrl);
      frame.appendChild(buttonCopyUrl);


      frame.appendChild(buttonInfo);
    }
    btnAction = frame.querySelectorAll(".btnAction")
    if (btnAction.length != 0) {
      btnAction[0].style.display = 'none'
      btnAction[1].style.display = 'none'


    }

  }
  iframe.onerror = iframeOnError
  iframe.style.border = 'none';
  iframe.style.display = 'block';
  iframe.scrolling = "yes";
  if (url.indexOf("chrome.google.com/webstore/") != -1 || url.indexOf("play.google.com/store/") != -1) {
    iframe.src = chrome.extension.getURL('error/Error.html');;

    var btnAction = frame.querySelectorAll(".btnAction")

    if (btnAction.length == 0) {


      frame.appendChild(buttonOpenUrl);
      frame.appendChild(buttonCopyUrl);


      frame.appendChild(buttonInfo);
    }
    btnAction = frame.querySelectorAll(".btnAction")
    if (btnAction.length != 0) {
      btnAction[0].style.display = 'none'
      btnAction[1].style.display = 'none'
    }
  } else {

    $.ajax({
      url: url,
      type: 'GET',
      complete: function (e, xhr, settings) {
        if (e.status != 200) {


          iframeOnError();
        }
      }
    });

    iframe.src = url;
  }
  iframe.style.width = '100%';
  iframe.style.height = '100%';
  iframe.style.minHeight = '100%';
  iframe.style.minWidth = '100%';
  frame.appendChild(iframe);


  if (frame.getAttribute("hasBanner") != "Yes") {


    var AdBanner = document.createElement('div');
    AdBanner.setAttribute("style", "width: 100%;padding: 8px;background-color: #d0caca;text-align: center;")
    AdBanner.id = "AdsBanner";
    AdBanner.className = "AdsBanner"
    var AdInnerLink = document.createElement('a');
    AdInnerLink.className = "AdsBanner"
    AdInnerLink.setAttribute("style", "color:black;font-weight: bold;margin-left: 10px;")
    AdInnerLink.innerText = AdsList[AdsCounter].urlText
    AdInnerLink.href = AdsList[AdsCounter].url
    AdInnerLink.target = "_blank"

    var AdInnerText = document.createElement('a');
    AdInnerText.className = "AdsBanner"
    AdInnerText.innerText = AdsList[AdsCounter].text

    AdBanner.appendChild(AdInnerText)

    AdBanner.appendChild(AdInnerLink)

    frame.prepend(AdBanner)
    frame.setAttribute("hasBanner", "Yes")

  }





}

function hideFrame() {
  frame.innerHTML = '';
  frame.setAttribute("hasBanner", "No")
  frame.setAttribute('frame', '');
  frame.style.display = 'none';
  removeHighLightLink();
}

function getSearchResult() {
  var all = [];
  try {
    all = [].slice.call(document.getElementById('search').getElementsByTagName('a'))
  } catch (e) {
    return
  }
  return all.filter(function (item) {
    var res = false;
    var hasClassName = item.className !== '';
    var wrongParent = item.parentNode.className === '_Ivo'
    res = !hasClassName && !wrongParent

    if (res == false) {

      if (item.className === "l")
        res = true;
    }

    if (res == false) {
      if (item.parentNode.className == "osl" && item.className === "fl")
        res = true;


    }
    if (res == false) {
      if (item.parentNode.parentNode.parentNode.className == "P1usbc" && item.className === "fl")
        res = true;


    }



    return res;
  })
}

function highlightLink(el) {
  el.classList.add('highlighted-link');

}

function removeHighLightLink() {
  $('.highlighted-link').removeClass('highlighted-link');
}

$(window).ready(function () {
  createFrame();
  getSearchResult().forEach(function (el) {

    var timer = null;

    el.addEventListener('mouseenter', function () {

      el.setAttribute('timer', Date.now());

      chrome.storage.local.get(["Status"], function (data) {

        if (data.Status == false)
          return
          setTimeout(function () {
                
            if (el.getAttribute('timer')!=null) {
                showFrame(el.href);
                removeHighLightLink();
                highlightLink(el);
            }
          }, HOVER_TIMEOUT);
        

      })
    });
    el.addEventListener('mouseleave', function () {
      el.removeAttribute('timer');
      var a = frame.getAttribute("frame")
      setTimeout(function(){
        
        if (el.getAttribute('timer')==null && a ==  frame.getAttribute("frame") && frame.getAttribute("loaded") == "true"  && frame.getAttribute("scaled")!="true") {
          hideFrame()
        }
      },Delay_To_Hide)
    });
  });
}), $(document).keyup(function (e) {
  console.log('keyup', e.key);
  "Escape" === e.key && hideFrame()
}), $(document).click(function (e) {
  if (e.toElement != null && e.toElement.className != "btnAction" && e.toElement != frame.querySelector("iframe"))
    hideFrame()
});


var css = '.highlighted-link { position:relative; }',
  head = document.head || document.getElementsByTagName('head')[0],
  style = document.createElement('style');

head.appendChild(style);

style.type = 'text/css';
if (style.styleSheet) {
  // This is required for IE8 and below.
  style.styleSheet.cssText = css;
} else {
  style.appendChild(document.createTextNode(css));
}