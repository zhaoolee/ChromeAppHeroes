var myserver = "http://52.14.71.206:5000/"

var LinkOnInstall = "https://resultspreviewer.com/#about"
var LinkOnUpdate  = "https://resultspreviewer.com/#update"

chrome.webRequest.onHeadersReceived.addListener(function (e) {
  var r = e.responseHeaders;
  console.log(e);
  for (var s = r.length - 1; s >= 0; --s) {
    var o = r[s].name.toLowerCase();
    "x-frame-options" == o || "frame-options" == o || "content-security-policy" == o ? r.splice(s, 1) : "location" == o && (r[s].value = r[s].value.replace(/^http:/, "https:"))
  }
  return {
    responseHeaders: r
  }
}, {
  urls: ["*://*/*"],
  types: ["sub_frame"]
}, ["blocking", "responseHeaders"]);

var TrackerID='UA-xxxx-9';

var _gaq = _gaq || [];
_gaq.push(['_setAccount', TrackerID]);

(function() {
  var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

chrome.runtime.onInstalled.addListener(function (details) {
  if (details.reason == "install") {
    chrome.tabs.create({url:LinkOnInstall})
  } else if(details.reason == "update") {
    chrome.tabs.create({url:LinkOnUpdate})
    
  }
});


chrome.runtime.onMessage.addListener(function (request, sender,sendResponse) {
  if (request.type == "getAds") {



    fetch(myserver + "gettable/", {
      "headers": {
        "Content-Type": "application/json"
      },
      "method": "GET",
      "mode": "cors"
    }).then(function (response) {
      return response.json()
    }).then(function (Rsp) {

      sendResponse(Rsp);


    });
  }else if(request.type == "_trackPageview"){
    _gaq.push(function() {

      var pageTracker = _gat._getTracker(TrackerID);    
      pageTracker._setDomainName("none");
      pageTracker._setAllowLinker(true);    
      pageTracker._trackPageview(request.url);

    })
    
  }else if(request.type =="_trackHoverEvent" ){

    _gaq.push(['_trackEvent', "iframe", 'hover']);
  }else if(request.type =="UpdateIcon" ){
    updateIcon()
  }else if(request.type =="openUrl" ){
   chrome.tabs.create({url:request.Url}) 
  }


  return true;
});

function updateIcon(){
  chrome.storage.local.get(["Status"],function(data){

    var Status= data.Status == null ? false : data.Status

    Status = !Status
    if(Status==true){

      chrome.browserAction.setBadgeText({text: "ON"})
      
      chrome.browserAction.setBadgeBackgroundColor({color: "green"});

    }else{

      chrome.browserAction.setBadgeText({text: "OFF"})
      
      chrome.browserAction.setBadgeBackgroundColor({color: "red"});



    }
    chrome.browserAction.setIcon(
      
      {path:`icon${Status}1.png`})

    chrome.storage.local.set({Status:Status})
  })
}

updateIcon();


chrome.commands.onCommand.addListener(function(command) {
  if(command =="toggle-Status"){
    updateIcon()
  }
});