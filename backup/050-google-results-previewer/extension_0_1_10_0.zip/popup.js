var HowToUse="https://resultspreviewer.com/#about"
var Share="https://resultspreviewer.com/#share"
var BuyCoffee="https://resultspreviewer.com/#coffee"

chrome.storage.local.get(["Status"],function(data){

    var Status= data.Status == null ? false : data.Status

    if(Status==false){
            
        document.querySelector("#TurnOff").style.display="none"
        document.querySelector("#TurnOn").style.display="block"
    }else{
            
        document.querySelector("#TurnOff").style.display="block"
        document.querySelector("#TurnOn").style.display="none"
    }

})

function OpenUrl(url){

    chrome.runtime.sendMessage({type:"openUrl",Url:url})

}

function Turn(){

    chrome.runtime.sendMessage({type:"UpdateIcon"})
    
}
document.querySelector("#TurnOn").addEventListener("click",function(){
    Turn()
    document.querySelector("#TurnOff").style.display="block"
    document.querySelector("#TurnOn").style.display="none"
})
document.querySelector("#TurnOff").addEventListener("click",function(){
    Turn()
    document.querySelector("#TurnOff").style.display="none"
    document.querySelector("#TurnOn").style.display="block"

})
document.querySelector("#HowToUse").addEventListener("click",function(){
    OpenUrl(HowToUse)
    
})

document.querySelector("#Share").addEventListener("click",function(){
    OpenUrl(Share)

    
})

document.querySelector("#BuyCoffee").addEventListener("click",function(){

    OpenUrl(BuyCoffee)
    
})
