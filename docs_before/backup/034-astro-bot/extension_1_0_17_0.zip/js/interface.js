function removeLoader() {
  var loader = document.getElementById("loader")
  loader.style.opacity = 0.0
  loader.style.display = 'none'
}

function hideMenu() {
  logoState = false
  var _ = anime ({
    targets: ['.menu-item'],
    opacity: 0.0,
    duration: 500
  })
}

function showMenu() {
  logoState = true
  var _ = anime ({
    targets: ['.menu-item'],
    opacity: 1.0,
    duration: 500
  })
}

function rotateLogo() {
  let direction = logoState ? 0 : 180
  let complete = logoState ? hideMenu : showMenu
  var _ = anime ({
    targets: ['.logo'],
    rotate: direction,
    duration: 800,
    elasticity: 10,
    easing: 'easeOutElastic',
    complete: complete
  });
}

function showInterface( ) {
  if (!astroDOM) return
  Object.keys(astroDOM).forEach( key => {
    astroDOM[ key ].style.opacity = 1.0
    astroDOM[ key ].style.display = 'flex'
  } )
}

function displayCorrectMessage() {
  let message = "You're awesome! Another correct answer in the bag."
  replaceHeaderMessage( message )
}

function displayIncorrectMessage() {
  let message = "Uh oh, not quite! I'm sure you'll get the next one."
  replaceHeaderMessage( message )
}

function replaceHeaderMessage(message) {
  let header_message = document.getElementById('header-message')
  let _ = anime({
    targets: header_message,
    opacity: 0.0,
    duration: 200,
    complete: () => {
      header_message.innerHTML = message
      let _ = anime({
        targets: header_message,
        opacity: 1.0,
        scale: 2.0,
        duration: 1000
      })
    }
  })
}
