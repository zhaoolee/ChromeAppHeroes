function guid() {
  var S4 = function() {
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
  };
  return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}

function AstroBot(args) {

  if (!chrome || !chrome.storage) return

  this.state = {
    uid: guid(),
    tabCount: 0,
    correctCount: 0,
    incorrectCount: 0,
    storyCount: 0,
    questionIndex: 0,
    articleIndex: 0,
    skipArticle: false
  }

  this.articles = []
  this.questionIndices = []

  this.getLocalState = () => {
    return new Promise((resolve, reject) =>
      chrome.storage.sync.get('state', result => resolve(result))
    )
  }

  this.setLocalState = (data) => {
    return new Promise((resolve, reject) =>
      chrome.storage.sync.set({
        state: data
      }, () => resolve()))
  }

  this.getLocalQuestions = () => {
    return new Promise((resolve, reject) =>
      chrome.storage.sync.get('questionIndices', result => resolve(result))
    )
  }

  this.setLocalQuestions = (data) => {
    return new Promise((resolve, reject) =>
      chrome.storage.sync.set({
        questionIndices: data
      }, () => resolve()))
  }

  this.setRemoteTimestamp = (key, value) => {
    let _this = this
    return new Promise(function(resolve, reject) {
      if (key === 'tabCount') {
        resolve()
        return
      }

      let timestamp = new Date().getTime()
      let questionKey = _this.questionIndices[_this.state.questionIndex]

      firebase.database().ref(`astro-bot/stats/timestamps/${_this.state.uid}`)
        .push({
          timestamp: timestamp,
          key: key,
          value: value,
          question: questionKey
        })
        .then(() => resolve())
        .catch(error => reject(error))
    });
  }

  this.setRemoteState = (data) => {
    firebase.database().ref(`astro-bot/stats/${this.state.uid}`)
      .set(this.state)
      .then(() => {})
      .catch(error => console.log(error))
  }

  this.updateField = (key, value) => {
    if (!!key && !!value) {
      this.setRemoteTimestamp(key, value).then(() => {
        this.state[key] = value
        this.setLocalState(this.state).then(() => {
          this.setRemoteState(this.state)
        })
      }).catch(error => console.log(error))
    }
  }

  this.getRemoteQuestions = () => {
    return new Promise(function(resolve, reject) {
      firebase.database()
        .ref(constants.DB_QUESTION_PATH)
        .once('value')
        .then(function(snapshot) {
          resolve(snapshot.val())
        }).catch(function(error) {
          reject(error)
        })
    })
  }

  this.retrieveStory = (id) => {
    return new Promise(function(resolve, reject) {
      fetch("https://hacker-news.firebaseio.com/v0/item/" + id + ".json")
        .then((resp) => resp.json())
        .then(data => resolve(data)).catch(error => reject(error))
    });
  }

  this.retrieveHNTopStories = () => {
    var URL = "https://hacker-news.firebaseio.com/v0/topstories.json"
    let _this = this
    return new Promise(function(resolve, reject) {
      fetch(URL).then((resp) => resp.json()).then(function(data) {
        _this.articles = data
        resolve()
      }).catch(error => reject(error))
    });
  }

  this.refresh = () => {
    this.setLocalState({})
    this.setLocalQuestions({})
  }

  this.retrieveQuestions = () => {
    let _this = this
    return new Promise(function(resolve, reject) {
      _this.getLocalQuestions().then((result) => {
        if (!!result && !!result.questionIndices) {
          _this.questionIndices = result.questionIndices
          resolve()
        } else {
          _this.getRemoteQuestions().then(data => {
            var _ = Object.keys(data).map(key => _this.questionIndices.push(key))
            _this.setLocalQuestions(_this.questionIndices).then(() => resolve()).catch(error => reject(error))
          }).catch(error => reject(error))
        }
      })
    });
  }

  this.clearCurrentQuestion = () => {
    if (!astroDOM) return false
    Object.keys(astroDOM).forEach(key => {
      while (astroDOM[key].firstChild) {
        astroDOM[key].removeChild(astroDOM[key].firstChild);
      }
    })
  }

  this.retrieveCurrentQuestion = ( key ) => {
    let _this = this
    return new Promise(function(resolve, reject) {
      firebase.database()
        .ref(constants.DB_QUESTION_PATH + '/' + key)
        .once('value')
        .then(function(snapshot) {
          resolve(snapshot.val())
        }).catch(function(error) {
          reject(error)
        })
    });
  }

  this.nextQuestion = () => {
    let _this = this
    if (_this.questionIndices.length === 0) return false

    _this.clearCurrentQuestion()
    _this.state.questionIndex = (_this.state.questionIndex === _this.questionIndices.length - 1) ?
      0 : _this.state.questionIndex + 1
    _this.setLocalState(_this.state)

    if (_this.state.questionIndex === _this.questionIndices.length - 1 ||
      _this.state.questionIndex % constants.QUESTION_FREQUENCY === 0) {

        if (_this.state.questionIndex === _this.questionIndices.length - 1) {
          _this.questionIndices = []
          _this.getRemoteQuestions().then(data => {
            var _ = Object.keys(data).map(key => _this.questionIndices.push(key))
            _this.setLocalQuestions(_this.questionIndices).then( () => {
              return true
            }).catch(error => {return false})
          }).catch(error => {return false})
        }

      _this.nextArticle()

    } else {
      let key = _this.questionIndices[_this.state.questionIndex]
      _this.retrieveCurrentQuestion( key ).then( result => {
        if (result) {
          let currentQuestion = new Question(key, result)
          if (currentQuestion) {
            var currentStatement = currentQuestion.getStatementElement()
            var currentCode = currentQuestion.getCodeElement()
            var currentOptions = currentQuestion.getOptionsElement()

            if (!currentStatement || !currentCode || !currentOptions) return false

            astroDOM.statement.appendChild(currentStatement)
            astroDOM.code.appendChild(currentCode)

            for (let index in currentOptions) {
              astroDOM.options.appendChild(currentOptions[index])
            }

            Prism.highlightAll();
            return true
          }
        }
      }).catch( error => {
        console.log(error)
        return false
      })
    }
  }

  this.nextArticle = () => {
    let _this = this
    _this.clearCurrentQuestion()

    _this.state.articleIndex = (_this.state.articleIndex === _this.articles.length - 1) ? 0 : _this.state.articleIndex + 1

    _this.retrieveStory(_this.articles[_this.state.articleIndex]).then(function(data) {

      var currentStory = new Story(data.title, data.url)
      if (currentStory) {

        _this.setLocalState(_this.state)
        var storyStatementDiv = document.createElement("div")
        storyStatementDiv.style.display = "flex"
        storyStatementDiv.style.flexDirection = "column"
        storyStatementDiv.style.justifyContents = "space-around"
        storyStatementDiv.style.alignItems = "center"

        // todo: refactor this
        if (_this.questionIndices >= _this.questionIndices.length - 1) {

          completeStatement.map(item => {
            let bonus = document.createElement("p")
            bonus.style.textAlign = "center"
            bonus.appendChild(document.createTextNode(item));
            storyStatementDiv.appendChild(bonus)
          })

        } else {
          let text = document.createTextNode("bonus: a random hacker news article every few questions")
          let bonus = document.createElement("p")
          bonus.style.textAlign = "center"
          bonus.appendChild(text)
          storyStatementDiv.appendChild(bonus)
        }

        astroDOM.statement.appendChild(storyStatementDiv)

        var story = currentStory.getStoryElement()
        if (!story) {
          return false
        }
        astroDOM.code.appendChild(story)

        var nextButton = document.createElement("button")
        nextButton.innerHTML = "Next"
        nextButton.onclick = answerHandler
        nextButton.className = "hover"
        nextButton.isNextButton = true

        astroDOM.options.appendChild(nextButton)
      }
    }).catch()
  }

  this.resetQuestions = () => {
    this.state.questionIndex = 0
    this.state.articleIndex = 0

    this.setLocalState(this.state).then(() => {
      this.nextQuestion()
    })
  }

  this.initialise = () => {
    let _this = this
    return new Promise(function(resolve, reject) {
      _this.getLocalState()
        .then(result => {
          if (!!result && Object.keys(result).length > 0) {
            let _ = Object.keys(_this.state).map(key => {
              _this.state[key] = result.state[key] ? result.state[key] : _this.state[key]
            })
          } else {
            // initialise the local state for the first time
            _this.setLocalState(_this.state)
          }
        })
        .then(_this.retrieveQuestions)
        .then(_this.retrieveHNTopStories)
        .then(() => resolve()).catch(error => reject(error))
    });
  }
}






// end
