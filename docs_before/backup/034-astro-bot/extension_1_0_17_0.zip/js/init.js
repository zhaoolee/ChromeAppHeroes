const constants = {
  TRACKING_KEY: 'UA-128262983-1',
  QUESTION_STATEMENT: 'question_statement',
  QUESTION_CODE: 'question_code',
  QUESTION_OPTIONS: 'question_options',
  QUESTION_FREQUENCY: 3,
  DB_QUESTION_PATH: 'astro-bot/questions/'
}

var _gaq = _gaq ? _gaq : [];
_gaq.push(['_setAccount', constants.TRACKING_KEY]);
_gaq.push(['_trackPageview']);

const firebaseConfig = {
  apiKey: "AIzaSyBRtJ-KOs9Fl0Gh3Gsqh-UHDK_WMjocLw8",
  authDomain: "personal-5a0f3.firebaseapp.com",
  databaseURL: "https://personal-5a0f3.firebaseio.com",
  projectId: "personal-5a0f3",
};

let logoState = false
let completeStatement = ["Congratulations, you've completed today's questions!"]

let astroDOM = {
  statement: document.getElementById(constants.QUESTION_STATEMENT),
  code: document.getElementById(constants.QUESTION_CODE),
  options: document.getElementById(constants.QUESTION_OPTIONS),
}

let astro
console.log("Astro Bot v1.0.17");
(function() {
  if (!chrome || !chrome.storage) return

  console.log("Valid extension environment");

  firebase.initializeApp( firebaseConfig );
  let ga = document.createElement('script');
  ga.type = 'text/javascript';
  ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  let s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(ga, s);

  astro = new AstroBot()
  astro.initialise().then( () => {
    astro.updateField('tabCount', astro.state.tabCount + 1)

    document.getElementById("main-logo").addEventListener("click", rotateLogo)
    document.getElementById("reset-button").addEventListener("click", astro.resetQuestions)

    removeLoader()
    showInterface()

    let _ = astro.nextQuestion()

  }).catch( error => console.log(error) )

})();
