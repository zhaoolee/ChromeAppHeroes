function Question(key, value) {

  this.key = key ? key : ""
  this.statement = value.statement ? value.statement : ""
  this.language = value.language
  this.code = value.code ? value.code : ""
  this.options = value.options ? value.options : []
  this.answer = value.answer ? value.answer : ""

  this.getStatementElement = function() {
    var statement = document.createElement("P")
    var text = document.createTextNode(this.statement)
    statement.appendChild(text)
    return statement
  }

  this.getCodeElement = function() {
    if (this.code.length > 0) {
      var pre = document.createElement("pre")
      var code = document.createElement("code")

      if (this.language) {
        code.className = `language-${this.language}`
      }

      var text = document.createTextNode(this.code)

      code.appendChild(text)
      pre.appendChild(code)

      return pre
    } else {
      return document.createElement("div")
    }
  }

  this.getOptionsElement = function() {
    var buttons = []
    for (let index = 0; index < this.options.length; index++) {
      let button = document.createElement("button")
      button.innerHTML = this.options[index].value
      button.id = this.options[index].key

      button.isAnswer = button.id === this.answer ? true : false

      button.onclick = answerHandler
      button.className = "hover"
      buttons.push(button)
    }
    return buttons
  }
}

function Story(title, url) {
  this.title = title
  this.url = url

  this.getStoryElement = function() {
    let element = document.createElement("a")
    element.href = this.url
    element.style.fontSize = '1.6em';
    let text = document.createTextNode(this.title)
    element.appendChild(text)
    return element
  }
}

function answerHandler() {
  this.style.border = 'none'
  let waitTime = 600
  if (this.isNextButton) {
    this.style.backgroundColor = "#0F8B8D"
    this.style.color = "#ffffff"
    setTimeout(function () {
      astro.nextQuestion()
    }, waitTime);
  } else {
    if (this.isAnswer) {
      this.style.backgroundColor = "#0F8B8D"
      this.style.color = "#ffffff"
      astro.updateField('correctCount', astro.state.correctCount + 1)
      displayCorrectMessage()
    } else {
      this.style.backgroundColor = "#950952"
      this.style.color = "#ffffff"
      astro.updateField('incorrectCount', astro.state.incorrectCount + 1)
      displayIncorrectMessage()
    }
  }
}
