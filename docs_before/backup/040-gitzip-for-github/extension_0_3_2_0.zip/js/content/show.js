
// just show the icon
chrome.runtime.sendMessage({action: "showIcon"}, function(response) {});

