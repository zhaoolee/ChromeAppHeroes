import * as React from 'react';
export declare class Header extends React.Component {
    constructor(props: any);
    render(): JSX.Element;
}
