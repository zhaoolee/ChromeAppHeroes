export declare class VideoControl {
    notifyAllToPerformSelfCheck(): void;
    notifyVideoControlSwitch(hostname: string, enabled: boolean): void;
}
