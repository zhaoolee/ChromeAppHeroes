export declare const clone: (obj: any) => any;
