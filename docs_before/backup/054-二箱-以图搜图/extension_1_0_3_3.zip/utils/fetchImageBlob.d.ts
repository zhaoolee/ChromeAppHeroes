export declare const fetchImageBlob: (uri: string, callback: any) => void;
