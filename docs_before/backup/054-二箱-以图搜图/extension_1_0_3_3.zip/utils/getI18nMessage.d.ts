export declare const getI18nMessage: (message: string, messageForPlural?: string | undefined, count?: number | undefined) => string;
