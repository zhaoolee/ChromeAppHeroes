export declare const getHostnameFromUrl: (url: string) => string;
