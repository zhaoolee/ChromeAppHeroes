export declare const getBase64FromImage: (img: any) => string;
