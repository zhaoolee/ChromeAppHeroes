export declare const getImageWidth: (url: string) => Promise<number>;
