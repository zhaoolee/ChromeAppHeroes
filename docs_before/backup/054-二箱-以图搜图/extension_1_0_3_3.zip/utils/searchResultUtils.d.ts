import { ISingleSearchResultItem } from '../searchResult/stores/searchResultStore';
export declare const getImageWidth: (searchResult: ISingleSearchResultItem) => number;
export declare const getImageHeight: (searchResult: ISingleSearchResultItem) => number;
