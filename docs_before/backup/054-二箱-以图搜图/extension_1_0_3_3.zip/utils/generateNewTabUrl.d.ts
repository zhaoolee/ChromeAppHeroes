export declare const generateNewTabUrl: (path: string) => Promise<unknown>;
