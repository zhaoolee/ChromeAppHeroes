export declare const stringOrArrayBufferToString: (input: string | ArrayBuffer) => any;
