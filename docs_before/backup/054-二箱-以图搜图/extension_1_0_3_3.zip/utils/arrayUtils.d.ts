export declare const getMinValueIndex: (list: number[]) => number;
