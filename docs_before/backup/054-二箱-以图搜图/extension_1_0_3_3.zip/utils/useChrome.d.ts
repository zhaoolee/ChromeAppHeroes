export declare const useChrome: () => void;
