export declare const openSearchResultTab: (cursor: number) => Promise<void>;
