import * as React from 'react';
export declare class About extends React.Component {
    constructor(props: any);
    render(): JSX.Element;
}
