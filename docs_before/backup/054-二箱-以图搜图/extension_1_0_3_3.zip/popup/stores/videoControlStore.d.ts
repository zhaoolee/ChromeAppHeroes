export declare class VideoControlStore {
    private static getOptionKey;
    active: boolean;
    hostname: string;
    constructor();
    toggle(): Promise<void>;
    private init;
}
