let tabList = {
  // windowId{number}: {
  //   tabId{number}: isKeylinesActivated{boolean}
  // }
};

function updateTabList (windowId, tabId, isKeylinesActivated) {
  if (!tabList[windowId]) {
    tabList[windowId] = {};
  }

  tabList[windowId][tabId] = isKeylinesActivated;
}


chrome.runtime.onMessage.addListener((message, messageSender, sendResponse) => {
  if (message.type === 'QUERY_TABS_STATUS') {
    let isKeylinesActivated = tabList[messageSender.tab.windowId] ? tabList[messageSender.tab.windowId][messageSender.tab.id] : false;
    sendResponse(isKeylinesActivated);
  }

  return true;
});


chrome.tabs.onActivated.addListener(activeInfo => {
  let windowId = activeInfo.windowId;
  let tabId = activeInfo.tabId;
  let isKeylinesActivated = tabList[windowId] ? tabList[windowId][tabId] : false;

  chrome.windows.getCurrent(
    {
      populate: true
    },
    function (window) {
      let currentTab = window.tabs.filter(function (tab) {
        return tab.active === true;
      })[0];

      chrome.browserAction.setIcon({
        path: {
          128: `image/logo_${isKeylinesActivated ? 'color_' : ''}128.png`
        }
      });

      chrome.tabs.sendMessage(
        currentTab.id,
        {
          type: 'KEYLINES_TAB_ON_ACTIVATED',
          windowId,
          tabId,
          isKeylinesActivated
        },
        function () {
        }
      );
    }
  );
});

chrome.browserAction.onClicked.addListener(function (thisTab) {
  let windowId = thisTab.windowId;
  let tabId = thisTab.id;

  chrome.windows.getCurrent(
    {
      populate: true
    },
    function (window) {
      let currentTab = window.tabs.filter(function (tab) {
        return tab.active === true;
      })[0];

      chrome.tabs.sendMessage(
        currentTab.id,
        {
          type: 'KEYLINES_BROWER_ACTION_ON_CLICK',
          windowId,
          tabId
        },
        function (isKeylinesActivated) {
          if (![true, false].includes(isKeylinesActivated)) return;

          chrome.browserAction.setIcon({
            path: {
              128: `image/logo_${isKeylinesActivated ? 'color_' : ''}128.png`
            }
          });

          updateTabList(windowId, tabId, isKeylinesActivated);
        }
      );
    }
  );
});