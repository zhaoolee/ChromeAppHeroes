window.isKeylinesActivated = false;

chrome.runtime.sendMessage({
  type: 'QUERY_TABS_STATUS'
}, (isKeylinesActivated) => {
  window.isKeylinesActivated = isKeylinesActivated;
  handleRender(isKeylinesActivated)
});

chrome.runtime.onMessage.addListener(function (message, messageSender, sendResponse) {
  if (message.type === 'KEYLINES_BROWER_ACTION_ON_CLICK') {
    window.isKeylinesActivated = !window.isKeylinesActivated;

    handleRender(window.isKeylinesActivated);

    if (/^https?:\/\//.test(location.href)) {
      sendResponse(window.isKeylinesActivated);
    }
  }

  if (message.type === 'KEYLINES_TAB_ON_ACTIVATED') {
    window.isKeylinesActivated = message.isKeylinesActivated;

    handleRender(window.isKeylinesActivated);
  }

  return true;
});



function handleRender (isKeylinesActivated) {
  if (isKeylinesActivated) {
    renderLine();
  }
  else {
    removeLine();
  }
}

let observer = null;

function renderLine () {

  [].forEach.call(document.querySelectorAll('*'), addOutline);

  observer = observer || new MutationObserver((records) => {
    records.forEach(record => {
      record.addedNodes.forEach(node => {
        node.querySelectorAll && [].forEach.call(node.querySelectorAll('*'), addOutline);
      });

    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree:   true
  });

  function addOutline (node) {
    if (node.style.outline) return;

    node.setAttribute('data-keylines', true);
    node.style.outline = '1px solid #' + (~~(Math.random() * (1 << 24))).toString(16);
  }

}

function removeLine () {
  [].forEach.call(document.querySelectorAll('*'), (node) => {
    if (node.hasAttribute('data-keylines')) {
      node.removeAttribute('data-keylines');
      node.style.outline = '';
    }
  });

  observer && observer.disconnect();
}