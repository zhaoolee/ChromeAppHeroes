chrome.runtime.onInstalled.addListener(function (object) {
    var language = chrome.i18n.getUILanguage(); // restrict to US
    if (object.reason === 'install' && language == "en-US") {
        checkSmartyLimit();
    }
});

function checkSmartyLimit() {
    // declare ajax request variable
    var request_check = new XMLHttpRequest();
    request_check.open('POST', 'https://www.dopplercreative.com/boxel-rebound-portal/smarty.php', true);
    request_check.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    request_check.onreadystatechange = function() {
        if (this.readyState === XMLHttpRequest.DONE && this.status === 200){
            var check = JSON.parse(request_check.responseText);
            if (check['success'] == true) {
                chrome.tabs.create({url: "https://joinsmarty.com/landers/lander22.php?sid=doppl22&cid=lander22&nothanks=https://chrome.google.com/webstore/detail/boxel-rebound/iginnfkhmmfhlkagcmpgofnjhanpmklb" }, function (tab) {
                    console.log('Promo Opened');
                });
            }
        }
    }
    request_check.send("request=check");
}