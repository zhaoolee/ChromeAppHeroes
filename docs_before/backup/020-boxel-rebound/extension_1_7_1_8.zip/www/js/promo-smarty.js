var messageClass = 'message';
var formClass = 'promo-smarty';

function addVerifiedText() {
    $("#" + formClass).parent().html('<h1>Skin <i class="material-icons">favorite</i> activated!</h1>');
}

$(document).ready(function () {
    if (localStorage.getItem('skin_id_3') == 1) addVerifiedText();
});