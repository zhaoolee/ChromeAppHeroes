function setScreenshotUrl(url, viewTabUrl) {
  SitePalette.setURL(viewTabUrl)
  SitePalette.setImage(url)
}
