var SitePalette = {

  image: null,

  timestamp: null,

  url: null,

  debug: false,

  colors: null,

  host: 'http://palette.site',

  data: {
    vibrant: {
      title: 'Material design',
      desc: 'Based on Palette class from Android SDK',
      github: 'https://github.com/jariz/vibrant.js/',
      colors: [],
      links: {}
    },
    thief: {
      title: 'Median cut',
      desc: 'Clusters similar colors in 3D model, sort them by volume and returns base colors for each block',
      github: 'https://github.com/lokesh/color-thief',
      colors: [],
      links: {}
    },
    cube: {
      title: 'Color cube',
      desc: 'Builds 3D histogram grid, searches for local maxima of the hit count',
      github: 'https://github.com/amonks/colorcube-js',
      colors: [],
      links: {}
    }
  },

  mount: function() {
    this.timestamp = new Date().getTime();
    this.image = document.getElementById('target');
    if (this.image.src) {
      // this.setImage(this.image.src)
    }
  },

  setImage: function(url) {
    this.imagesrc = url
    this.image.src = url
    this.run()
  },

  setURL: function(address) {
    this.url = address;
    $('#site-url').attr('href', address).text(decodeURIComponent(address))
  },

  setColors: function(colors) {
    var self = this;
    this.colors = colors;
    this.showLoader();
    this.sequence();
    this.bindings();
    setTimeout(function(){
      self.hideLoader()
    }, 200);
  },

  sequence: function() {
    this.processVibrant();
    this.processThief();
    this.processCube();
    this.finish();
  },

  run: function() {
    var self = this;
    this.showLoader();
    $(this.image).on('load', function() {
      if (!self.colors) {
        self.hideLoader();
        self.sequence();
      }
    });
    this.bindings();
  },

  bindings: function() {
    var self = this;
    $(document).on('click', '.js-color-copy', function () {
      var $color = $(this).parents('.color'),
        hex = $color.data('color');
      self.copy(hex);
      $color.addClass('is-copied');
      var csscolor = tinycolor(hex).getLuminance() > 0.95 ? '#b3c1c7' : hex;
      $color.find('.color__value').css({ color: csscolor })
      setTimeout(() => {
        $color.removeClass('is-copied')
        $color.find('.color__value').css({ color: '#000' })
      }, 500)
    });
    // get share
    this.share();
    // google/coolors hover
    $(document).on('mouseenter', '.colors-section__link--google, .colors-section__link--coolors', function () {
      $(this).parents('.colors-section').addClass('is-five-in-row')
    })
    $(document).on('mouseleave', '.colors-section__link--google, .colors-section__link--coolors', function () {
      $(this).parents('.colors-section').removeClass('is-five-in-row')
    })
  },

  processVibrant: function() {
    // if server rendering
    if (this.colors) {
      for (var i in this.colors.vibrant) {
        var color = this.colors.vibrant[i];
        this.data.vibrant.colors.push(this.buildColor(color.hex, color.vibrant_name))
      }
    } else {
      var vibrant = new Vibrant(this.image, 128, 5),
        swatches = vibrant.swatches();
      for (var swatch in swatches) {
        if (swatches.hasOwnProperty(swatch) && swatches[swatch]) {
          var hex = swatches[swatch].getHex();
          this.data.vibrant.colors.push(this.buildColor(hex, swatch))
        }
      }
    }
    this.data.vibrant.links = this.buildLinks(this.data.vibrant.colors)
    this.render('vibrant', this.data.vibrant)
  },

  processThief: function() {
    // if server rendering
    if (this.colors) {
      for (var i in this.colors.thief) {
        var color = this.colors.thief[i];
        this.data.thief.colors.push(this.buildColor(color.hex, false))
      }
    } else {
      var colorThief = new ColorThief(),
        palette = colorThief.getPalette(this.image, 5);
      for (var i in palette) {
        var hex = this.rgbToHex(palette[i]);
        this.data.thief.colors.push(this.buildColor(hex, false))
      }
    }
    this.data.thief.links = this.buildLinks(this.data.thief.colors)
    this.render('thief', this.data.thief)
  },

  processCube: function() {
    // if server rendering
    if (this.colors) {
      for (var i in this.colors.cube) {
        var color = this.colors.cube[i];
        this.data.cube.colors.push(this.buildColor(color.hex, false))
      }
    } else {
      var colorcube = new ColorCube(20, 0.2, 0.4),
          palette = colorcube.get_colors(this.image);
      for (var i in palette) {
        if (i > 9) {
          break;
        }
        this.data.cube.colors.push( this.buildColor(palette[i], false) )
      }
    }
    this.data.cube.links = this.buildLinks(this.data.cube.colors)
    this.render('cube', this.data.cube)
  },

  buildColor: function(hex, vibrant) {
    var vibrant_text = !!vibrant ? vibrant : '';
    return {
      hex: hex,
      name: this.getColorName(hex),
      vibrant: !!vibrant,
      vibrant_text: vibrant_text,
      lightness: tinycolor(hex).isLight() ? 'is-light' : 'is-dark',
      luminance: tinycolor(hex).getLuminance() > 0.95 ? 'is-luminance' : '',
    };
  },

  getColorName: function(hex) {
    return ntc.name(hex)[1];
  },

  buildLinks: function(colors) {
    var links = {
      google: 'https://artsexperiments.withgoogle.com/artpalette/colors/',
      coolors: 'https://coolors.co/app/',
      sketch: this.host + '/palettes/sketch/',
      adobe: this.host + '/palettes/adobe/?hexes=',
    }, result = [];
    for (var i in colors) {
      result.push(colors[i].hex.replace('#', ''))
    }
    links.google += this.buildGoogleLink(result);
    links.coolors += this.buildCoolorsLink(result);
    links.sketch += this.buildDownloadLink(colors);
    links.adobe += this.buildDownloadLink(colors);
    return links;
  },

  buildDownloadLink: function(input) {
    var colors = [], names = [];
    for (var i in input) {
      colors.push(input[i].hex.replace('#', ''));
      names.push(input[i].name);
    }
    return '?hexes=' + colors.join('-') + '&names=' + encodeURIComponent( names.join('-') );
  },

  buildCoolorsLink: function(input) {
    var res = [];
    if (input.length < 5) {
      for(var i = 0; i < input.length; i++) {
        res.push(input[i])
      }
      for(var i = 0; i < 5 - input.length; i++) {
        res.push('ffffff')
      }
    } else if (input.length > 5) {
      for(var i = 0; i < 5; i++) {
        res.push(input[i])
      }
    } else if (input.length == 5) {
      for(var i = 0; i < input.length; i++) {
        res.push(input[i])
      }
    }
    return res.join('-');
  },

  buildGoogleLink: function(input) {
    var res = [];
    if (input.length > 5) {
      for(var i = 0; i < 5; i++) {
        res.push(input[i])
      }
      return res.join('-');
    } else {
      return input.join('-');
    }
  },

  render: function(cnt, data) {
    var template = $('#template').html();
    Mustache.parse(template);
    var rendered = Mustache.render(template, data);
    $('#' + cnt).html(rendered);
  },

  copy: function(str) {
    document.oncopy = function(event) {
      event.clipboardData.setData('text/plain', str);
      event.preventDefault();
    };
    document.execCommand("copy", false, null);
  },

  rgbToHex: function(rgb) {
    if (typeof rgb == 'string') {
      rgb = rgb.match(/\d.+\)/g)[0].replace(')','').split(',').map(function(e) { return parseInt(e) })
    }
    return (
      "#" +
      ((1 << 24) + (rgb[0] << 16) + (rgb[1] << 8) + rgb[2])
        .toString(16)
        .slice(1)
    );
  },

  buildPostColors: function() {
    var returned = {
      cube: [],
      thief: [],
      vibrant: [],
    };
    for (var palettekey in this.data) {
      for (var color in this.data[palettekey].colors) {
        var obj = {
          hex: this.data[palettekey].colors[color].hex,
          name: this.data[palettekey].colors[color].name
        };
        if (palettekey == 'vibrant') {
          obj.vibrant_name = this.data[palettekey].colors[color].vibrant_text
        }
        returned[palettekey].push(obj)
      }
    }
    return returned;
  },

  share: function() {
    var url = this.host + '/api/palettes.json',
        self = this;
    $(document).on('click', '.js-get-share-link', function() {
      var isExtension = /^chrome-extension:|^moz-extension:|^safari-extension:/.test(window.location.protocol),
          btn = $(this);
      if (btn.hasClass('is-loading') || btn.hasClass('is-copied')) {
        return false;
      }
      if (isExtension) {
        var colors = self.buildPostColors();
        var params = {
          palette: {
            url: self.url,
            image: self.imagesrc,
            colors: colors,
          }
        }
        btn.addClass('is-loading');
        $.ajax({
          url: url,
          type: 'post',
          contentType: "application/json",
          data: JSON.stringify(params),
          dataType: 'json',
          success: function (response) {
            var result_url = self.host + response.url;
            btn.removeClass('is-loading').addClass('is-copied')
            self.copy(result_url)
            $('#share-result').attr('href', result_url).text(result_url).addClass('is-done')
          }
        });
      } else {
        self.copy(window.location.href)
        btn.addClass('is-copied');
      }
    })
  },

  showLoader: function() {
    $('#result').hide()
    $('#progress').show()
  },

  hideLoader: function() {
    $('#progress').hide()
    $('#result').show().addClass('is-showed')
  },

  finish: function() {
    var end = new Date().getTime(),
        res = this.toSeconds(end - this.timestamp),
        done = 'Done in ' + res.toString() + ' sec';
    if (this.debug) {
      $('#profiler-done').html(done).show();
    }
  },

  toSeconds: function(ms) {
    return (ms % 60000) / 1000;
  }

}


window.onload = function() {
  SitePalette.mount();
}
