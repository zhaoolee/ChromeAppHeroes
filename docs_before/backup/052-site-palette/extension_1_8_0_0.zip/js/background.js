var sitePalette = {
    screenId: 100,
    tabId: null,
    screenshotCanvas: null,
    screenshotContext: null,
    scrollBy: 0,
    size: {
        width: 0,
        height: 0
    },
    originalParams: {
        overflow: "",
        scrollTop: 0
    },
    initialize: function () {
        this.screenshotCanvas = document.createElement("canvas");
        this.screenshotContext = this.screenshotCanvas.getContext("2d");
        this.bindEvents();
    },

    getNextViewTabUrl: function () {
        return chrome.extension.getURL('screenshot.html?id=' + this.screenId++)
    },

    bindEvents: function () {
        chrome.browserAction.onClicked.addListener(function (tab) {
            this.tabId = tab.id;
            chrome.tabs.sendMessage(tab.id, {
                "msg": "getPageDetails"
            });
        }.bind(this));
        chrome.runtime.onMessage.addListener(function (request, sender, callback) {
            if (request.msg === "setPageDetails") {
                this.size = request.size;
                this.scrollBy = request.scrollBy;
                this.originalParams = request.originalParams;

                // set width & height of canvas element
                this.screenshotCanvas.width = this.size.width * window.devicePixelRatio;
                this.screenshotCanvas.height = this.size.height * window.devicePixelRatio;

                this.scrollTo(0);
            } else if (request.msg === "capturePage") {
                this.capturePage(request.position, request.lastCapture);
            }
        }.bind(this));
    },
    scrollTo: function (position) {
        chrome.tabs.sendMessage(this.tabId, {
            "msg": "scrollPage",
            "size": this.size,
            "scrollBy": this.scrollBy,
            "scrollTo": position
        });
    },

    capturePage: function (position, lastCapture) {
        var self = this;
        var tabUrl = '';
        chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
            tabUrl = tabs[0].url;
        });
        setTimeout(function () {
            chrome.tabs.captureVisibleTab(null, {
                "format": "jpeg",
            }, function (dataURI) {
                var newWindow,
                    image = new Image();
                    // https://stackoverflow.com/questions/25652485/capturevisibletab-returning-undefined
                    // https://www.ancestry.com/
                    // когда масштаб != 100 баги картинки и тупит
                if (typeof dataURI !== "undefined") {
                    image.onload = function () {
                        self.screenshotContext.drawImage(image, 0, position * window.devicePixelRatio);
                        if (lastCapture) {
                            self.resetPage();
                            var viewTabUrl = self.getNextViewTabUrl();
                            var targetId;
                            chrome.tabs.onUpdated.addListener(function listener(tabId, changedProps) {
                                if (tabId != targetId || changedProps.status != "complete")
                                    return;
                                chrome.tabs.onUpdated.removeListener(listener);
                                var views = chrome.extension.getViews();
                                for (var i = 0; i < views.length; i++) {
                                    var view = views[i];
                                    if (view.location.href == viewTabUrl) {
                                        view.setScreenshotUrl(self.screenshotCanvas.toDataURL("image/jpeg", 0.4), tabUrl);
                                        break;
                                    }
                                }
                            });
                            chrome.tabs.create({url: viewTabUrl}, function (tab) {
                                targetId = tab.id;
                            });
                        } else {
                            self.scrollTo(position + self.scrollBy);
                        }
                    };
                    image.src = dataURI;
                } else {
                    chrome.tabs.sendMessage(self.tabId, {
                        "msg": "showError",
                        "error": "Error"
                    });
                }
            });
        }, 150);
    },

    resetPage: function () {
        chrome.tabs.sendMessage(this.tabId, {
            "msg": "resetPage",
            "originalParams": this.originalParams
        });
    }
};

sitePalette.initialize();
