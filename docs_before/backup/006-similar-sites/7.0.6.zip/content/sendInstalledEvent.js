const interval = setInterval(()=>{
	if (document.getElementById('done_preload')){
		var event = new Event('ssInstalled');
		document.dispatchEvent(event);
		window.clearInterval(interval);
	}
}, 10);


