function moveToTab() {
  let currentWindowID = parseInt($(".selected")[0].children[4].innerHTML);
  let currentTabID = parseInt($(".selected")[0].children[3].innerHTML);
  chrome.windows.update(currentWindowID, { focused: true });
  try {
    chrome.tabs.update(currentTabID, { active: true });
  } catch (e) {
    alert(e);
  }
}
function closeTab(tab, event) {
  if(event.target) {
    let tabID = parseInt(tab.id);
    let tabs = $(".itemID");
    for(let i=0; i < tabs.length; i++) {
      let currentTabID = parseInt(tabs[i].innerHTML);
      if(currentTabID === tabID) {
        tabs[i].parentElement.remove();
      }
    }
    chrome.tabs.remove(tabID);
    event.stopPropagation();
  }
}
function scrollToHigh(index) {

  if (index === -1) {
    return;
  }

  let results = this.$("html");
  let lis = this.$(".item:visible") || [];
  if (lis[index]) {
    let selectedLi = $(lis[index]);
    let rb, hb, y;
    hb = selectedLi.offset().top + selectedLi.outerHeight(true);
    rb = $("html").scrollTop() + $(window.top).height();

    if (hb > rb) {
      results.scrollTop(results.scrollTop() + (hb - rb));
    }

    y = selectedLi.offset().top - $("html").scrollTop();

    // make sure the top of the element is visible
    if (y < 0) {
      results.scrollTop(results.scrollTop() + y); // y is negative
    }

    if (index === 0) {
      results.scrollTop(0);
    }
  }
}

function keyboardHandler(event) {
  let key = event.keyCode;
  let currentIndex=$(".item:visible").index($(".selected"));
  let current;
  if(key==40) {
    if(currentIndex<$(".item:visible").length-1) {
      currentIndex=currentIndex+1;
    } else {
      currentIndex=0;
    }
    $(".item:visible").removeClass("selected");

    current=$(".item:visible").eq(currentIndex);
    current.addClass("selected");
    scrollToHigh(currentIndex);
  } else if (key == 38) {

    if(currentIndex>0) {
      currentIndex=currentIndex-1;
    } else {
      currentIndex=$(".item:visible").length-1;
    }
    $(".item:visible").removeClass("selected");

    current=$(".item:visible").eq(currentIndex);
    current.addClass("selected");
    scrollToHigh(currentIndex);
  } else if ( key == 13) {
    moveToTab();
  } else {
    let matcher = new RegExp(document.getElementById("search").value, "gi");
    for(let i=0; i < document.getElementsByClassName("item").length; i++) {
      if (
        matcher.test(document.getElementsByClassName("itemtitle")[i].innerHTML) ||
        matcher.test(document.getElementsByClassName("itemurl")[i].innerHTML)
      ) {
        document.getElementsByClassName("item")[i].style.display="block";
      } else {
        document.getElementsByClassName("item")[i].style.display="none";
      }
    }
    $(".item").removeClass("selected");
    $(".item:visible").eq(0).addClass("selected");
    let windowList = document.getElementsByClassName("window").length;
    for(let j=0; j<windowList; j++) {
      let hidden = true;
      for(let k=0; k<document.getElementsByClassName("window")[j].getElementsByClassName("item").length; k++) {
        if(document.getElementsByClassName("window")[j].getElementsByClassName("item")[k].style.display === "block") {
          hidden = false;
        }
      }
      if(hidden === true) {
        document.getElementsByClassName("window")[j].style.display = "none";
      } else {
        document.getElementsByClassName("window")[j].style.display = "block";
      }
    }
  }
}

function constructTabTree(tabs, parent) {
  let item, itemName, itemImage, itemClose, itemUrl, itemID, itemWindowID;

  tabs.forEach(function(tab) {
    item = document.createElement("div");
    item.className = "item";
    parent.appendChild(item);

    itemImage = document.createElement("img");
    itemImage.className = "itemimage";
    itemImage.src = tab.favIconUrl;
    item.append(itemImage);

    itemName = document.createElement("div");
    itemName.className = "itemtitle";
    itemName.innerHTML = tab.title;
    item.append(itemName);

    itemUrl = document.createElement("div");
    itemUrl.className = "itemurl";
    itemUrl.innerHTML = tab.url;
    item.append(itemUrl);

    itemID = document.createElement("div");
    itemID.className = "itemID";
    itemID.innerHTML = tab.id;
    itemID.style.display="none";
    item.append(itemID);

    itemWindowID = document.createElement("div");
    itemWindowID.className = "itemWindowID";
    itemWindowID.innerHTML = tab.windowId;
    itemWindowID.style.display="none";
    item.append(itemWindowID);

    itemClose = document.createElement("div");
    itemClose.className = "itemclose";
    itemClose.innerHTML = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"512\" height=\"512\" viewBox=\"0 0 512 512\"><path d=\"M466.745 0L256 210.745 45.255 0 0 45.254 210.745 256 0 466.745 45.255 512 256 301.255 466.745 512 512 466.745 301.255 256 512 45.254z\"/></svg>";
    item.append(itemClose);

    itemClose.addEventListener("click", closeTab.bind(this, tab));
    item.addEventListener("click", function () { moveToTab(); });
  });
}
document.addEventListener("DOMContentLoaded", function() {
  let container = document.getElementById("container");
  let list = document.createElement("div");
  let i = 1;
  list.setAttribute("id", "list");
  container.appendChild(list);
  document.getElementById("search").addEventListener("keyup", keyboardHandler);

  chrome.windows.getAll({populate:true},function(windows){
    windows.forEach(function(window){
      let itemList = document.createElement("div");
      itemList.className = "window";
      list.appendChild(itemList);
      let heading = document.createElement("div");
      heading.className = "heading";
      if(window.focused == true) {
        heading.innerHTML = "Current Window";
      } else {
        heading.innerHTML = "Window " + i;
        i=i+1;
      }
      itemList.appendChild(heading);
      constructTabTree(window.tabs, itemList);
    });
    let itemsList = $(".item:visible");
    itemsList.eq(0).addClass("selected");
    itemsList.each(function(itemIndex, item) {
      $(item).mouseover(function(e) {
        itemsList.removeClass("selected");
        e.currentTarget.className = "item selected";
        // let currentIndex=itemsList.index($(e.target));
        // let current=item.eq(currentIndex);
        // current.addClass("selected");
      });
    });
  });
});
